from pathlib import Path
import re,subprocess,csv,json,hashlib,collections
root=Path('/workspace/hakoniwa-world'); out=Path('/workspace/perf-audit-20261031')
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
paths=subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
paths=[p for p in paths if '/archive/' not in '/'+p and not Path(p).name.startswith('.env')]
def family(p):
    if p.startswith('product/app/'): return 'app/'+p.split('/')[2]
    if p.startswith('product/resources/js/'): return 'frontend'
    if p.startswith('product/routes/'): return 'routes'
    if p.startswith('product/bootstrap/'): return 'bootstrap'
    if p.startswith('product/resources/views/'): return 'views'
    if p.startswith('product/resources/css/'): return 'styles'
    if p in ['product/public/index.php','product/public/.htaccess']: return 'public-entry'
    if p in ['product/composer.json','product/package.json','product/vite.config.js','product/tsconfig.json','product/eslint.config.js']: return 'build-config'
    if p.startswith('product/config/'): return 'config'
    if p.startswith('product/database/'): return 'database'
    if p.startswith('product/docker/') or p=='product/Dockerfile': return 'operations'
    if p.startswith('.github/workflows/'): return 'ci'
    return None
files=[];symbols=[]
for p in paths:
    f=family(p)
    if not f or (f=='frontend' and ('.test.ts' in p or '__fixtures__' in p)): continue
    path=root/p
    if not path.is_file(): continue
    data=path.read_bytes()
    if path.suffix not in ['.php','.ts','.vue','.js','.sh','.json','.sql','.yml','.yaml','.conf','.ini','.css'] and path.name not in ['Dockerfile','.htaccess']: continue
    s=data.decode('utf-8',errors='replace')
    files.append({'path':p,'family':f,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'lines':len(s.splitlines()),'functions':len(re.findall(r'\bfunction\s+\w+',s)),'query_markers':len(re.findall(r'::query\(|DB::|->(?:get|first|count|exists|sum|pluck|update|save|insert|delete)\(',s)),'loop_markers':len(re.findall(r'\b(?:foreach|for|while)\s*\(|\.(?:map|filter|sort)\(',s)),'source_sha':sha})
    for i,line in enumerate(s.splitlines(),1):
        m=re.search(r'(?:(public|protected|private)\s+)?(?:static\s+)?function\s+(\w+)\s*\(',line)
        if m: symbols.append({'path':p,'line':i,'visibility':m[1] or 'n/a','symbol':m[2],'family':f,'source_sha':sha})
for name,rows in [('source-census.csv',files),('symbols.csv',symbols)]:
    with (out/name).open('w') as h:
        w=csv.DictWriter(h,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={'source_sha':sha,'files':len(files),'symbols':len(symbols),'families':dict(collections.Counter(x['family'] for x in files)), 'excluded':'archive body, environment/credential files, vendor, node_modules, tests and test fixtures as performance targets (existing focused tests used as evidence)'}
(out/'inventory-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False))
