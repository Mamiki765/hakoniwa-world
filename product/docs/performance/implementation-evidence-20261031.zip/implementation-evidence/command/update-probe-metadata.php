<?php
$path = '/evidence/command-response-after-queries.json';
$data = json_decode(file_get_contents($path), true, flags: JSON_THROW_ON_ERROR);
$data['original_probe_limit_note'] = $data['limits'];
$data['limits'] = 'One candidate-code request per Q=1/Q=30 in one synthetic fixture. Compare SQL counts with the separately archived fixed-base measurement; no repeated latency benchmark or production speedup claim.';
file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR)."\n");
