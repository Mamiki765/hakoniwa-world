<?php
// Pure bounded benchmark: real config/app files, no application boot or DB.
$mode = $argv[1] ?? 'after';
$GLOBALS['counts'] = [];
function probeCount(string $key): void { $GLOBALS['counts'][$key] = ($GLOBALS['counts'][$key] ?? 0) + 1; }
function probeRead(string $path): string|false { probeCount('file_reads'); return file_get_contents($path); }
function probeDecode(string $source, bool $associative, int $depth, int $flags): mixed { probeCount('json_decodes'); return json_decode($source, $associative, $depth, $flags); }
function config_path(string $path): string { return '/var/www/html/config/'.$path; }
function config(string $key, mixed $default = null): mixed {
    static $configs = [];
    $parts = explode('.', $key); $name = array_shift($parts);
    $configs[$name] ??= require config_path($name.'.php'); $value = $configs[$name];
    foreach ($parts as $part) { if (! is_array($value) || ! array_key_exists($part, $value)) return $default; $value = $value[$part]; }
    return $value;
}
spl_autoload_register(function (string $class) use ($mode): void {
    if (! str_starts_with($class, 'App\\')) return;
    $path = '/var/www/html/app/'.str_replace('\\', '/', substr($class, 4)).'.php';
    if ($class === App\Application\Underground\UndergroundAlphaV1PlayerCatalog::class && $mode === 'before') $path = '/evidence/baseline-player-catalog.php';
    $source = file_get_contents($path);
    if ($class === App\Application\Underground\UndergroundAlphaV1PlayerCatalog::class) {
        $source = str_replace(['file_get_contents(', 'json_decode('], ['\\probeRead(', '\\probeDecode('], $source);
    }
    if ($class === App\Domain\Underground\Combat\AlphaV1BuildCatalog::class) {
        $source = str_replace("public function __construct(private array \$manifest)\n    {", "public function __construct(private array \$manifest)\n    {\n        \\probeCount('catalog_constructions');", $source, $n);
        if ($n !== 1) throw new RuntimeException('Constructor instrumentation mismatch');
    }
    eval(substr($source, 5));
});
use App\Application\Underground\UndergroundAlphaV1PlayerCatalog;
use App\Domain\Underground\Combat\AlphaV1CombatRules;
use App\Domain\Underground\Combat\UndergroundBuildValidator;
$results = ['mode'=>$mode,'base_sha'=>'2e93ec918774ad64d787aba99fc59a7bc3e54d16','php'=>PHP_VERSION,'kind'=>'pure PHP, counts instrumented, no DB/network/application boot','iterations'=>16];
// Load classes/config before timed groups; each group gets one fresh resolver.
$rules = new AlphaV1CombatRules;
$validator = new UndergroundBuildValidator($rules);
$warm = new UndergroundAlphaV1PlayerCatalog($rules, $validator);
$warm->explorationCatalog(); $warm->trialCatalog('trial_01');
foreach (['foundation', 'exploration', 'trial', 'normal_encounter_preparation'] as $kind) {
    $player = new UndergroundAlphaV1PlayerCatalog($rules, $validator);
    $GLOBALS['counts'] = []; $values = []; $start = hrtime(true);
    for ($i=0; $i<16; $i++) {
        if ($kind === 'foundation') $values[] = hash('sha256', serialize($player->laboratoryCatalog()->manifest()));
        if ($kind === 'exploration') $values[] = hash('sha256', serialize($player->explorationCatalog()->manifest()));
        if ($kind === 'trial') $values[] = hash('sha256', serialize($player->trialCatalog('trial_01')->manifest()));
        if ($kind === 'normal_encounter_preparation') {
            $ground = 'shallow_caves';
            $key = $player->weightedExplorationEncounter(1000, $ground);
            $first = $player->explorationEncounter($key, $ground);
            $normal = $player->explorationEncounters($ground);
            $selected = $player->explorationEncounter($key, $ground);
            $values[] = hash('sha256', serialize([$key,$first,$normal,$selected]));
        }
    }
    $results[$kind] = ['elapsed_ms'=>(hrtime(true)-$start)/1e6,'calls'=>$GLOBALS['counts'],'value_hash'=>hash('sha256',serialize($values))];
}
$results['peak_memory_bytes'] = memory_get_peak_usage(true);
file_put_contents('/evidence/catalog-benchmark-'.$mode.'.json',json_encode($results,JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR)."\n");
echo json_encode($results,JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR)."\n";
