<?php
declare(strict_types=1);
// Research only: same-row generated columns in a transaction-local synthetic table.
require '/var/www/html/vendor/autoload.php';
$app = require '/var/www/html/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
if (! $app->environment('testing') || Illuminate\Support\Facades\DB::connection()->getDriverName() !== 'pgsql'
    || ! str_ends_with(Illuminate\Support\Facades\DB::connection()->getDatabaseName(), '_test')) {
    throw new RuntimeException('Research probe requires the isolated PostgreSQL test database.');
}
use Illuminate\Support\Facades\DB;

$cases = [[], ['sort' => 'price'], ['sort' => 'item_level'],
    ['category' => 'weapon', 'il_min' => 30, 'quality_min' => 30],
    ['purchasable_only' => true], ['weapon_style' => 'sword'],
    ['sort' => 'item_level', 'purchasable_only' => true, 'page' => 2],
    ['il_min' => 1000], ['page' => 1000000]];
$cap = 60;
$size = config('hakoniwa.ruleset.underground_market.page_size');
$results = [];
DB::beginTransaction();
try {
    DB::statement(<<<'SQL'
CREATE TEMP TABLE audit_market_query_probe (
 id BIGINT PRIMARY KEY, status TEXT NOT NULL, price BIGINT NOT NULL, item_snapshot JSONB NOT NULL,
 item_level_query INTEGER GENERATED ALWAYS AS ((item_snapshot->>'item_level')::integer) STORED,
 quality_query INTEGER GENERATED ALWAYS AS (COALESCE((item_snapshot->>'quality_percent')::integer, 0)) STORED,
 category_query TEXT GENERATED ALWAYS AS (item_snapshot->>'category') STORED,
 weapon_style_query TEXT GENERATED ALWAYS AS (item_snapshot->>'weapon_style') STORED
) ON COMMIT DROP
SQL);
    $records = [];
    foreach (range(1, 96) as $id) {
        $item = ['category' => ['weapon', 'armor', 'accessory', 'resonance'][$id % 4],
            'item_level' => 20 + ($id % 9) * 10];
        if ($id % 5 !== 0) {
            $item['quality_percent'] = $id % 11 === 0 ? null : ($id % 5) * 20;
        }
        if ($item['category'] === 'weapon' && $id % 8 !== 0) {
            $item['weapon_style'] = $id % 3 === 0 ? 'bow' : 'sword';
        }
        $records[] = ['id' => $id, 'status' => $id % 7 === 0 ? 'sold' : 'active',
            'price' => 1000 + ($id % 5) * 100, 'item_snapshot' => json_encode($item, JSON_THROW_ON_ERROR)];
    }
    DB::table('audit_market_query_probe')->insert($records);
    $raw = DB::table('audit_market_query_probe')->where('status', 'active')->orderByDesc('id')->get();
    foreach ($cases as $filters) {
        // Current browse filter/sort semantics, narrowed to IDs and has_more for comparison.
        $rows = $raw->map(static function ($row) use ($cap): array {
            $item = json_decode($row->item_snapshot, true, 512, JSON_THROW_ON_ERROR);
            return ['id' => (int) $row->id, 'price' => (int) $row->price, 'item' => $item,
                'purchasable' => $item['item_level'] <= $cap];
        })->filter(static function (array $row) use ($filters): bool {
            $item = $row['item'];
            return (! ($filters['purchasable_only'] ?? false) || $row['purchasable'])
                && (! isset($filters['category']) || $item['category'] === $filters['category'])
                && (! isset($filters['weapon_style']) || ($item['weapon_style'] ?? null) === $filters['weapon_style'])
                && ($item['item_level'] >= ($filters['il_min'] ?? 0))
                && (($item['quality_percent'] ?? 0) >= ($filters['quality_min'] ?? 0));
        })->values();
        $sort = $filters['sort'] ?? 'newest';
        if ($sort === 'price') { $rows = $rows->sortBy([['price', 'asc'], ['id', 'desc']])->values(); }
        if ($sort === 'item_level') { $rows = $rows->sortBy([['item.item_level', 'desc'], ['id', 'desc']])->values(); }
        $page = $filters['page'] ?? 1;
        $expected = ['ids' => $rows->slice(($page - 1) * $size, $size)->pluck('id')->values()->all(),
            'has_more' => $rows->count() > $page * $size];
        $query = DB::table('audit_market_query_probe')->where('status', 'active')
            ->where('item_level_query', '>=', $filters['il_min'] ?? 0)
            ->where('quality_query', '>=', $filters['quality_min'] ?? 0);
        if ($filters['purchasable_only'] ?? false) { $query->where('item_level_query', '<=', $cap); }
        if (isset($filters['category'])) { $query->where('category_query', $filters['category']); }
        if (isset($filters['weapon_style'])) { $query->where('weapon_style_query', $filters['weapon_style']); }
        if ($sort === 'price') { $query->orderBy('price'); }
        if ($sort === 'item_level') { $query->orderByDesc('item_level_query'); }
        $fetched = $query->orderByDesc('id')->offset(($page - 1) * $size)->limit($size + 1)->get(['id']);
        $actual = ['ids' => $fetched->take($size)->pluck('id')->map(static fn ($id): int => (int) $id)->all(),
            'has_more' => $fetched->count() > $size];
        if ($actual !== $expected) { throw new RuntimeException('Query-column mismatch: '.json_encode($filters)); }
        $results[] = ['filters' => $filters, 'equal' => true, 'current_rows_fetched' => $raw->count(),
            'candidate_rows_fetched' => $fetched->count(), 'result' => $actual];
    }
} finally {
    DB::rollBack();
}
echo json_encode(['base_sha' => '2e93ec918774ad64d787aba99fc59a7bc3e54d16', 'php' => PHP_VERSION,
    'current_service_sha256' => hash_file('sha256', '/var/www/html/app/Application/Underground/UndergroundMarketService.php'),
    'source' => 'UndergroundMarketService::browse filter/sort subset', 'fixture_rows' => 96, 'page_size' => $size,
    'cases' => $results, 'permanent_data_changed' => false,
    'limits' => 'Synthetic TEMP table only. Compares IDs/order/has_more and rows transferred; not admission, blocked reasons, inventory, purchase, historic malformed JSON, index plans, latency or production throughput. No market runtime implementation or migration.'
], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), "\n";
