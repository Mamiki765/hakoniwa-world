<?php
require '/var/www/html/vendor/autoload.php';
require '/evidence/CommandQueueServiceBaseline.php';
use App\Application\CommandQueueService;
use App\Application\CommandQueueServiceBaseline;
use App\Models\NationCommandQueueItem;
use Illuminate\Database\Eloquent\Collection;
$objects=[];$methods=[];
foreach (['before'=>CommandQueueServiceBaseline::class,'after'=>CommandQueueService::class] as $key=>$class) {
    $objects[$key]=(new ReflectionClass($class))->newInstanceWithoutConstructor();
    $methods[$key]=new ReflectionMethod($class,'bulkPlan');
}
function candidates(int $count): array { $out=[];for($i=0;$i<$count;$i++) $out[]=['definition'=>null,'x'=>$i,'y'=>0];return $out; }
function active(int $count): Collection { $out=[];for($i=1;$i<=$count;$i++) $out[]=(new NationCommandQueueItem)->forceFill(['id'=>$i,'queue_position'=>$i]);return new Collection($out); }
function normalized(array $p): array {
    $cancelled=$p['cancelled']??array_map(fn($e)=>$e['existing'],array_values(array_filter($p['dropped'],fn($e)=>isset($e['existing']))));
    return ['kept'=>array_map(fn($e)=>isset($e['existing'])?['id'=>$e['existing']->id]:$e,$p['kept']),
        'cancelled_ids'=>array_map(fn($m)=>$m->id,$cancelled),
        'truncated_count'=>$p['truncated_count']??count($p['dropped']),
        'inserted_count'=>$p['inserted_count'],'skipped_count'=>$p['skipped_count'],
        'cancelled_count'=>$p['cancelled_count'],'cancelled_items'=>$p['cancelled_items']];
}
$cases=[[0,31,1,1],[29,2,5,1],[29,3,5,1],[29,2,30,2],[30,0,1,1],[0,32,1,2]];
$matches=0;
foreach($cases as [$q,$c,$position,$group]) foreach(['overflow','fill_available'] as $policy) {
    $args=[active($q),candidates($c),$position,30,$group,$policy];$results=[];
    foreach($objects as $key=>$object) $results[$key]=normalized($methods[$key]->invokeArgs($object,$args));
    if($results['before']!==$results['after']) throw new RuntimeException('Mismatch '.json_encode([$q,$c,$position,$group,$policy]));
    $matches++;
}
$large=candidates(10000);$empty=active(0);$samples=[];
for($round=0;$round<3;$round++) foreach($objects as $key=>$object) {
    gc_collect_cycles();$startMemory=memory_get_usage();$start=hrtime(true);$plans=[];
    foreach(['overflow','fill_available'] as $policy) $plans[$policy]=$methods[$key]->invoke($object,$empty,$large,1,30,1,$policy);
    $samples[$key][]=['elapsed_ms'=>(hrtime(true)-$start)/1e6,'retained_memory_delta_bytes'=>memory_get_usage()-$startMemory,
        'discarded_generated_wrappers'=>array_sum(array_map(fn($p)=>isset($p['dropped'])?count($p['dropped']):0,$plans))];
    unset($plans);
}
echo json_encode(['base_sha'=>'2e93ec918774ad64d787aba99fc59a7bc3e54d16','php'=>PHP_VERSION,
    'fixture'=>['candidate_count'=>10000,'active_items'=>0,'queue_limit'=>30,'policies'=>2,'rounds'=>3],
    'semantic_comparisons'=>$matches,'all_matched'=>true,'samples'=>$samples,
    'limits'=>'Pure private planning method only; candidate allocation, map scan, validation, snapshot, ORM, SQL and HTTP excluded. Shared host, no production speedup prediction.'],JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR),"\n";
