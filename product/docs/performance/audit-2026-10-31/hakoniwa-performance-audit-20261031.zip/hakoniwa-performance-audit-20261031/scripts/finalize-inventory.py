from pathlib import Path
import csv,re,json,collections
root=Path('/workspace/hakoniwa-world'); out=Path('/workspace/perf-audit-20261031')
def read(name): return list(csv.DictReader((out/name).open()))
def save(name,rows):
    with (out/name).open('w') as h:
        w=csv.DictWriter(h,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
census=read('source-census.csv'); sha=census[0]['source_sha']; fronts=[]
for r in census:
    if r['family']!='frontend': continue
    p=r['path']; name=Path(p).name
    cand=''; note='入力件数に線形/小さな固定catalog。IOはAPI側台帳へ。追加の具体的改善を裏付けず。'; group='フォーム・表示・局所projection'
    if name=='App.vue': cand='UI-01;UI-03';group='shell/初期read/遷移/timer';note='static import bundle、公開read→本人read逐次。世代/partial error/認証境界を維持。'
    elif name=='HexMap.vue':cand='UI-02';group='map input/culling/DOM';note='全loaded N走査。scalar補助実測は小さく実ブラウザ主因認定は保留。'
    elif name=='UndergroundPanel.vue':cand='UI-01';group='地底view/遷移/戦闘応答';note='static import/story読込はbundle比較。決算/受付はBU/APIへ。'
    elif name in ['CommandQueuePanel.vue','surfaceLedger.ts']:cand='CQ-01;CQ-02;CQ-03;CQ-06';group='計画取得/通常・bulk mutation';note='command担当でPromise.all/abort/generation/refresh延期の既修正も確認。'
    elif name in ['UndergroundBattleLog.vue','undergroundBattleLog.ts']:cand='BU-05';group='戦闘ログprojection';note='structured computed/再生、simple旧形式round×action filterのみ低優先。'
    elif name=='client.ts':group='API/受付/token/error';note='mutation前の受付、再送token保持/不確定結果の新規化禁止を維持。'
    elif name in ['mapState.ts','ownBoardUnread.ts','boosts.ts']:group='cache/inflight/世代/poll';note='既存dedup/世代/timer境界あり。具体的な重複requestを特定せず。'
    if 'preview/' in p or any(x in name for x in ['TestHarness','TestFixture','TestNavigation']): group='開発preview/test補助';note='通常production入口からは使わない。構造目録へ含め、実行時間は未測定。'
    fronts.append({'path':p,'group':group,'inspection':'確認済み（静的構造・関連経路）','result':'改善候補（条件付き含む）' if cand else '具体的追加候補なし','candidate':cand,'notes':note,'measurement_limit':'全画面browser trace/HTTP/全分岐実行は未確認。詳細frontend.md。','source_sha':sha})
save('frontend-coverage.csv',fronts)
existing=['api-db-coverage.csv','command-coverage.csv','command-symbols.csv','battle-coverage.csv','battle-file-inventory.csv','turn-coverage.csv','turn-dependency-inventory.csv','foundation-coverage.csv','frontend-coverage.csv']
refs=collections.defaultdict(set)
for name in existing:
    for row in read(name):
        for v in row.values():
            if not v: continue
            for p in re.findall(r'(?:product/)?app/[A-Za-z0-9_./]+\.php|product/resources/js/[A-Za-z0-9_./]+\.(?:ts|vue)',v):
                p=p if p.startswith('product/') else 'product/'+p
                refs[p].add(name)
for r in fronts: refs[r['path']].add('frontend-coverage.csv')
extra=[]
for r in census:
    p=r['path'];fam=r['family']
    if p.startswith('product/app/') and p in refs:continue
    if fam=='frontend':continue
    cand='';note='起動/設定/schema/運用の構造確認。実稼働の有効性・IO/planは未確認。';result='具体的追加候補なし/正当性コストを維持'
    if p.endswith('LegacyInspiredInitialIslandGenerator.php'):cand='SUP-01;SUP-02';note='登録plan/apply。変更cell save/船候補sortの有限増幅。lock/prestate/退避/rollback保持。'
    elif p.endswith('NationResourceService.php') or p.endswith('RulesetPublisher.php'):cand='SUP-01';note='cold登録/install/publicationの有限逐次write/2P definition lookup。通常Turn guardとは区別。'
    elif p.endswith('AssetManifestResolver.php'):cand='UI-04';note='sceneAssets map反復。単純image結果cacheはconfig/file即時更新の反証あり保留。'
    elif p.endswith('MapCellPresenter.php'):cand='FND-01;UI-04';note='呼出側eager/偽装用definition memo済。船direct parse/asset projectionへ。'
    elif p.endswith('OilDiscoveryExperienceBackfill.php'):cand='AP-14';note='明示的一回補填、6 SELECT/正常旧event。推測帰属/再適用不可。'
    elif p.endswith('SecretaryItemEffectContextResolver.php'):note='joinで所有World確定、metadata照合、settings decodeは1回/resolve。'
    elif p.endswith('BuriedTreasureRevealResolver.php'):note='completed run1query、distinct treasure cell label draw。viewer/Turnを跨ぐcacheは不可。'
    elif p.endswith('PublicMonsterKillProjection.php'):note='歴史/current定義batch、stable key集約とsort。'
    elif p.endswith('SeaAreaWeatherPresenter.php'):note='weather種類単位のasset memo済。chunk順/初回sunny表現維持。'
    elif p.endswith('ManualIndexPresenter.php'):note='有限canonical索引/notes require。小さなrequest-local共有余地はあるが未測定・高優先へ昇格せず。'
    elif p.endswith('AdditionalTurnPlan.php') or p.endswith('TurnExecutionSchedule.php') or p.endswith('TurnScheduleStatus.php'):note='bounded slots/debt/重複防止、nextRegularは算術・SQLなし。series共有はAP-02。'
    elif fam.startswith('app/'):note='小さなDTO/interface/例外/seed/算術/guard。補完分冊に境界を記録。'
    elif fam=='database':note='canonical schema+全現行migration構造、96 table索引台帳へ。実DB/WAL/planは未確認。'
    elif fam=='config':note='current/frozen canonical payloadとLaravel設定の構造。全設定再解読の既修正とauthoring gateを区別。'
    elif fam=='styles':note='ビルドへ含むtheme/game CSS。transfer bytes確認、style/paintと実端末は未確認。'
    elif fam=='views':note='Blade loop/asset起動/公開とprivate表示の構造。manual有限indexはPHP分冊へ。'
    if cand:result='改善候補（条件付き/低優先含む）'
    extra.append({'path':p,'family':fam,'inspection':'確認済み（構造・関連呼出の静的照合）','result':result,'candidate':cand,'notes':note,'limits':'全分岐実行/本番設定/実行計画は未確認','report':'supplement.md;frontend.md','source_sha':sha})
save('supplement-coverage.csv',extra)
for r in extra:refs[r['path']].add('supplement-coverage.csv')
sources=[]
for r in census:
    sources.append({**r,'inspection':'構造棚卸し済み','coverage_refs':';'.join(sorted(refs[r['path']])),'detailed_limit':'処理群/担当台帳の確認粒度が正本。全3751methodの全行手読・全分岐動的実行の意味ではない。','runtime_validation':'代表実測以外未確認'})
save('source-coverage.csv',sources)
assert all(x['coverage_refs'] for x in sources)
routes=json.loads((out/'routes.json').read_text()); route_rows=[]
for r in routes:
    a=r['action'];path='';owner='supplement';cand='';detail='静的入口/処理群確認、動的全分岐未確認'
    if a.startswith('App\\'):
        klass=a.split('@')[0];path='product/app/'+klass.removeprefix('App\\').replace('\\','/')+'.php'
        if 'CommandQueueController' in a:owner='command';cand='CQ-01〜06'
        elif 'UndergroundIntroController' in a or 'UndergroundEquipmentController' in a:owner='battle';cand='BU-01〜05'
        elif 'AssetController' in a or 'AppController' in a or 'ManualController' in a:owner='supplement/frontend';cand='UI-01;UI-03;UI-04'
        else:owner='api-db';cand='該当serviceのAP台帳参照（全actionが改善対象という意味ではない）'
        assert path in refs,path
    else:detail='framework生成のstorage/health入口。設定/経路構造確認、vendor内部性能は対象外';owner='framework/config'
    route_rows.append({'method':r['method'],'uri':r['uri'],'action':a,'path':path,'owner':owner,'inspection':detail,'candidate_scope':cand,'coverage_refs':';'.join(sorted(refs[path])) if path else 'supplement-coverage.csv','source_sha':sha})
save('route-coverage.csv',route_rows)
commands=[]
for p in sorted((root/'product/app/Console/Commands').glob('*.php')):
    s=p.read_text();m=re.search(r'\$signature\s*=\s*[\'\"]([^\'\"\s]+)',s);line=s[:m.start()].count('\n')+1 if m else 0
    commands.append({'signature':m[1] if m else '', 'path':str(p.relative_to(root)),'line':line,'inspection':'入口と呼出先の静的照合','validation':'Turn代表以外は実command未実行（mutationを調査目的で実行しない）','coverage_refs':';'.join(sorted(refs[str(p.relative_to(root))])),'source_sha':sha})
save('console-coverage.csv',commands)
summary={'source_files':len(census),'app_php_files':sum(x['path'].startswith('product/app/') for x in census),'frontend_source_files':len(fronts),'named_symbols':len(read('symbols.csv')),'http_entries':len(routes),'app_http_entries':sum(x['action'].startswith('App\\') for x in routes),'framework_entries':sum(not x['action'].startswith('App\\') for x in routes),'console_commands':len(commands),'canonical_turn_phases':12,'database_tables':len(read('api-db-indexes.csv')),'source_coverage_without_reference':sum(not x['coverage_refs'] for x in sources),'families':dict(collections.Counter(x['family'] for x in census)),'meaning':'静的入口/構造の全件棚卸し。全分岐実行率ではない。runtime未確認は台帳へ明記。'}
(out/'coverage-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False))
