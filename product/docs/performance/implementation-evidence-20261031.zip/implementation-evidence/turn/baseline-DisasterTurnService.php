<?php

namespace App\Application;

use App\Domain\Disaster\LandSubsidenceThresholdResolver;
use App\Domain\Facility\FacilityRankPolicy;
use App\Domain\Map\GridCoordinate;
use App\Domain\Map\MapCellStateService;
use App\Domain\Map\NationLandAreaCalculator;
use App\Domain\Map\SeaAreaNameResolver;
use App\Domain\Nation\NationProtectionPolicy;
use App\Domain\Ship\SurfaceShipTurnBatch;
use App\Domain\Turn\DeterministicRandomStream;
use App\Domain\Turn\TurnContext;
use App\Domain\Turn\TurnRandomStreamFactory;
use App\Models\MapCell;
use App\Models\MapSpace;
use App\Models\Nation;
use App\Models\NationCommandQueueItem;
use App\Models\Ship;
use App\Models\TerrainDefinition;
use DomainException;
use Illuminate\Database\Eloquent\Collection;

final class DisasterTurnService
{
    public function __construct(
        private readonly MapCellStateService $cells,
        private readonly TurnEventRecorder $events,
        private readonly NationLandAreaCalculator $landArea,
        private readonly LandSubsidenceThresholdResolver $subsidenceThreshold,
        private readonly MonsterRemovalService $monsterRemoval,
        private readonly MonsterSpawnService $monsterSpawn,
        private readonly MonsterWorldSpawnService $monsterWorldSpawn,
        private readonly NationProtectionPolicy $nationProtection,
        private readonly SurfaceShipRemovalService $shipRemoval,
        private readonly FacilityRankPolicy $facilityRanks,
        private readonly FacilityScaleDamageService $facilityScaleDamage,
        private readonly CentralFacilityDamageService $centralFacilityDamage,
        private readonly WorldDisasterOpportunityService $worldOpportunities,
        private readonly NpcShipSpawnService $npcShipSpawn,
        private readonly BuriedTreasureService $buriedTreasures,
        private readonly SecretaryDisasterCharmService $charms,
        private readonly SeaAreaWeatherService $weather,
        private readonly SeaAreaNameResolver $seaAreas,
    ) {}

    /** @return array<string, int> */
    public function executeGlobal(TurnContext $context): array
    {
        $this->monsterRemoval->beginWorld($context);
        $rules = $this->rules($context);
        $metrics = [
            'executed_disasters' => 0,
            'damaged_cells' => 0,
            'land_subsidence_nations' => 0,
            'land_subsidence_changed_to_sea' => 0,
            'land_subsidence_changed_to_shallow' => 0,
            'land_subsidence_protected_mountains' => 0,
            'land_subsidence_capitals_damaged' => 0,
            'land_subsidence_central_facilities_damaged' => 0,
            'land_subsidence_affected_chunks' => 0,
            'eligible_spawn_nations' => 0,
            'spawn_draws' => 0,
            'monsters_spawned' => 0,
            'blocked_no_settlement' => 0,
            'monsters_removed_by_terrain' => 0,
        ];
        $space = $this->surfaceSpace($context);
        $this->weather->draw($context, $space);
        $cellIndex = null;

        $definitions = [
            'earthquake' => [TurnRandomStreamFactory::GLOBAL_EARTHQUAKE_TRIGGER, TurnRandomStreamFactory::GLOBAL_EARTHQUAKE_CENTER],
            'tsunami' => [TurnRandomStreamFactory::GLOBAL_TSUNAMI_TRIGGER, TurnRandomStreamFactory::GLOBAL_TSUNAMI_CENTER],
            'eruption' => [TurnRandomStreamFactory::GLOBAL_ERUPTION_TRIGGER, TurnRandomStreamFactory::GLOBAL_ERUPTION_CENTER],
        ];

        foreach ($definitions as $key => [$triggerLabel, $centerLabel]) {
            if ($key === 'eruption') {
                $weatherMetrics = $this->executeWeatherDisasters($context, $space, $rules, $cellIndex);
                $metrics['executed_disasters'] += $weatherMetrics['executed_disasters'];
                $metrics['damaged_cells'] += $weatherMetrics['damaged_cells'];
            }
            $settings = $rules[$key];
            $worldOpportunity = $this->worldOpportunities->resolve($context, $space, $key);

            for ($opportunity = 1; $opportunity <= $worldOpportunity['count']; $opportunity++) {
                $trigger = $this->probabilityDraw($context, $settings['probability'], $triggerLabel);
                if (! $trigger['success']) {
                    continue;
                }
                $center = $this->center($context, $space, $settings['center_padding'], $centerLabel);
                $isFractional = $opportunity > $worldOpportunity['full'];
                $this->events->record($context, 'disaster.triggered', $context->world, [
                    'disaster_key' => $key,
                    'center_x' => $center->x,
                    'center_y' => $center->y,
                    'draw' => $trigger['draw'],
                    'numerator' => $settings['probability']['numerator'],
                    'denominator' => $settings['probability']['denominator'],
                    'world_chunk_count' => $worldOpportunity['chunk_count'],
                    'world_scale_numerator' => $worldOpportunity['scale_numerator'],
                    'world_scale_denominator' => 225,
                    'world_opportunity_index' => $opportunity,
                    'world_opportunity_kind' => $isFractional ? 'fractional' : 'integer',
                    'world_fractional_gate_draw' => $isFractional ? $worldOpportunity['fractional_draw'] : null,
                    'world_fractional_gate_numerator' => $worldOpportunity['fractional_numerator'],
                ]);
                $metrics['executed_disasters']++;
                $cellIndex ??= $this->newMutableCellIndex($context);
                $radius = (int) $settings['radius'];
                if ($key === 'tsunami') {
                    $radius++;
                }
                $this->loadRadiusCells($space, $center, $radius, $cellIndex);
                $metrics['damaged_cells'] += match ($key) {
                    'earthquake' => $this->earthquake(
                        $context,
                        $space,
                        $center,
                        $settings,
                        TurnRandomStreamFactory::GLOBAL_EARTHQUAKE_EFFECT,
                        'global',
                        $cellIndex,
                    ),
                    'tsunami' => $this->tsunami($context, $space, $center, $settings, $cellIndex),
                    'eruption' => $this->eruption($context, $space, $center, $settings, $cellIndex),
                };
            }
        }

        $subsidence = $this->landSubsidence(
            $context,
            $space,
            $rules['land_subsidence'] ?? null,
            $cellIndex,
        );
        $metrics['executed_disasters'] += $subsidence['triggered_nations'];
        $metrics['damaged_cells'] += $subsidence['changed_to_sea']
            + $subsidence['changed_to_shallow']
            + $subsidence['capitals_damaged']
            + $subsidence['central_facilities_damaged'];
        $metrics['land_subsidence_nations'] = $subsidence['triggered_nations'];
        $metrics['land_subsidence_changed_to_sea'] = $subsidence['changed_to_sea'];
        $metrics['land_subsidence_changed_to_shallow'] = $subsidence['changed_to_shallow'];
        $metrics['land_subsidence_protected_mountains'] = $subsidence['protected_mountains'];
        $metrics['land_subsidence_capitals_damaged'] = $subsidence['capitals_damaged'];
        $metrics['land_subsidence_central_facilities_damaged'] = $subsidence['central_facilities_damaged'];
        $metrics['land_subsidence_affected_chunks'] = $subsidence['affected_chunks'];

        foreach ($this->monsterWorldSpawn->spawn($context, $space) as $key => $value) {
            $metrics[$key] = $value;
        }
        foreach ($this->npcShipSpawn->spawn($context, $space) as $key => $value) {
            $metrics[$key] = $value;
        }
        foreach ($this->buriedTreasures->spawnNatural($context, $space) as $key => $value) {
            $metrics[$key] = $value;
        }
        foreach ($this->monsterSpawn->spawnNatural($context, $space) as $key => $value) {
            $metrics[$key] = $value;
        }
        $metrics['monsters_removed_by_terrain'] = $this->monsterRemoval->removedCount();

        return $metrics;
    }

    /**
     * @param  array<string, array<string, mixed>>  $rules
     * @return array{executed_disasters: int, damaged_cells: int}
     */
    private function executeWeatherDisasters(
        TurnContext $context,
        MapSpace $space,
        array $rules,
        ?DisasterMutableCellIndex &$cellIndex,
    ): array {
        $regions = array_filter($context->state->seaAreaWeather(),
            static fn (array $region): bool => in_array($region['weather_key'], ['typhoon', 'meteor_shower'], true));
        $centers = $context->state->weatherHugeMeteorCenters();
        $metrics = ['executed_disasters' => 0, 'damaged_cells' => 0];
        if ($regions === [] && $centers === []) {
            return $metrics;
        }
        $cellIndex ??= $this->newMutableCellIndex($context);
        // One load for weather areas + windbreak halos and all huge meteor blasts, clipped to the World.
        $cells = MapCell::query()->where('map_space_id', $space->id)
            ->whereBetween('x', [$space->min_x, $space->max_x])
            ->whereBetween('y', [$space->min_y, $space->max_y])
            ->where(function ($query) use ($regions, $centers): void {
                foreach ($regions as $region) {
                    $query->orWhere(function ($area) use ($region): void {
                        $area->whereBetween('x', [$region['min_x'] - 1, $region['max_x'] + 1])
                            ->whereBetween('y', [$region['min_y'] - 1, $region['max_y'] + 1]);
                    });
                }
                foreach ($centers as $center) {
                    $query->orWhere(function ($blast) use ($center): void {
                        $blast->whereBetween('x', [$center->x - 2, $center->x + 2])
                            ->whereBetween('y', [$center->y - 2, $center->y + 2]);
                    });
                }
            })->orderBy('id')->lockForUpdate()->with(['terrain', 'facility'])->get();
        $cellIndex->addCells($cells);
        $ships = null;
        foreach ($regions as $region) {
            $key = $region['weather_key'];
            $coordinates = [];
            foreach (range($region['min_y'], $region['max_y']) as $y) {
                foreach (range($region['min_x'], $region['max_x']) as $x) {
                    if ($cellIndex->cellAt($x, $y) !== null) {
                        $coordinates[] = new GridCoordinate($x, $y);
                    }
                }
            }
            if ($coordinates === []) {
                continue;
            }
            $metadata = [
                'disaster_key' => $key,
                'sea_area_name' => $this->seaAreas->forCoordinate($region['min_x'], $region['min_y']),
                'chunk_x' => $region['chunk_x'], 'chunk_y' => $region['chunk_y'],
                'min_x' => $region['min_x'], 'max_x' => $region['max_x'],
                'min_y' => $region['min_y'], 'max_y' => $region['max_y'],
            ];
            $this->events->record($context, 'disaster.triggered', $context->world, $metadata);
            $stream = $context->random->stream(TurnRandomStreamFactory::seaAreaWeatherEffect(
                $key, $region['chunk_x'], $region['chunk_y'],
                $context->ruleset->settings['turn_processing']['sea_area_weather']['stream_version'],
            ));
            // Preserve the existing per-hit effects; only the target domain and stream change.
            $origin = new GridCoordinate($region['min_x'], $region['min_y']);
            if ($key === 'typhoon') {
                $metrics['damaged_cells'] += $this->typhoon($context, $space, $origin, $rules[$key], $cellIndex, $coordinates, $stream);
            } else {
                $ships ??= $this->shipRemoval->lockActiveWorldIndex($context);
                $metrics['damaged_cells'] += $this->meteorShower($context, $space, $origin, $rules[$key], $cellIndex, $coordinates, $stream, $ships);
            }
            $metrics['executed_disasters']++;
        }
        if ($centers !== []) {
            $ships ??= $this->shipRemoval->lockActiveWorldIndex($context);
            $shipBatch = new SurfaceShipTurnBatch($ships->filter(static fn (Ship $ship): bool => $ship->state === Ship::STATE_ACTIVE), []);
            foreach ($centers as $center) {
                // Keep the old center-based player log, including centers in the outside border.
                $this->events->record($context, 'disaster.triggered', $context->world, [
                    'disaster_key' => 'huge_meteor', 'center_x' => $center->x, 'center_y' => $center->y,
                ]);
                $metrics['damaged_cells'] += $this->resolveHugeMeteorBlast(
                    $context, $space, $center, $rules['huge_meteor'],
                    cellIndex: $cellIndex, shipBatch: $shipBatch, createBuriedTreasure: true,
                );
                $metrics['executed_disasters']++;
            }
        }

        return $metrics;
    }

    /**
     * @return array{
     *     triggered_nations: int,
     *     changed_to_sea: int,
     *     changed_to_shallow: int,
     *     protected_mountains: int,
     *     capitals_damaged: int,
     *     central_facilities_damaged: int,
     *     affected_chunks: int
     * }
     */
    private function landSubsidence(
        TurnContext $context,
        MapSpace $space,
        mixed $authoredSettings,
        ?DisasterMutableCellIndex $cellIndex = null,
    ): array {
        $settings = $this->landSubsidenceSettings($authoredSettings);
        $empty = [
            'triggered_nations' => 0,
            'changed_to_sea' => 0,
            'changed_to_shallow' => 0,
            'protected_mountains' => 0,
            'capitals_damaged' => 0,
            'central_facilities_damaged' => 0,
            'affected_chunks' => 0,
        ];
        if (! $settings['enabled']) {
            return $empty;
        }
        $centralFacilityKeys = $this->centralFacilityDisasterContract($context)['facility_keys'];

        $nations = Nation::query()
            ->where('world_id', $context->world->id)
            ->whereIn('state', ['active', 'dormant', 'recovery'])
            ->orderBy('id')
            ->get();
        $landByNation = $this->landArea->forNationIds(
            $context->world,
            $nations->pluck('id')->map(static fn ($id): int => (int) $id)->all(),
        );
        /** @var array<int, array{nation: Nation, owned_land_cells: int, threshold: int, draw: int, to_sea: array<int, true>, to_shallow: array<int, true>, protected_mountains: array<int, true>, capitals: array<int, true>, central_facilities: array<int, true>}> $plans */
        $plans = [];
        foreach ($nations as $nation) {
            $ownedLandCells = $landByNation[$nation->id] ?? 0;
            $threshold = $this->subsidenceThreshold->resolve($context->ruleset, $nation);
            if ($ownedLandCells <= $threshold) {
                continue;
            }
            $trigger = $this->probabilityDraw(
                $context,
                $settings['probability'],
                TurnRandomStreamFactory::landSubsidenceTrigger($nation->id, $settings['stream_version']),
            );
            if (! $trigger['success']) {
                continue;
            }
            $plans[$nation->id] = [
                'nation' => $nation,
                'owned_land_cells' => $ownedLandCells,
                'threshold' => $threshold,
                'draw' => $trigger['draw'],
                'to_sea' => [],
                'to_shallow' => [],
                'protected_mountains' => [],
                'capitals' => [],
                'central_facilities' => [],
            ];
        }
        if ($plans === []) {
            return $empty;
        }

        $cellIndex ??= $this->newMutableCellIndex($context);
        $this->loadAllCells($space, $cellIndex);
        $cells = $cellIndex->cells();
        /** @var array<int, MapCell> $cellsById */
        $cellsById = [];
        /** @var array<string, array{id: int, x: int, y: int, map_chunk_id: int, terrain_key: string, facility_key: string|null, owner_nation_id: int|null, population: int}> $snapshot */
        $snapshot = [];
        foreach ($cells as $cell) {
            $cellsById[$cell->id] = $cell;
            $snapshot[$cell->x.':'.$cell->y] = [
                'id' => $cell->id,
                'x' => $cell->x,
                'y' => $cell->y,
                'map_chunk_id' => $cell->map_chunk_id,
                'terrain_key' => $cell->terrain->key,
                'facility_key' => $cell->facility?->key,
                'owner_nation_id' => $cell->owner_nation_id,
                'population' => $cell->population,
            ];
        }

        foreach ($plans as $nationId => &$plan) {
            foreach ($snapshot as $cellSnapshot) {
                if ($cellSnapshot['owner_nation_id'] !== $nationId
                    || in_array($cellSnapshot['terrain_key'], ['sea', 'shallow'], true)) {
                    continue;
                }

                $coastal = false;
                $origin = new GridCoordinate($cellSnapshot['x'], $cellSnapshot['y']);
                foreach (array_keys(GridCoordinate::DIRECTION_NAMES) as $direction) {
                    $coordinate = $origin->neighbor($direction);
                    if ($coordinate->x < $space->min_x || $coordinate->x > $space->max_x
                        || $coordinate->y < $space->min_y || $coordinate->y > $space->max_y) {
                        $coastal = true;

                        continue;
                    }
                    $neighbor = $snapshot[$coordinate->x.':'.$coordinate->y] ?? null;
                    if ($neighbor === null || ! in_array($neighbor['terrain_key'], ['sea', 'shallow'], true)) {
                        continue;
                    }
                    $coastal = true;
                    if ($neighbor['terrain_key'] === 'shallow'
                        && in_array($neighbor['owner_nation_id'], [null, $nationId], true)) {
                        $plan['to_sea'][$neighbor['id']] = true;
                    }
                }
                if (! $coastal) {
                    continue;
                }
                if (in_array($cellSnapshot['facility_key'], $centralFacilityKeys, true)) {
                    $plan['central_facilities'][$cellSnapshot['id']] = true;
                } elseif ($cellSnapshot['terrain_key'] === 'mountain') {
                    $plan['protected_mountains'][$cellSnapshot['id']] = true;
                } elseif ($cellSnapshot['facility_key'] === 'capital') {
                    $plan['capitals'][$cellSnapshot['id']] = true;
                } else {
                    $plan['to_shallow'][$cellSnapshot['id']] = true;
                }
            }
        }
        unset($plan);

        /** @var array<int, array<int, true>> $seaAffectedNations */
        $seaAffectedNations = [];
        foreach ($plans as $nationId => $plan) {
            foreach (array_keys($plan['to_sea']) as $cellId) {
                $seaAffectedNations[$cellId][$nationId] = true;
            }
        }

        $changedToSea = 0;
        $changedToShallow = 0;
        $protectedMountains = 0;
        $capitalsDamaged = 0;
        $centralFacilitiesDamaged = 0;
        /** @var array<int, int> $changedToSeaByNation */
        $changedToSeaByNation = [];
        /** @var array<int, int> $changedToShallowByNation */
        $changedToShallowByNation = [];
        /** @var array<int, int> $centralFacilitiesDamagedByNation */
        $centralFacilitiesDamagedByNation = [];
        /** @var array<int, array<int, true>> $affectedChunkIdsByNation */
        $affectedChunkIdsByNation = [];
        /** @var array<int, true> $affectedChunks */
        $affectedChunks = [];
        $seaCellIds = array_keys($seaAffectedNations);
        sort($seaCellIds, SORT_NUMERIC);
        foreach ($seaCellIds as $cellId) {
            $affectedNationIds = array_map('intval', array_keys($seaAffectedNations[$cellId]));
            sort($affectedNationIds, SORT_NUMERIC);
            if ($this->changeCell(
                $context,
                $cellsById[$cellId],
                'land_subsidence',
                $settings['affected_shallow_result'],
                true,
                'disaster.cell_damaged',
                ['source' => 'land_subsidence', 'affected_nation_ids' => $affectedNationIds],
                $cellIndex,
            )) {
                $changedToSea++;
                $chunkId = (int) $cellsById[$cellId]->map_chunk_id;
                $affectedChunks[$chunkId] = true;
                foreach ($affectedNationIds as $affectedNationId) {
                    $changedToSeaByNation[$affectedNationId] = ($changedToSeaByNation[$affectedNationId] ?? 0) + 1;
                    $affectedChunkIdsByNation[$affectedNationId][$chunkId] = true;
                }
            }
        }

        /** @var array<int, list<array{before_population: int, after_population: int, damage_percent: int}>> $capitalDamageByNation */
        $capitalDamageByNation = [];
        foreach ($plans as $nationId => $plan) {
            $protectedMountains += count($plan['protected_mountains']);
            $centralCellIds = array_keys($plan['central_facilities']);
            sort($centralCellIds, SORT_NUMERIC);
            foreach ($centralCellIds as $cellId) {
                if ($this->applyCentralFacilityDisasterDamage(
                    $context,
                    $cellsById[$cellId],
                    'land_subsidence',
                ) === true) {
                    $centralFacilitiesDamaged++;
                    $centralFacilitiesDamagedByNation[$nationId] = ($centralFacilitiesDamagedByNation[$nationId] ?? 0) + 1;
                    $chunkId = (int) $cellsById[$cellId]->map_chunk_id;
                    $affectedChunks[$chunkId] = true;
                    $affectedChunkIdsByNation[$nationId][$chunkId] = true;
                }
            }
            $landCellIds = array_keys($plan['to_shallow']);
            sort($landCellIds, SORT_NUMERIC);
            foreach ($landCellIds as $cellId) {
                if ($this->changeCell(
                    $context,
                    $cellsById[$cellId],
                    'land_subsidence',
                    $settings['affected_coastal_land_result'],
                    true,
                    'disaster.cell_damaged',
                    ['source' => 'land_subsidence'],
                    $cellIndex,
                )) {
                    $changedToShallow++;
                    $changedToShallowByNation[$nationId] = ($changedToShallowByNation[$nationId] ?? 0) + 1;
                    $chunkId = (int) $cellsById[$cellId]->map_chunk_id;
                    $affectedChunks[$chunkId] = true;
                    $affectedChunkIdsByNation[$nationId][$chunkId] = true;
                }
            }
            $capitalCellIds = array_keys($plan['capitals']);
            sort($capitalCellIds, SORT_NUMERIC);
            foreach ($capitalCellIds as $cellId) {
                $capitalDamage = $this->damageCapitalByPercentage(
                    $context,
                    $cellsById[$cellId],
                    'land_subsidence',
                    $settings['capital_damage_percentage'],
                    ['source' => 'land_subsidence'],
                );
                if ($capitalDamage['damage_percent'] > 0) {
                    $capitalDamageByNation[$nationId][] = $capitalDamage;
                    $capitalsDamaged++;
                    $chunkId = (int) $cellsById[$cellId]->map_chunk_id;
                    $affectedChunks[$chunkId] = true;
                    $affectedChunkIdsByNation[$nationId][$chunkId] = true;
                }
            }
        }

        foreach ($plans as $nationId => $plan) {
            $this->events->record($context, 'land_subsidence.triggered', $plan['nation'], [
                'disaster_key' => 'land_subsidence',
                'nation_id' => $nationId,
                'nation_number' => $plan['nation']->nation_number,
                'owned_land_cells_before' => $plan['owned_land_cells'],
                'effective_safe_land_cells' => $plan['threshold'],
                'changed_to_sea_count' => $changedToSeaByNation[$nationId] ?? 0,
                'changed_to_shallow_count' => $changedToShallowByNation[$nationId] ?? 0,
                'protected_mountain_count' => count($plan['protected_mountains']),
                'capital_damage' => $capitalDamageByNation[$nationId] ?? [],
                'central_facility_damage_count' => $centralFacilitiesDamagedByNation[$nationId] ?? 0,
                'affected_chunk_count' => count($affectedChunkIdsByNation[$nationId] ?? []),
                'draw' => $plan['draw'],
                'numerator' => $settings['probability']['numerator'],
                'denominator' => $settings['probability']['denominator'],
                'snapshot_applied' => true,
            ]);
        }

        return [
            'triggered_nations' => count($plans),
            'changed_to_sea' => $changedToSea,
            'changed_to_shallow' => $changedToShallow,
            'protected_mountains' => $protectedMountains,
            'capitals_damaged' => $capitalsDamaged,
            'central_facilities_damaged' => $centralFacilitiesDamaged,
            'affected_chunks' => count($affectedChunks),
        ];
    }

    public function landLevelEarthquake(
        TurnContext $context,
        NationCommandQueueItem $item,
        int $x,
        int $y,
    ): bool {
        $settings = $context->ruleset->settings['turn_processing']['command_random_effects']['land_level_earthquake'] ?? null;
        if (! is_array($settings)) {
            throw new DomainException('The active ruleset is missing land_level earthquake settings.');
        }
        $trigger = $this->probabilityDraw(
            $context,
            $settings['probability'],
            TurnRandomStreamFactory::LAND_LEVEL_EARTHQUAKE_TRIGGER,
        );
        if (! $trigger['success']) {
            return false;
        }

        $this->events->record($context, 'command.land_level_earthquake', $item, [
            'nation_id' => $item->queue()->value('nation_id'),
            'command_key' => 'land_level',
            'disaster_key' => 'earthquake',
            'center_x' => $x,
            'center_y' => $y,
            'draw' => $trigger['draw'],
            'numerator' => $settings['probability']['numerator'],
            'denominator' => $settings['probability']['denominator'],
        ]);
        $this->earthquake(
            $context,
            $this->surfaceSpace($context),
            new GridCoordinate($x, $y),
            $settings,
            TurnRandomStreamFactory::LAND_LEVEL_EARTHQUAKE_EFFECT,
            'land_level',
        );

        return true;
    }

    public function processFire(
        TurnContext $context,
        MapCell $cell,
        ?DisasterMutableCellIndex $cellIndex = null,
    ): bool {
        if ($this->monsterRemoval->hasAtCell($context, $cell->id)) {
            return false;
        }
        $rules = $this->rules($context);
        $settings = $rules['fire'];
        $facilityKey = $cell->facility?->key;
        if ($this->facilityRanks->largeCityImmuneToDisaster($context->ruleset->settings, $facilityKey, (int) $cell->population, 'fire')) {
            return false;
        }
        $unprotectedSeaFacility = in_array(
            $facilityKey,
            $settings['unprotected_sea_facility_keys'] ?? [],
            true,
        );
        $settlement = in_array($facilityKey, ['village', 'town', 'city', 'capital'], true)
            && $cell->population >= $settings['minimum_city_population'];
        if (! $unprotectedSeaFacility
            && ! $settlement
            && ! in_array($facilityKey, $settings['facility_keys'], true)) {
            return false;
        }

        $protection = $unprotectedSeaFacility ? 0 : $this->adjacentProtectionCount(
            $cell,
            $this->forestProtectionFacilityKeys($context, 'fire', $settings['protection_facility_keys']),
            $cellIndex,
        );
        if ($protection > 0) {
            if ($cell->owner_nation_id !== null) {
                $context->state->addRoutineSummaryMetric(
                    (int) $cell->owner_nation_id,
                    'fire_protection_checks',
                );
            }

            return false;
        }

        $trigger = $this->probabilityDraw($context, $settings['probability'], TurnRandomStreamFactory::FIRE);
        if (! $trigger['success']) {
            return false;
        }
        if ($this->nationProtection->protectsFromDisaster($context, $cell->x, $cell->y)) {
            return false;
        }
        if ($this->charms->protect($context, $cell, 'fire')) {
            return false;
        }
        if ($unprotectedSeaFacility && $this->protectUnderseaFire($context, $cell, $settings, $cellIndex)) {
            return false;
        }
        if ($this->isCapital($cell)) {
            $this->damageCapital($context, $cell, 'fire', 'facility_or_wasteland', [
                'draw' => $trigger['draw'],
                'source' => 'process_cells',
            ]);

            return true;
        }
        if ($unprotectedSeaFacility) {
            $this->changeCell($context, $cell, 'fire', 'sea', true, 'fire.undersea_city_destroyed', [
                'draw' => $trigger['draw'],
                'numerator' => $settings['probability']['numerator'],
                'denominator' => $settings['probability']['denominator'],
            ], $cellIndex, 'private');

            return true;
        }

        if ($facilityKey === 'factory') {
            $facilityDamage = $this->facilityScaleDamage->apply(
                $context,
                $cell,
                FacilityRankPolicy::FIRE,
                'fire',
                [
                    'disaster_key' => 'fire',
                    'draw' => $trigger['draw'],
                    'numerator' => $settings['probability']['numerator'],
                    'denominator' => $settings['probability']['denominator'],
                ],
            );
            if ($facilityDamage !== null && $facilityDamage['scale_loss'] > 0) {
                return true;
            }
        }
        $this->changeCell($context, $cell, 'fire', 'wasteland', false, 'fire.damaged', [
            'draw' => $trigger['draw'],
            'numerator' => $settings['probability']['numerator'],
            'denominator' => $settings['probability']['denominator'],
        ], $cellIndex);

        return true;
    }

    /** @param array<string, mixed> $settings */
    private function protectUnderseaFire(
        TurnContext $context,
        MapCell $cell,
        array $settings,
        ?DisasterMutableCellIndex $cellIndex,
    ): bool {
        $protection = $settings['undersea_protection'] ?? null;
        if (! is_array($protection)) {
            return false;
        }
        $radius = (int) $protection['radius'];
        $cost = (int) $protection['cost_money'];
        $origin = new GridCoordinate((int) $cell->x, (int) $cell->y);
        $candidates = $cellIndex?->cells() ?? MapCell::query()
            ->where('map_space_id', $cell->map_space_id)
            ->whereBetween('x', [$cell->x - $radius, $cell->x + $radius])
            ->whereBetween('y', [$cell->y - $radius, $cell->y + $radius])
            ->whereHas('facility', fn ($query) => $query->where('key', $protection['facility_key']))
            ->orderBy('id')->lockForUpdate()->with('facility')->get()->all();
        foreach ($candidates as $station) {
            if ($station->facility?->key !== $protection['facility_key']
                || $station->owner_nation_id === null
                || $station->owner_nation_id !== $cell->owner_nation_id
                || $origin->distanceTo(new GridCoordinate((int) $station->x, (int) $station->y)) > $radius) {
                continue;
            }
            $payer = Nation::query()->whereKey($station->owner_nation_id)
                ->whereIn('state', ['active', 'recovery'])->lockForUpdate()->first();
            if ($payer === null || (int) $payer->money < $cost) {
                continue;
            }
            $payer->decrement('money', $cost);
            // The first affordable station settles the single fire. Never charge overlaps twice.
            $this->events->record($context, 'fire.extinguished_undersea', $cell, [
                'nation_id' => $cell->owner_nation_id, 'x' => $cell->x, 'y' => $cell->y,
                'cost_money' => $cost,
            ], 'private');

            return true;
        }

        return false;
    }

    /** @param array<string, mixed> $settings */
    private function earthquake(
        TurnContext $context,
        MapSpace $space,
        GridCoordinate $center,
        array $settings,
        string $effectLabel,
        string $source,
        ?DisasterMutableCellIndex $cellIndex = null,
    ): int {
        $damaged = 0;
        foreach ($center->radius($settings['radius']) as $coordinate) {
            $cell = $this->cellAt($space, $coordinate, $cellIndex);
            if ($cell === null || ! $this->isMutable($cell, $cellIndex)) {
                continue;
            }
            if ($this->monsterRemoval->hasAtCell($context, $cell->id)) {
                continue;
            }
            $facilityKey = $cell->facility?->key;
            if ($this->facilityRanks->largeCityImmuneToDisaster($context->ruleset->settings, $facilityKey, (int) $cell->population, 'earthquake')) {
                continue;
            }
            $city = in_array($facilityKey, ['village', 'town', 'city', 'capital'], true)
                && $cell->population >= $settings['minimum_city_population'];
            if (! $city && ! in_array($facilityKey, $settings['facility_keys'], true)) {
                continue;
            }
            $draw = $this->probabilityDraw($context, $settings['damage_probability'], $effectLabel);
            if (! $draw['success']) {
                continue;
            }
            if ($this->nationProtection->protectsFromDisaster($context, $cell->x, $cell->y)) {
                continue;
            }
            if ($this->charms->protect($context, $cell, 'earthquake')) {
                continue;
            }
            if ($this->isCapital($cell)) {
                $this->damageCapital($context, $cell, 'earthquake', 'facility_or_wasteland', [
                    'source' => $source,
                    'center_x' => $center->x,
                    'center_y' => $center->y,
                    'draw' => $draw['draw'],
                ]);
            } else {
                if ($facilityKey === 'factory') {
                    $facilityDamage = $this->facilityScaleDamage->apply(
                        $context,
                        $cell,
                        FacilityRankPolicy::EARTHQUAKE,
                        'earthquake',
                        [
                            'disaster_key' => 'earthquake',
                            'source' => $source,
                            'center_x' => $center->x,
                            'center_y' => $center->y,
                            'draw' => $draw['draw'],
                        ],
                    );
                    if ($facilityDamage !== null && $facilityDamage['scale_loss'] > 0) {
                        $damaged++;

                        continue;
                    }
                }
                $this->changeCell($context, $cell, 'earthquake', 'wasteland', false, 'disaster.cell_damaged', [
                    'source' => $source,
                    'center_x' => $center->x,
                    'center_y' => $center->y,
                    'draw' => $draw['draw'],
                ], $cellIndex);
            }
            $damaged++;
        }

        return $damaged;
    }

    /** @param array<string, mixed> $settings */
    private function tsunami(
        TurnContext $context,
        MapSpace $space,
        GridCoordinate $center,
        array $settings,
        DisasterMutableCellIndex $cellIndex,
    ): int {
        $damaged = 0;
        foreach ($center->radius($settings['radius']) as $coordinate) {
            $cell = $this->cellAt($space, $coordinate, $cellIndex);
            if ($cell === null || ! $this->isMutable($cell, $cellIndex)
                || (! $this->isTsunamiTarget($cell, $settings)
                    && ! $this->centralFacilityDamage->isCentral($context, $cell))) {
                continue;
            }
            if ($this->monsterRemoval->hasAtCell($context, $cell->id)) {
                continue;
            }
            $water = $this->adjacentWaterCount($cell, $space, $settings['water_facility_keys'], $cellIndex);
            $draw = $context->random->stream(TurnRandomStreamFactory::GLOBAL_TSUNAMI_EFFECT)
                ->integer(0, $settings['internal_denominator'] - 1);
            if ($draw >= max(0, $water - $settings['adjacent_water_offset'])) {
                continue;
            }
            if ($this->nationProtection->protectsFromDisaster($context, $cell->x, $cell->y)) {
                continue;
            }
            if ($this->charms->protect($context, $cell, 'tsunami')) {
                continue;
            }
            $centralDamage = $this->applyCentralFacilityDisasterDamage($context, $cell, 'tsunami');
            if ($centralDamage !== null) {
                $damaged += $centralDamage ? 1 : 0;

                continue;
            }
            if ($this->isCapital($cell)) {
                $this->damageCapital($context, $cell, 'tsunami', 'facility_or_wasteland', [
                    'center_x' => $center->x, 'center_y' => $center->y,
                    'adjacent_water_count' => $water, 'draw' => $draw,
                ]);
            } else {
                $this->changeCell($context, $cell, 'tsunami', 'wasteland', false, 'disaster.cell_damaged', [
                    'center_x' => $center->x, 'center_y' => $center->y,
                    'adjacent_water_count' => $water, 'draw' => $draw,
                ], $cellIndex);
            }
            $damaged++;
        }

        return $damaged;
    }

    /**
     * @param  array<string, mixed>  $settings
     * @param  list<GridCoordinate>  $coordinates
     */
    private function typhoon(
        TurnContext $context,
        MapSpace $space,
        GridCoordinate $center,
        array $settings,
        DisasterMutableCellIndex $cellIndex,
        array $coordinates,
        DeterministicRandomStream $stream,
    ): int {
        $damaged = 0;
        foreach ($coordinates as $coordinate) {
            $cell = $this->cellAt($space, $coordinate, $cellIndex);
            if ($cell === null || ! $this->isMutable($cell, $cellIndex)
                || ! in_array($cell->facility?->key, $settings['facility_keys'], true)) {
                continue;
            }
            if ($this->monsterRemoval->hasAtCell($context, $cell->id)) {
                continue;
            }
            $protection = $this->adjacentProtectionCount(
                $cell,
                $this->forestProtectionFacilityKeys($context, 'typhoon', $settings['protection_facility_keys']),
                $cellIndex,
            );
            $draw = $stream->integer(0, $settings['internal_denominator'] - 1);
            $threshold = $settings['base_damage_threshold'];
            if ($cell->facility?->key === 'farm') {
                $rankTwoThreshold = $this->facilityRanks->rankTwoTyphoonThreshold(
                    $context->ruleset->settings,
                    'farm',
                    $cell->facility_scale,
                );
                if ($rankTwoThreshold !== null) {
                    $threshold = $rankTwoThreshold;
                }
            }
            if ($draw >= max(0, $threshold - $protection)) {
                continue;
            }
            if ($this->nationProtection->protectsFromDisaster($context, $cell->x, $cell->y)) {
                continue;
            }
            if ($this->charms->protect($context, $cell, 'typhoon')) {
                continue;
            }
            $this->changeCell($context, $cell, 'typhoon', 'plain', false, 'disaster.cell_damaged', [
                'center_x' => $center->x, 'center_y' => $center->y,
                'protection_count' => $protection, 'draw' => $draw,
            ], $cellIndex);
            $damaged++;
        }

        return $damaged;
    }

    /**
     * @param  array<string, mixed>  $settings
     * @param  list<GridCoordinate>  $coordinates
     * @param  Collection<int, Ship>  $ships
     */
    private function meteorShower(
        TurnContext $context,
        MapSpace $space,
        GridCoordinate $center,
        array $settings,
        DisasterMutableCellIndex $cellIndex,
        array $coordinates,
        DeterministicRandomStream $stream,
        Collection $ships,
    ): int {
        $damaged = 0;
        do {
            $coordinate = $coordinates[$stream->integer(0, count($coordinates) - 1)];
            $cell = $this->cellAt($space, $coordinate, $cellIndex);
            $createTreasure = false;
            if ($cell !== null && $this->isMutable($cell, $cellIndex)) {
                $nationallyProtected = $this->nationProtection->protectsFromDisaster($context, $cell->x, $cell->y);
                $damageable = $cell->terrain->key !== 'sea'
                    || in_array($cell->facility?->key, $settings['seabed_facility_keys'], true)
                    || $ships->get($cell->id) !== null;
                $charmProtected = ! $nationallyProtected && $damageable
                    && $this->charms->protect($context, $cell, 'meteor_shower');
                $createTreasure = ! $nationallyProtected && ! $charmProtected;
                $shipRemoved = ! $charmProtected && $this->shipRemoval->sinkLockedAtCell(
                    $context,
                    $cell,
                    $ships->get($cell->id),
                    'meteor_shower',
                    ['disaster_key' => 'meteor_shower'],
                ) !== null;
                if ($nationallyProtected || $charmProtected) {
                    // Keep the selected impact and continuation RNG opportunity, but apply no effect.
                    $damaged += $shipRemoved ? 1 : 0;
                } elseif ($this->isCapital($cell)) {
                    $this->damageCapital($context, $cell, 'meteor_shower', 'deep_sea', [
                        'population_damage_kind' => FacilityRankPolicy::LAND_DESTRUCTION,
                        'center_x' => $center->x, 'center_y' => $center->y,
                    ]);
                    $damaged++;
                } else {
                    $landTarget = $cell->terrain->key !== 'sea'
                        || in_array($cell->facility?->key, $settings['seabed_facility_keys'], true);
                    $monsterRemoved = false;
                    $facilityDamage = null;
                    $centralDamage = $this->applyCentralFacilityDisasterDamage(
                        $context,
                        $cell,
                        'meteor_shower',
                        metadata: ['center_x' => $center->x, 'center_y' => $center->y],
                    );
                    if ($centralDamage !== null) {
                        $damaged += ($centralDamage || $shipRemoved) ? 1 : 0;
                    } elseif ($landTarget && in_array($cell->facility?->key, ['farm', 'factory', 'mine'], true)) {
                        $monsterRemoved = $this->removeMonsterForTerrainEvent($context, $cell, 'meteor_shower');
                        $facilityDamage = $this->facilityScaleDamage->apply(
                            $context,
                            $cell,
                            FacilityRankPolicy::LAND_DESTRUCTION,
                            'meteor_shower',
                            [
                                'disaster_key' => 'meteor_shower',
                                'center_x' => $center->x,
                                'center_y' => $center->y,
                                'monster_removed' => $monsterRemoved,
                            ],
                        );
                    }
                    if ($centralDamage !== null) {
                        // The central-facility path above has already resolved this impact.
                    } elseif ($facilityDamage !== null && $facilityDamage['scale_loss'] > 0) {
                        $damaged++;
                    } elseif ($cell->terrain->key === 'shallow') {
                        if ($this->changeCell(
                            $context,
                            $cell,
                            'meteor_shower',
                            'sea',
                            true,
                            'disaster.cell_damaged',
                            cellIndex: $cellIndex,
                        )) {
                            $damaged++;
                        }
                    } elseif ($cell->terrain->key !== 'sea'
                        || in_array($cell->facility?->key, $settings['seabed_facility_keys'], true)) {
                        if ($this->changeCell(
                            $context,
                            $cell,
                            'meteor_shower',
                            'sea',
                            true,
                            'disaster.cell_damaged',
                            cellIndex: $cellIndex,
                        )) {
                            $damaged++;
                        }
                    } elseif ($shipRemoved) {
                        $damaged++;
                    }
                }
            }
            if ($createTreasure) {
                $this->buriedTreasures->create($context, $cell, 'meteor', false);
            }
            $continuation = $settings['continuation_probability'];
            $continueDraw = $stream->integer(0, $continuation['denominator'] - 1);
        } while ($continueDraw < $continuation['numerator']);

        return $damaged;
    }

    /**
     * @param  array<string, mixed>  $settings
     * @param  array<string, mixed>  $eventMetadata
     */
    public function resolveHugeMeteorBlast(
        TurnContext $context,
        MapSpace $space,
        GridCoordinate $center,
        array $settings,
        string $disasterKey = 'huge_meteor',
        array $eventMetadata = [],
        ?DisasterMutableCellIndex $cellIndex = null,
        ?SurfaceShipTurnBatch $shipBatch = null,
        bool $createBuriedTreasure = false,
    ): int {
        $damaged = 0;
        $ships = $shipBatch === null
            ? $this->shipRemoval->lockActiveWorldIndex($context)
            : null;
        $coordinates = [...$center->ring(0), ...$center->ring(1), ...$center->ring(2)];
        foreach ($coordinates as $coordinate) {
            $cell = $this->cellAt($space, $coordinate, $cellIndex);
            if ($cell === null || ! $this->isMutable($cell, $cellIndex)) {
                continue;
            }
            $distance = $center->distanceTo($coordinate);
            $ship = $shipBatch?->shipAt((int) $cell->id) ?? $ships?->get($cell->id);
            $shipRemoved = $this->shipRemoval->sinkLockedAtCell(
                $context,
                $cell,
                $ship,
                $disasterKey,
                ['disaster_key' => $disasterKey, ...$eventMetadata],
            ) !== null;
            if ($shipRemoved && $shipBatch !== null && $ship !== null) {
                $shipBatch->forget($ship, (int) $cell->id);
            }
            if ($this->nationProtection->protectsFromDisaster($context, $cell->x, $cell->y)) {
                $damaged += $shipRemoved ? 1 : 0;

                continue;
            }
            $centralDamage = $this->applyCentralFacilityDisasterDamage(
                $context,
                $cell,
                'huge_meteor',
                $distance,
                ['center_x' => $center->x, 'center_y' => $center->y, ...$eventMetadata],
            );
            if ($centralDamage !== null) {
                $damaged += ($centralDamage || $shipRemoved) ? 1 : 0;

                continue;
            }
            $monsterRemoved = false;
            if ($this->isCapital($cell)) {
                if ($distance === 0) {
                    $this->damageCapital($context, $cell, $disasterKey, 'deep_sea', $eventMetadata);
                } elseif ($distance === 1) {
                    $this->damageCapital($context, $cell, $disasterKey, 'excavation_or_shallow', [...$eventMetadata, 'population_damage_kind' => FacilityRankPolicy::LAND_DESTRUCTION]);
                } elseif ($this->hugeMeteorRingTwoTarget($cell, $settings)) {
                    $this->damageCapital($context, $cell, $disasterKey, 'facility_or_wasteland', [...$eventMetadata, 'population_damage_kind' => FacilityRankPolicy::ORDINARY_TERRAIN_DESTRUCTION]);
                } else {
                    continue;
                }
                $damaged++;

                continue;
            }
            if ($distance === 2) {
                $monsterRemoved = $this->removeMonsterForTerrainEvent($context, $cell, $disasterKey);
                if (! $this->hugeMeteorRingTwoTarget($cell, $settings)) {
                    $damaged += ($monsterRemoved || $shipRemoved) ? 1 : 0;

                    continue;
                }
                $facilityDamage = null;
                if (in_array($cell->facility?->key, ['farm', 'factory', 'mine'], true)) {
                    $facilityDamage = $this->facilityScaleDamage->apply(
                        $context,
                        $cell,
                        FacilityRankPolicy::ORDINARY_TERRAIN_DESTRUCTION,
                        $disasterKey,
                        [
                            'disaster_key' => $disasterKey,
                            'ring_distance' => 2,
                            'monster_removed' => $monsterRemoved,
                            ...$eventMetadata,
                        ],
                    );
                }
                if ($facilityDamage !== null) {
                    $damaged += $facilityDamage['scale_loss'] > 0 ? 1 : 0;

                    continue;
                }
                $changed = $this->changeCell(
                    $context,
                    $cell,
                    $disasterKey,
                    'wasteland',
                    false,
                    'disaster.cell_damaged',
                    [...$eventMetadata, 'population_damage_kind' => FacilityRankPolicy::ORDINARY_TERRAIN_DESTRUCTION],
                    $cellIndex,
                );
            } elseif ($cell->terrain->key === 'sea' || $cell->terrain->key === 'shallow'
                || in_array($cell->facility?->key, $settings['seabed_facility_keys'], true)) {
                $changed = $this->changeCell(
                    $context,
                    $cell,
                    $disasterKey,
                    'sea',
                    true,
                    'disaster.cell_damaged',
                    $eventMetadata,
                    $cellIndex,
                );
            } else {
                $facilityDamage = null;
                if ($distance === 1 && in_array($cell->facility?->key, ['farm', 'factory', 'mine'], true)) {
                    $monsterRemoved = $this->removeMonsterForTerrainEvent($context, $cell, $disasterKey);
                    $facilityDamage = $this->facilityScaleDamage->apply(
                        $context,
                        $cell,
                        FacilityRankPolicy::LAND_DESTRUCTION,
                        $disasterKey,
                        [
                            'disaster_key' => $disasterKey,
                            'ring_distance' => 1,
                            'monster_removed' => $monsterRemoved,
                            ...$eventMetadata,
                        ],
                    );
                }
                if ($facilityDamage !== null) {
                    $damaged += $facilityDamage['scale_loss'] > 0 ? 1 : 0;

                    continue;
                }
                $changed = $this->changeCell(
                    $context,
                    $cell,
                    $disasterKey,
                    $distance === 0 ? 'sea' : 'shallow',
                    true,
                    'disaster.cell_damaged',
                    $distance === 1 ? [...$eventMetadata, 'population_damage_kind' => FacilityRankPolicy::LAND_DESTRUCTION] : $eventMetadata,
                    $cellIndex,
                );
            }
            $damaged += ($changed || $monsterRemoved || $shipRemoved) ? 1 : 0;
        }

        if ($createBuriedTreasure) {
            $centerCell = $this->cellAt($space, $center, $cellIndex);
            if ($centerCell instanceof MapCell) {
                $this->buriedTreasures->create($context, $centerCell, 'huge_meteor', true);
            }
        }

        return $damaged;
    }

    /** @param array<string, mixed> $settings */
    private function eruption(
        TurnContext $context,
        MapSpace $space,
        GridCoordinate $center,
        array $settings,
        DisasterMutableCellIndex $cellIndex,
    ): int {
        $damaged = 0;
        $ships = $this->shipRemoval->lockActiveWorldIndex($context);
        $centerCell = $this->cellAt($space, $center, $cellIndex);
        if ($centerCell !== null && $this->isMutable($centerCell, $cellIndex)) {
            $shipRemoved = $this->shipRemoval->sinkLockedAtCell(
                $context,
                $centerCell,
                $ships->get($centerCell->id),
                'eruption',
                ['disaster_key' => 'eruption'],
            ) !== null;
            if ($this->nationProtection->protectsFromDisaster($context, $centerCell->x, $centerCell->y)) {
                $damaged += $shipRemoved ? 1 : 0;
            } elseif (($centralDamage = $this->applyCentralFacilityDisasterDamage(
                $context,
                $centerCell,
                'eruption',
                0,
            )) !== null) {
                $damaged += ($centralDamage || $shipRemoved) ? 1 : 0;
            } elseif ($this->isCapital($centerCell)) {
                $this->damageCapital($context, $centerCell, 'eruption', 'eruption_center');
                $damaged++;
            } elseif ($this->changeCell(
                $context,
                $centerCell,
                'eruption',
                'mountain',
                false,
                'disaster.cell_damaged',
                cellIndex: $cellIndex,
            ) || $shipRemoved) {
                $damaged++;
            }
        }

        foreach (array_keys(GridCoordinate::DIRECTION_NAMES) as $direction) {
            $cell = $this->cellAt($space, $center->neighbor($direction), $cellIndex);
            if ($cell === null || ! $this->isMutable($cell, $cellIndex) || $cell->terrain->key === 'mountain') {
                continue;
            }
            $shipRemoved = $this->shipRemoval->sinkLockedAtCell(
                $context,
                $cell,
                $ships->get($cell->id),
                'eruption',
                ['disaster_key' => 'eruption', 'direction' => $direction],
            ) !== null;
            if ($this->nationProtection->protectsFromDisaster($context, $cell->x, $cell->y)) {
                $damaged += $shipRemoved ? 1 : 0;

                continue;
            }
            $centralDamage = $this->applyCentralFacilityDisasterDamage(
                $context,
                $cell,
                'eruption',
                1,
                ['direction' => $direction],
            );
            if ($centralDamage !== null) {
                $damaged += ($centralDamage || $shipRemoved) ? 1 : 0;

                continue;
            }
            if ($this->isCapital($cell)) {
                $severity = $cell->terrain->key === 'sea'
                    ? 'excavation_or_shallow'
                    : 'facility_or_wasteland';
                $this->damageCapital($context, $cell, 'eruption', $severity, ['direction' => $direction]);
                $damaged++;

                continue;
            }
            $target = $cell->terrain->key === 'sea' ? 'shallow' : 'wasteland';
            if ($this->changeCell($context, $cell, 'eruption', $target, $target === 'shallow', 'disaster.cell_damaged', [
                'direction' => $direction,
            ], $cellIndex) || $shipRemoved) {
                $damaged++;
            }
        }

        return $damaged;
    }

    /** @param array<string, mixed> $settings */
    private function isTsunamiTarget(MapCell $cell, array $settings): bool
    {
        if (in_array($cell->terrain->key, ['sea', 'shallow', 'wasteland', 'forest', 'mountain'], true)) {
            return false;
        }
        $key = $cell->facility?->key;
        if (in_array($key, $settings['excluded_facility_keys'], true)) {
            return false;
        }
        if (in_array($key, $settings['settlement_facility_keys'], true)) {
            return $cell->population > 0;
        }

        return in_array($key, $settings['facility_keys'], true);
    }

    /** @param array<string, mixed> $settings */
    private function hugeMeteorRingTwoTarget(MapCell $cell, array $settings): bool
    {
        return ! in_array($cell->terrain->key, ['sea', 'shallow', 'wasteland', 'mountain'], true)
            && ! in_array($cell->facility?->key, $settings['seabed_facility_keys'], true);
    }

    /** @param list<string> $seabedFacilityKeys */
    private function adjacentWaterCount(
        MapCell $cell,
        MapSpace $space,
        array $seabedFacilityKeys,
        DisasterMutableCellIndex $cellIndex,
    ): int {
        $count = 0;
        $origin = new GridCoordinate($cell->x, $cell->y);
        foreach (array_keys(GridCoordinate::DIRECTION_NAMES) as $direction) {
            $coordinate = $origin->neighbor($direction);
            if ($coordinate->x < $space->min_x || $coordinate->x > $space->max_x
                || $coordinate->y < $space->min_y || $coordinate->y > $space->max_y) {
                $count++;

                continue;
            }
            $neighbor = $this->cellAt($space, $coordinate, $cellIndex);
            if ($neighbor !== null && (in_array($neighbor->terrain->key, ['sea', 'shallow'], true)
                || in_array($neighbor->facility?->key, $seabedFacilityKeys, true))) {
                $count++;
            }
        }

        return $count;
    }

    /** @param list<string> $facilityKeys */
    private function adjacentProtectionCount(
        MapCell $cell,
        array $facilityKeys,
        ?DisasterMutableCellIndex $cellIndex = null,
    ): int {
        $count = 0;
        $origin = new GridCoordinate($cell->x, $cell->y);
        foreach (array_keys(GridCoordinate::DIRECTION_NAMES) as $direction) {
            $coordinate = $origin->neighbor($direction);
            $neighbor = $cellIndex !== null
                ? $cellIndex->cellAt($coordinate->x, $coordinate->y)
                : MapCell::query()->where('map_space_id', $cell->map_space_id)
                    ->where('x', $coordinate->x)->where('y', $coordinate->y)
                    ->with(['terrain', 'facility'])->first();
            if ($neighbor !== null && ($neighbor->terrain->key === 'forest'
                || in_array($neighbor->facility?->key, $facilityKeys, true))) {
                $count++;
            }
        }

        return $count;
    }

    /**
     * @param  list<string>  $baseFacilityKeys
     * @return list<string>
     */
    private function forestProtectionFacilityKeys(
        TurnContext $context,
        string $disasterKey,
        array $baseFacilityKeys,
    ): array {
        $contract = $context->ruleset->settings['central_facilities']['forest_equivalent_protection'] ?? null;
        if ($contract === null) {
            return $baseFacilityKeys;
        }
        $facilityKeys = is_array($contract) ? ($contract['facility_keys'] ?? null) : null;
        $disasterKeys = is_array($contract) ? ($contract['disaster_keys'] ?? null) : null;
        if (! is_array($contract)
            || ! is_array($facilityKeys)
            || ! array_is_list($facilityKeys)
            || $facilityKeys === []
            || array_filter($facilityKeys, static fn (mixed $key): bool => ! is_string($key) || $key === '') !== []
            || ! is_array($disasterKeys)
            || ! array_is_list($disasterKeys)
            || array_filter($disasterKeys, static fn (mixed $key): bool => ! is_string($key) || $key === '') !== []) {
            throw new DomainException('The active Ruleset has an invalid central-facility forest-protection contract.');
        }
        if (! in_array($disasterKey, $contract['disaster_keys'], true)) {
            return $baseFacilityKeys;
        }

        return array_values(array_unique([...$baseFacilityKeys, ...$contract['facility_keys']]));
    }

    /**
     * @param  array<string, mixed>  $extra
     * @return array{before_population: int, after_population: int, damage_percent: int}
     */
    private function damageCapital(
        TurnContext $context,
        MapCell $cell,
        string $disasterKey,
        string $percentageKey,
        array $extra = [],
    ): array {
        $percentages = $context->ruleset->settings['capital_damage_percentages'] ?? null;
        if (! is_array($percentages) || ! is_int($percentages[$percentageKey] ?? null)) {
            throw new DomainException('The active ruleset has invalid Capital damage settings.');
        }

        return $this->damageCapitalByPercentage(
            $context,
            $cell,
            $disasterKey,
            $percentages[$percentageKey],
            $extra,
        );
    }

    /**
     * @param  array<string, mixed>  $extra
     * @return array{before_population: int, after_population: int, damage_percent: int}
     */
    private function damageCapitalByPercentage(
        TurnContext $context,
        MapCell $cell,
        string $disasterKey,
        int $percentage,
        array $extra = [],
    ): array {
        if ($this->nationProtection->protectsFromDisaster($context, $cell->x, $cell->y)) {
            return [
                'before_population' => (int) $cell->population,
                'after_population' => (int) $cell->population,
                'damage_percent' => 0,
            ];
        }
        $minimum = $context->ruleset->settings['capital_minimum_population'] ?? null;
        if (! is_int($minimum) || $minimum < 1 || $percentage < 0 || $percentage > 100) {
            throw new DomainException('The active ruleset has invalid Capital damage settings.');
        }
        $before = $cell->population;
        $cell->population = max($minimum, intdiv($before * (100 - $percentage), 100));
        $kind = $extra['population_damage_kind'] ?? null;
        $limit = is_string($kind) ? $this->facilityRanks->populationDamageLimit($context->ruleset->settings, $kind) : null;
        if ($limit !== null) {
            $cell->population = max($cell->population, $before - $limit);
        }
        $minimumPopulationAdjustment = max(0, $cell->population - $before);
        $cell->version++;
        $this->saveChangedCell($context, $cell);
        $this->events->record($context, 'capital.disaster_damaged', $cell, [
            'nation_id' => $cell->owner_nation_id,
            'disaster_key' => $disasterKey,
            'x' => $cell->x,
            'y' => $cell->y,
            'damage_percent' => $percentage,
            'before_population' => $before,
            'after_population' => $cell->population,
            'minimum_population' => $minimum,
            'minimum_population_applied' => $minimumPopulationAdjustment > 0,
            'minimum_population_adjustment' => $minimumPopulationAdjustment,
            'capital_identity_preserved' => true,
            'capital_name' => $cell->owner_nation_id === null ? null
                : Nation::query()->whereKey($cell->owner_nation_id)->value('capital_name'),
            ...$extra,
        ]);

        return [
            'before_population' => $before,
            'after_population' => $cell->population,
            'damage_percent' => $percentage,
        ];
    }

    /** @param array<string, mixed> $extra */
    private function changeCell(
        TurnContext $context,
        MapCell $cell,
        string $disasterKey,
        string $terrainKey,
        bool $neutralizeOwner,
        string $eventType,
        array $extra = [],
        ?DisasterMutableCellIndex $cellIndex = null,
        ?string $visibility = null,
    ): bool {
        if ($this->nationProtection->protectsFromDisaster($context, $cell->x, $cell->y)) {
            return false;
        }
        if ($this->centralFacilityDamage->isCentral($context, $cell)) {
            return false;
        }
        $beforeTerrain = $cell->terrain->key;
        $beforeFacility = $cell->facility?->key;
        $beforeOwner = $cell->owner_nation_id;
        $beforePopulation = $cell->population;
        $kind = $extra['population_damage_kind'] ?? ($disasterKey === 'meteor_shower' ? FacilityRankPolicy::LAND_DESTRUCTION : null);
        $loss = is_string($kind) ? $this->facilityScaleDamage->applyPopulation($context, $cell, $kind) : null;
        if ($loss !== null) {
            $this->events->record($context, $eventType, $cell, [
                'nation_id' => $beforeOwner,
                'disaster_key' => $disasterKey,
                'x' => $cell->x,
                'y' => $cell->y,
                'preserved_facility_key' => $beforeFacility,
                'before_population' => $beforePopulation,
                'after_population' => $cell->population,
                'from_terrain_key' => $beforeTerrain,
                'to_terrain_key' => $beforeTerrain,
                ...$extra,
            ]);

            return $loss > 0;
        }
        $targetOwner = $neutralizeOwner ? null : $beforeOwner;
        $monsterRemoved = $this->removeMonsterForTerrainEvent($context, $cell, $disasterKey);
        if ($beforeTerrain === $terrainKey && $beforeFacility === null
            && $beforeOwner === $targetOwner && $beforePopulation === 0) {
            return $monsterRemoved;
        }

        $windRepairable = isset($context->ruleset->settings['power_economy'])
            && $beforeFacility === 'wind_power' && ! $neutralizeOwner
            && ! in_array($terrainKey, ['sea', 'shallow'], true);
        if ($windRepairable) {
            // Reuse the existing facility state; land loss still removes equipment.
            $cell->facility_operational_state = 'damaged';
        } else {
            $this->cells->setFacility($cell, null);
            $terrain = $cellIndex?->terrainDefinition($terrainKey)
                ?? TerrainDefinition::query()->where('key', $terrainKey)->firstOrFail();
            $this->cells->transitionTerrain($cell, $terrain);
        }
        $cell->owner_nation_id = $targetOwner;
        $cell->population = 0;
        $cell->version++;
        $this->saveChangedCell($context, $cell);
        $this->events->record($context, $eventType, $cell, [
            'nation_id' => $beforeOwner,
            'disaster_key' => $disasterKey,
            'x' => $cell->x,
            'y' => $cell->y,
            'from_terrain_key' => $beforeTerrain,
            'to_terrain_key' => $cell->terrain->key,
            'removed_facility_key' => $windRepairable ? null : $beforeFacility,
            'from_owner_nation_id' => $beforeOwner,
            'to_owner_nation_id' => $targetOwner,
            'before_population' => $beforePopulation,
            'after_population' => 0,
            'wind_repairable' => $windRepairable,
            ...$extra,
        ], $visibility, message: $windRepairable ? '風力発電所が被災し故障しました。建設コマンドで半額修理できます。' : null);

        return true;
    }

    /**
     * Returns null for a non-central cell, true when level damage was applied,
     * and false when the central facility is protected from this damage shape.
     *
     * @param  array<string, mixed>  $metadata
     */
    private function applyCentralFacilityDisasterDamage(
        TurnContext $context,
        MapCell $cell,
        string $disasterKey,
        ?int $ringDistance = null,
        array $metadata = [],
    ): ?bool {
        if (! $this->centralFacilityDamage->isCentral($context, $cell)) {
            return null;
        }
        $contract = $this->centralFacilityDisasterContract($context);
        if (in_array($disasterKey, $contract['immune_disaster_keys'], true)) {
            return false;
        }
        $levelLoss = match (true) {
            $disasterKey === 'tsunami' => $contract['tsunami_level_loss'],
            $disasterKey === 'meteor_shower' => $contract['meteor_shower_level_loss'],
            $disasterKey === 'huge_meteor' && $ringDistance === 0 => $contract['huge_meteor_center_level_loss'],
            $disasterKey === 'huge_meteor' && $ringDistance === 1 => $contract['huge_meteor_ring_one_level_loss'],
            $disasterKey === 'huge_meteor' && $ringDistance === 2 => $contract['huge_meteor_ring_two_level_loss'],
            $disasterKey === 'eruption' && $ringDistance === 0 => $contract['eruption_center_level_loss'],
            $disasterKey === 'eruption' && $ringDistance === 1 => $contract['eruption_ring_one_level_loss'],
            $disasterKey === 'land_subsidence' => $contract['land_subsidence_level_loss'],
            default => null,
        };
        if ($levelLoss === null || $levelLoss === 0) {
            return false;
        }
        $damage = $this->centralFacilityDamage->apply(
            $context,
            $cell,
            $levelLoss,
            $disasterKey,
            $disasterKey,
            [
                'disaster_key' => $disasterKey,
                'ring_distance' => $ringDistance,
                ...$metadata,
            ],
        );

        return $damage !== null && $damage['scale_loss'] > 0;
    }

    /**
     * @return array{facility_keys: list<string>, tsunami_level_loss: int, meteor_shower_level_loss: int, huge_meteor_center_level_loss: int, huge_meteor_ring_one_level_loss: int, huge_meteor_ring_two_level_loss: int, eruption_center_level_loss: int, eruption_ring_one_level_loss: int, land_subsidence_level_loss: int, immune_disaster_keys: list<string>}
     */
    private function centralFacilityDisasterContract(TurnContext $context): array
    {
        $contract = $context->ruleset->settings['central_facilities']['disaster_damage'] ?? null;
        $facilityKeys = is_array($contract) ? ($contract['facility_keys'] ?? null) : null;
        $immuneKeys = is_array($contract) ? ($contract['immune_disaster_keys'] ?? null) : null;
        $lossKeys = [
            'tsunami_level_loss', 'meteor_shower_level_loss', 'huge_meteor_center_level_loss',
            'huge_meteor_ring_one_level_loss', 'huge_meteor_ring_two_level_loss',
            'eruption_center_level_loss', 'eruption_ring_one_level_loss', 'land_subsidence_level_loss',
        ];
        if (! is_array($contract)
            || ! is_array($facilityKeys)
            || ! array_is_list($facilityKeys)
            || $facilityKeys === []
            || array_filter($facilityKeys, static fn (mixed $key): bool => ! is_string($key) || $key === '') !== []
            || array_filter($lossKeys, static fn (string $key): bool => ! is_int($contract[$key] ?? null) || $contract[$key] < 0) !== []
            || ! is_array($immuneKeys)
            || ! array_is_list($immuneKeys)
            || array_filter($immuneKeys, static fn (mixed $key): bool => ! is_string($key) || $key === '') !== []) {
            throw new DomainException('The active Ruleset has an invalid central-facility disaster contract.');
        }

        return $contract;
    }

    private function removeMonsterForTerrainEvent(
        TurnContext $context,
        MapCell $cell,
        string $disasterKey,
    ): bool {
        if ($this->nationProtection->protectsFromDisaster($context, $cell->x, $cell->y)) {
            return false;
        }

        return $this->monsterRemoval->removeAtCell(
            $context,
            $cell,
            $disasterKey,
            'monster.removed_by_terrain_event',
            ['terrain_event_key' => $disasterKey, 'hardening_ignored' => true],
        );
    }

    private function saveChangedCell(TurnContext $context, MapCell $cell): void
    {
        $cell->save();
        $context->state->markMapChunkChanged($cell->map_chunk_id);
    }

    private function isCapital(MapCell $cell): bool
    {
        return $cell->facility?->key === 'capital';
    }

    private function isMutable(MapCell $cell, ?DisasterMutableCellIndex $cellIndex = null): bool
    {
        if ($cellIndex !== null) {
            return $cellIndex->isMutable($cell);
        }

        return $cell->owner_nation_id === null
            || Nation::query()->whereKey($cell->owner_nation_id)
                ->whereIn('state', ['active', 'dormant', 'recovery'])->exists();
    }

    private function newMutableCellIndex(TurnContext $context): DisasterMutableCellIndex
    {
        $activeNationIds = Nation::query()
            ->where('world_id', $context->world->id)
            ->whereIn('state', ['active', 'dormant', 'recovery'])
            ->orderBy('id')
            ->pluck('id')
            ->map(static fn ($id): int => (int) $id)
            ->all();
        $terrainDefinitions = TerrainDefinition::query()->orderBy('id')->get()->keyBy('key');

        return DisasterMutableCellIndex::fromCells([], $activeNationIds, $terrainDefinitions);
    }

    private function loadRadiusCells(
        MapSpace $space,
        GridCoordinate $center,
        int $radius,
        DisasterMutableCellIndex $cellIndex,
    ): void {
        $cells = MapCell::query()
            ->where('map_space_id', $space->id)
            ->whereBetween('x', [$center->x - $radius, $center->x + $radius])
            ->whereBetween('y', [$center->y - $radius, $center->y + $radius])
            ->orderBy('id')
            ->lockForUpdate()
            ->with(['terrain', 'facility'])
            ->get();
        $cellIndex->addCells($cells);
    }

    private function loadAllCells(MapSpace $space, DisasterMutableCellIndex $cellIndex): void
    {
        $cells = MapCell::query()
            ->where('map_space_id', $space->id)
            ->orderBy('id')
            ->lockForUpdate()
            ->with(['terrain', 'facility'])
            ->get();
        $cellIndex->addCells($cells);
    }

    private function surfaceSpace(TurnContext $context): MapSpace
    {
        return MapSpace::query()->where('world_id', $context->world->id)
            ->where('key', 'surface')->firstOrFail();
    }

    private function cellAt(
        MapSpace $space,
        GridCoordinate $coordinate,
        ?DisasterMutableCellIndex $cellIndex = null,
    ): ?MapCell {
        if ($cellIndex !== null) {
            return $cellIndex->cellAt($coordinate->x, $coordinate->y);
        }

        return MapCell::query()->where('map_space_id', $space->id)
            ->where('x', $coordinate->x)->where('y', $coordinate->y)
            ->lockForUpdate()->with(['terrain', 'facility'])->first();
    }

    /** @return array<string, array<string, mixed>> */
    private function rules(TurnContext $context): array
    {
        $turnProcessing = $context->ruleset->settings['turn_processing'] ?? null;
        if (! is_array($turnProcessing) || ! array_key_exists('disasters', $turnProcessing)) {
            throw new DomainException('The active ruleset is missing disaster settings.');
        }
        $rules = $turnProcessing['disasters'];
        if (! is_array($rules)) {
            throw new DomainException('The active ruleset is missing disaster settings.');
        }

        return $rules;
    }

    /**
     * @return array{
     *     enabled: bool,
     *     base_safe_land_cells: int,
     *     probability: array{numerator: int, denominator: int},
     *     affected_shallow_result: string,
     *     affected_coastal_land_result: string,
     *     mountain_immune: bool,
     *     capital_damage_percentage: int,
     *     out_of_bounds_is_water: bool,
     *     stream_version: int
     * }
     */
    private function landSubsidenceSettings(mixed $authored): array
    {
        if (! is_array($authored)
            || ! is_bool($authored['enabled'] ?? null)
            || ! is_int($authored['base_safe_land_cells'] ?? null)
            || ! is_array($authored['probability'] ?? null)
            || ! is_int($authored['probability']['numerator'] ?? null)
            || ! is_int($authored['probability']['denominator'] ?? null)
            || ! is_string($authored['affected_shallow_result'] ?? null)
            || ! is_string($authored['affected_coastal_land_result'] ?? null)
            || ! is_bool($authored['mountain_immune'] ?? null)
            || ! is_int($authored['capital_damage_percentage'] ?? null)
            || ! is_bool($authored['out_of_bounds_is_water'] ?? null)
            || ! is_int($authored['stream_version'] ?? null)) {
            throw new DomainException('The active ruleset is missing land-subsidence settings.');
        }
        $numerator = $authored['probability']['numerator'];
        $denominator = $authored['probability']['denominator'];
        if ($authored['base_safe_land_cells'] < 0
            || $numerator < 0 || $denominator < 1 || $numerator > $denominator
            || $authored['affected_shallow_result'] !== 'sea'
            || $authored['affected_coastal_land_result'] !== 'shallow'
            || $authored['mountain_immune'] !== true
            || $authored['capital_damage_percentage'] < 0
            || $authored['capital_damage_percentage'] > 100
            || $authored['out_of_bounds_is_water'] !== true
            || $authored['stream_version'] < 1) {
            throw new DomainException('The active ruleset has invalid land-subsidence settings.');
        }

        return $authored;
    }

    /** @param array{numerator: int, denominator: int} $probability
     * @return array{draw: int, success: bool}
     */
    private function probabilityDraw(TurnContext $context, array $probability, string $label): array
    {
        $draw = $context->random->stream($label)->integer(0, $probability['denominator'] - 1);

        return ['draw' => $draw, 'success' => $draw < $probability['numerator']];
    }

    private function center(
        TurnContext $context,
        MapSpace $space,
        int $padding,
        string $label,
    ): GridCoordinate {
        $minimumX = $space->min_x - $padding;
        $maximumX = $space->max_x + $padding;
        $minimumY = $space->min_y - $padding;
        $maximumY = $space->max_y + $padding;
        if ($minimumX < DeterministicRandomStream::MINIMUM_INTEGER
            || $maximumX > DeterministicRandomStream::MAXIMUM_INTEGER
            || $minimumY < DeterministicRandomStream::MINIMUM_INTEGER
            || $maximumY > DeterministicRandomStream::MAXIMUM_INTEGER) {
            throw new DomainException('Disaster center draw bounds must fit signed 32-bit integers after World expansion.');
        }
        $stream = $context->random->stream($label);

        return new GridCoordinate(
            $stream->integer($minimumX, $maximumX),
            $stream->integer($minimumY, $maximumY),
        );
    }
}
