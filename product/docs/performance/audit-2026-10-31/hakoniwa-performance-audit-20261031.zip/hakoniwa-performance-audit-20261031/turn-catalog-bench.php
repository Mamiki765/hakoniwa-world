<?php
declare(strict_types=1);
spl_autoload_register(function(string $class): void {
    if (str_starts_with($class, 'App\\')) {
        $path='/source/product/app/'.str_replace('\\','/',substr($class,4)).'.php';
        if (is_file($path)) require $path;
    }
});
$settings=require '/source/product/config/hakoniwa/rulesets/hakoniwa-2s-plus-v41.php';
$contract=new App\Domain\Secretary\SecretaryItemGameplayContract(new App\Domain\Secretary\SecretaryItemCatalog);
$times=[];$hashes=[];
for ($round=0;$round<3;++$round) {
    $start=hrtime(true);
    for($i=0;$i<500;++$i) $effects=$contract->validatedEffectCatalog($settings);
    $times[]=(hrtime(true)-$start)/1e6;
    $hashes[]=hash('sha256',json_encode($effects,JSON_THROW_ON_ERROR));
}
if (count(array_unique($hashes)) !== 1) throw new RuntimeException('Output mismatch');
echo json_encode(['runtime'=>PHP_VERSION,'ruleset'=>$settings['key'],'item_count'=>count($effects),'calls_per_round'=>500,'milliseconds'=>$times,'output_sha256'=>$hashes[0]],JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR),"\n";
