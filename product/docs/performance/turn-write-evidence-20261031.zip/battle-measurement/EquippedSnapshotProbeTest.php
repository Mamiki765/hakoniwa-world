<?php

// External-only probe. The application source and branch are never edited.
use App\Application\Underground\UndergroundEquipmentLoadoutResolver;
use App\Application\Underground\UndergroundIntroService;
use App\Application\Underground\UndergroundRuntimeEquipmentGenerator;
use App\Application\Underground\UndergroundEquipmentCatalog;
use App\Models\UndergroundBattle;
use App\Models\UndergroundOwnedEquipment;
use App\Models\UndergroundProfile;
use Illuminate\Database\Events\QueryExecuted;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Tests\Support\UndergroundPlayerAccessTestCase;

function bu02ProbeRows(UndergroundProfile $profile): Illuminate\Database\Eloquent\Collection
{
    $context = &$GLOBALS['bu02_probe_context'];
    if (is_array($context) && $context['enabled']) {
        if ($context['profile_id'] !== $profile->id) {
            throw new RuntimeException('The probe snapshot cannot cross profiles.');
        }
        if ($context['rows'] !== null) {
            return $context['rows'];
        }
    }
    $rows = UndergroundOwnedEquipment::query()
        ->where('underground_profile_id', $profile->id)
        ->whereNotNull('equipped_slot')->orderBy('id')->get();
    if (is_array($context) && $context['enabled']) {
        $context['rows'] = $rows;
    }
    return $rows;
}

function bu02ProbeEnter(string $name): void
{
    $GLOBALS['bu02_probe_starts'][$name][] = ['wall'=>hrtime(true),'cpu'=>getrusage()];
}

function bu02ProbeExit(string $name): void
{
    $start = array_pop($GLOBALS['bu02_probe_starts'][$name]);
    $row = &$GLOBALS['bu02_probe_methods'][$name];
    $row ??= ['calls'=>0, 'inclusive_ms'=>0.0, 'inclusive_cpu_ms'=>0.0];
    $row['calls']++;
    $row['inclusive_ms'] += (hrtime(true)-$start['wall'])/1e6;
    $cpu = getrusage();
    $cpuMs = static fn(array $r):float=>(($r['ru_utime.tv_sec']+$r['ru_stime.tv_sec'])*1000)+(($r['ru_utime.tv_usec']+$r['ru_stime.tv_usec'])/1000);
    $row['inclusive_cpu_ms'] += $cpuMs($cpu)-$cpuMs($start['cpu']);
}

// Only wrap the real resolver methods and replace its two identical equipped
// row SELECT sites with the same SELECT or one response-local row snapshot.
// Canonical validation/aggregate/projection logic is unchanged in both modes.
if (class_exists(UndergroundEquipmentLoadoutResolver::class, false)) {
    throw new RuntimeException('Resolver was loaded before external instrumentation.');
}
$resolverPath = '/var/www/html/app/Application/Underground/UndergroundEquipmentLoadoutResolver.php';
$resolverSource = file_get_contents($resolverPath);
$originalResolverHash = hash('sha256', $resolverSource);
$query = <<<'SOURCE'
$rows = UndergroundOwnedEquipment::query()
            ->where('underground_profile_id', $profile->id)
            ->whereNotNull('equipped_slot')
            ->orderBy('id')
            ->get();
SOURCE;
$resolverSource = str_replace($query, '$rows = \\bu02ProbeRows($profile);', $resolverSource, $replaced);
if ($replaced !== 2) {
    throw new RuntimeException('Expected exactly two equipped SELECT sites.');
}
$methods = ['combatLoadout','summary','ratingRequirementBps','definitionForRow','projectOwned','equippedDefinitions'];
$tokens = token_get_all($resolverSource);
$position = 0; $patches = [];
for ($i=0, $count=count($tokens); $i<$count; $i++) {
    $token = $tokens[$i]; $text = is_array($token) ? $token[1] : $token;
    if (is_array($token) && $token[0] === T_FUNCTION) {
        $name = null; $open = null; $cursor = $position;
        for ($j=$i; $j<$count; $j++) {
            $part = $tokens[$j]; $value = is_array($part) ? $part[1] : $part;
            if ($name === null && is_array($part) && $part[0] === T_STRING) $name = $value;
            if ($part === '{') { $open = $cursor; break; }
            $cursor += strlen($value);
        }
        if ($open !== null && in_array($name, $methods, true)) {
            $depth = 1; $cursor = $open+1;
            for ($j++; $j<$count; $j++) {
                $part = $tokens[$j]; $value = is_array($part) ? $part[1] : $part;
                if ($part === '{' || (is_array($part) && in_array($part[0], [T_CURLY_OPEN,T_DOLLAR_OPEN_CURLY_BRACES], true))) $depth++;
                if ($part === '}') $depth--;
                if ($depth === 0) break;
                $cursor += strlen($value);
            }
            $patches[] = [$open+1, "\n\\bu02ProbeEnter('$name'); try {\n"];
            $patches[] = [$cursor, "\n} finally { \\bu02ProbeExit('$name'); }\n"];
        }
    }
    $position += strlen($text);
}
if (count($patches) !== count($methods)*2) throw new RuntimeException('Method instrumentation count mismatch.');
usort($patches, static fn (array $a, array $b): int => $b[0]<=>$a[0]);
foreach ($patches as [$offset,$insert]) $resolverSource = substr_replace($resolverSource,$insert,$offset,0);
eval(substr($resolverSource,5));
$GLOBALS['bu02_probe_original_resolver_sha256'] = $originalResolverHash;

final class EquippedSnapshotProbeTest extends UndergroundPlayerAccessTestCase
{
    use RefreshDatabase;

    public function test_one_state_response_with_six_generated_equipped_slots(): void
    {
        Carbon::setTestNow('2026-10-31 12:00:00+09:00');
        [$user,$secretary] = $this->secretaryUser('BU02 synthetic response');
        $profile = $this->openEquipmentProfile($secretary, 5000000, 0);
        $battle = UndergroundBattle::query()->where('underground_profile_id',$profile->id)->sole();
        $generator = app(UndergroundRuntimeEquipmentGenerator::class);
        $catalog = app(UndergroundEquipmentCatalog::class);
        $slots = ['weapon'=>['weapon','dagger',null], 'armor'=>['armor',null,null],
            'accessory_1'=>['accessory',null,'vitality'], 'accessory_2'=>['accessory',null,'might'],
            'accessory_3'=>['accessory',null,'spirit'], 'resonance'=>['resonance',null,null]];
        foreach ($slots as $slot=>[$category,$style,$mainStat]) {
            $resonance = $category === 'resonance';
            $tier = $resonance ? 'bahamul' : 'shallow_caves';
            $variant = $resonance ? $catalog->resonanceVariantKeys($tier)[0] : null;
            $payload = $generator->generate($resonance ? 210 : 30,$tier,$resonance ? 'unique' : 'epic',
                $category,$style,$mainStat,23,'bu02-synthetic:'.$slot,$variant);
            UndergroundOwnedEquipment::query()->create([
                'underground_profile_id'=>$profile->id,'definition_key'=>$payload['key'],
                'catalog_identity'=>$catalog->identity(),'equipped_slot'=>$slot,
                'grant_key'=>'bu02:'.$slot,'instance_kind'=>'generated','instance_identity'=>$payload['instance_identity'],
                'generator_identity'=>$payload['generator_identity'],'generated_payload'=>$payload,
                'quality_percent'=>$generator->qualityPercent($payload),'polish_level'=>$resonance ? 2 : 0,
                'source_battle_id'=>$battle->id,'source_reward_index'=>array_search($slot,array_keys($slots),true)+1,
                'acquired_at'=>Carbon::now(),
            ]);
        }
        $GLOBALS['bu02_probe_context'] = null;
        // Warm one-off starter completion, visitor code, balances and catalogs
        // outside the timing/query window. Use the real service return path.
        $service = app(UndergroundIntroService::class);
        $warm = $service->state($user);
        $this->assertCount(6,array_filter($warm['equipment_summary']['equipped']));
        $listenerActive = false; $queries = [];
        DB::listen(static function (QueryExecuted $event) use (&$listenerActive,&$queries): void {
            if (!$listenerActive) return;
            $sql = strtolower($event->sql);
            $queries[] = ['sql'=>$event->sql,'bindings'=>$event->bindings,'ms'=>$event->time,
                'equipped'=>str_contains($sql,'from "underground_owned_equipment"')
                    && str_contains($sql,'"equipped_slot" is not null')];
        });
        if (getenv('BU02_PREPARE_ONLY') === '1') {
            file_put_contents(__DIR__.'/prepared.json',json_encode(['prepared'=>true,'equipped_slots'=>6,
                'profile_id'=>$profile->id,'normal_service_state_ok'=>true],JSON_PRETTY_PRINT)."\n");
            return;
        }
        $result = ['base_sha'=>'2e93ec918774ad64d787aba99fc59a7bc3e54d16','catalog_head'=>'7aa89e1058416da5b7cc3b65b65a7cb3816deb83',
            'php'=>PHP_VERSION,'fixture'=>'one synthetic open profile; 6 generated slots incl polished IL210 resonance; same frozen time; real IntroService::state',
            'prototype'=>'one response-local equipped-row snapshot; canonical method bodies unchanged; no persistent cache',
            'resolver_sha256'=>$GLOBALS['bu02_probe_original_resolver_sha256'],'pairs'=>[]];
        foreach ([['baseline','snapshot'],['snapshot','baseline'],['baseline','snapshot']] as $pair=>$modes) {
            $rows=[];
            foreach ($modes as $mode) {
                $queries=[]; $GLOBALS['bu02_probe_methods']=[]; $GLOBALS['bu02_probe_starts']=[];
                $GLOBALS['bu02_probe_context']=['enabled'=>$mode==='snapshot','profile_id'=>$profile->id,'rows'=>null];
                $listenerActive=true; $cpu=getrusage(); $start=hrtime(true);
                try { $value=$service->state($user); }
                finally { $elapsed=(hrtime(true)-$start)/1e6; $afterCpu=getrusage(); $listenerActive=false; $GLOBALS['bu02_probe_context']=null; }
                $cpuMs=static fn(array $r):float=>(($r['ru_utime.tv_sec']+$r['ru_stime.tv_sec'])*1000)+(($r['ru_utime.tv_usec']+$r['ru_stime.tv_usec'])/1000);
                $equipped=array_values(array_filter($queries,static fn(array $q):bool=>$q['equipped']));
                $rows[$mode]=['service_ms'=>$elapsed,'process_cpu_ms'=>$cpuMs($afterCpu)-$cpuMs($cpu),
                    'query_count'=>count($queries),'sql_ms'=>array_sum(array_column($queries,'ms')),
                    'equipped_query_count'=>count($equipped),'equipped_sql_ms'=>array_sum(array_column($equipped,'ms')),
                    'methods'=>$GLOBALS['bu02_probe_methods'],'output_hash'=>hash('sha256',serialize($value)),
                    'equipped_queries'=>$equipped];
                $this->assertSame($mode==='snapshot' ? 1 : 3,count($equipped));
            }
            $this->assertSame($rows['baseline']['output_hash'],$rows['snapshot']['output_hash']);
            $result['pairs'][]=['order'=>$modes,'results'=>$rows];
        }
        $this->assertNull($GLOBALS['bu02_probe_context']);
        file_put_contents(__DIR__.'/measurement.json',json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n");
        Carbon::setTestNow();
    }
}
