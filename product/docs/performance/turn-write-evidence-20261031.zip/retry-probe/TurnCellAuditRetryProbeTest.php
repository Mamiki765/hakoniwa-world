<?php

namespace Tests\CellAuditRetryProbe;

use App\Application\CommandQueueService;
use App\Application\CompleteTurnEngine;
use App\Application\MonsterKillCycleService;
use App\Application\NationCreationService;
use App\Application\OceanWorldGenerator;
use App\Application\SecretaryItemGrantService;
use App\Application\TurnRunner;
use App\Application\WorldExpansionService;
use App\Domain\Disaster\SeaAreaWeatherLottery;
use App\Domain\Map\GridCoordinate;
use App\Domain\Map\MapCellStateService;
use App\Domain\Ruleset\CurrentRulesetGuard;
use App\Domain\Turn\TurnContext;
use App\Domain\Turn\TurnPhase;
use App\Domain\Turn\TurnPhaseResult;
use App\Domain\Turn\TurnPipeline;
use App\Domain\Turn\TurnRandomStreamFactory;
use App\Domain\Turn\TurnSeedGenerator;
use App\Domain\Turn\TurnState;
use App\Domain\World\MapBounds;
use App\Domain\World\WorldGenerationProfile;
use App\Domain\World\WorldMutationLock;
use App\Models\FacilityDefinition;
use App\Models\MapCell;
use App\Models\Nation;
use App\Models\NationResource;
use App\Models\NationResourceSalePolicy;
use App\Models\ResourceDefinition;
use App\Models\RulesetVersion;
use App\Models\TerrainDefinition;
use App\Models\TurnRun;
use App\Models\User;
use App\Models\World;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Events\QueryExecuted;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Tests\Concerns\UsesForwardOnlyDatabaseMigrations;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Str;
use PHPUnit\Framework\Attributes\DataProvider;
use Tests\Concerns\CreatesTestWorlds;
use Tests\Concerns\UsesIndividualTestWorld;
use Tests\TestCase;


final class TurnCellAuditRetryProbeTest extends TestCase
{
    use CreatesTestWorlds;
    use UsesIndividualTestWorld;
    use DatabaseMigrations, UsesForwardOnlyDatabaseMigrations {
        UsesForwardOnlyDatabaseMigrations::runDatabaseMigrations insteadof DatabaseMigrations;
        UsesForwardOnlyDatabaseMigrations::refreshTestDatabase insteadof DatabaseMigrations;
    }

    private const FIXTURE_SEED = '0000000000000000000000000000000000000000000000000000000000000000';

    private bool $observing = false;
    private bool $injected = false;
    private bool $rollbackObserved = false;
    private string $mode = '';
    private array $fault = [];
    private array $rollback = [];
    private array $states = [];
    private array $contextIdentities = [];
    private array $processInsertSizes = [];
    private array $firstBatchWithoutIds = [];
    private array $failedBatchWithoutIds = [];
    private array $replayedBatchWithoutIds = [];

    protected function setUp(): void
    {
        // Match the parent mature fixture; this is fixture input, not an RNG algorithm override.
        \Illuminate\Support\Carbon::setTestNow('2026-10-31 12:00:00 UTC');
        Str::createUuidsUsing(static fn () => \Ramsey\Uuid\Uuid::fromString('00000000-0000-4000-8000-000000000031'));
        parent::setUp();
        fake()->seed(20261031);
    }

    protected function tearDown(): void
    {
        $this->observing = false;
        try {
            parent::tearDown();
        } finally {
            Str::createUuidsNormally();
            \Illuminate\Support\Carbon::setTestNow();
        }
    }

    public function test_canonical_mature_turn_replays_after_a_real_serialization_failure(): void
    {
        $this->mode = (string) getenv('TURN_CELL_RETRY_MODE');
        $path = (string) getenv('TURN_CELL_RETRY_OUTPUT');
        if (! in_array($this->mode, ['clean', 'fault'], true) || $path === '' || is_file($path)) {
            throw new \RuntimeException('Explicit clean/fault mode and a new evidence output path are required.');
        }
        $world = $this->processCellProfileWorld(3_600, 'mature');
        $this->assertSame(0, DB::connection()->transactionLevel(), 'C1 must enter a root transaction, not a PHPUnit savepoint.');
        $initialTurn = (int) $world->current_turn;
        $input = $this->auditStateSnapshot();
        $inputGameplay = $this->rollbackComparableTables($input);
        $pdo = DB::connection()->getPdo();

        // Keep the configured TurnRunner, pipeline and real GameplayTurnPhase implementations.
        // Only the master-seed input is fixed, as in the parent paired mature measurements.
        $this->app->instance(TurnSeedGenerator::class, new RetryFixtureSeedGenerator(self::FIXTURE_SEED));
        $pipeline = app(TurnPipeline::class);
        $this->assertSame(TurnPipeline::CANONICAL_PHASE_KEYS,
            array_map(static fn (TurnPhase $phase): string => $phase->key(), $pipeline->phases()));
        $phaseClasses = [];
        foreach ($pipeline->phases() as $phase) {
            $this->assertInstanceOf(\App\Domain\Turn\GameplayTurnPhase::class, $phase);
            $phaseClasses[] = $phase::class;
        }

        DB::listen(function (QueryExecuted $query) use ($inputGameplay): void {
            if (! $this->observing) {
                return;
            }
            // The first run refresh outside the rolled-back game transaction is C1's own
            // diagnostic path. Snapshot here before the second attempt changes game state.
            if ($this->injected && ! $this->rollbackObserved
                && $query->connection->transactionLevel() === 0
                && str_starts_with(strtolower($query->sql), 'select ')
                && str_contains($query->sql, 'from "turn_runs"')) {
                $this->rollbackObserved = true;
                $this->observing = false;
                try {
                    $snapshot = $this->auditStateSnapshot();
                    $this->rollback = [
                        'transaction_level' => $query->connection->transactionLevel(),
                        'pdo_object_id' => spl_object_id($query->connection->getPdo()),
                        'gameplay_and_preexisting_audit_restored' => $this->rollbackComparableTables($snapshot) === $inputGameplay,
                        'failed_state_batch_active' => $this->states[0]->cellAuditBatchActive(),
                        'failed_state_buffer_rows' => $this->states[0]->cellAuditRowCount(),
                        'snapshot' => $snapshot,
                    ];
                } finally {
                    $this->observing = true;
                }
            }
            if (! str_starts_with($query->sql, 'insert into "audit_events" ')) {
                return;
            }
            [$phase, $context] = $this->phaseContext();
            if ($phase !== 'process_cells' || ! $context instanceof TurnContext) {
                return;
            }
            $index = $this->observeState($context);
            if (preg_match('/^insert into "audit_events" \(([^)]+)\) values /', $query->sql, $match) !== 1) {
                throw new \RuntimeException('The probe cannot classify this audit INSERT shape.');
            }
            $columns = count(explode(',', $match[1]));
            $rowCount = intdiv(count($query->bindings), $columns);
            $this->processInsertSizes[$index][] = $rowCount;
            if (isset($this->firstBatchWithoutIds[$index])) {
                return;
            }
            $batch = $this->latestAuditBatch($context, $rowCount);
            $this->firstBatchWithoutIds[$index] = $batch;
            if ($this->mode === 'fault' && ! $this->injected && $rowCount >= 1_000) {
                // QueryExecuted fires after PostgreSQL accepted this bulk INSERT.
                // The fault is real SQLSTATE 40001, once, inside the unchanged root Turn body.
                $this->injected = true;
                $this->failedBatchWithoutIds = $batch;
                $this->fault = [
                    'phase' => $phase,
                    'inserted_rows_in_statement' => $rowCount,
                    'bindings' => count($query->bindings),
                    'transaction_level' => $query->connection->transactionLevel(),
                    'pdo_object_id' => spl_object_id($query->connection->getPdo()),
                    'context_identity' => $this->contextIdentities[$index],
                    'batch_active_after_insert' => $context->state->cellAuditBatchActive(),
                    'buffer_rows_after_insert' => $context->state->cellAuditRowCount(),
                    'turn_audit_rows_visible_before_error' => DB::table('audit_events')
                        ->where('world_id', $context->world->id)->where('turn', $context->targetTurn)->count(),
                ];
                try {
                    DB::unprepared("DO $$ BEGIN RAISE EXCEPTION 'cell audit C1 external fixture' USING ERRCODE = '40001'; END; $$;");
                } catch (\Throwable $exception) {
                    $this->fault['exception_class'] = $exception::class;
                    $this->fault['sqlstate'] = $exception instanceof \PDOException ? ($exception->errorInfo[0] ?? null) : null;
                    throw $exception;
                }
                throw new \RuntimeException('The real PostgreSQL fault unexpectedly returned.');
            }
            if ($this->mode === 'fault' && $this->injected && $index === 1) {
                $this->replayedBatchWithoutIds = $batch;
            }
        });

        $run = null;
        $caught = null;
        $this->observing = true;
        try {
            // One new cron invocation. There is no cross-invocation/manual retry in this probe.
            $run = app(TurnRunner::class)->run($world, source: 'cron');
            $this->observing = false;
            $this->assertInstanceOf(TurnRun::class, $run);
            $this->assertSame(TurnRun::STATUS_COMPLETED, $run->status);
            $this->assertSame(self::FIXTURE_SEED, $run->random_seed);
            $this->assertSame($initialTurn + 1, (int) $world->fresh()->current_turn);
            $this->assertSame(1, TurnRun::query()->where('world_id', $world->id)->count());
            $this->assertSame(0, DB::connection()->transactionLevel());
            $this->assertSame($pdo, DB::connection()->getPdo());
            $this->assertSame(TurnPipeline::CANONICAL_PHASE_KEYS,
                array_column($run->phase_results, 'phase'));
            $this->assertSame(3_600, collect($run->phase_results)->firstWhere('phase', 'process_cells')['metrics']['processed']);
            foreach ($this->states as $state) {
                $this->assertFalse($state->cellAuditBatchActive());
                $this->assertSame(0, $state->cellAuditRowCount());
            }
            if ($this->mode === 'fault') {
                $this->assertTrue($this->injected);
                $this->assertSame('40001', $this->fault['sqlstate']);
                $this->assertSame(1_000, $this->fault['inserted_rows_in_statement']);
                $this->assertGreaterThanOrEqual(1_000, $this->fault['turn_audit_rows_visible_before_error']);
                $this->assertTrue($this->rollbackObserved);
                $this->assertSame(0, $this->rollback['transaction_level']);
                $this->assertTrue($this->rollback['gameplay_and_preexisting_audit_restored']);
                $this->assertFalse($this->rollback['failed_state_batch_active']);
                $this->assertSame(0, $this->rollback['failed_state_buffer_rows']);
                $this->assertCount(2, $this->states);
                $this->assertNotSame($this->states[0], $this->states[1]);
                $this->assertSame($this->contextIdentities[0], $this->contextIdentities[1]);
                $this->assertSame($this->failedBatchWithoutIds, $this->replayedBatchWithoutIds);
                $this->assertSame(2, (int) $run->attempt_count);
                $this->assertSame(
                    $this->auditCanonicalize([['attempt_count' => 1, 'phase' => 'process_cells', 'sqlstate' => '40001']]),
                    $this->auditCanonicalize($run->failure_context['transient_retries']),
                );
            } else {
                $this->assertFalse($this->injected);
                $this->assertCount(1, $this->states);
                $this->assertSame(1, (int) $run->attempt_count);
                $this->assertSame([], $run->failure_context);
            }
        } catch (\Throwable $exception) {
            $caught = $exception;
        } finally {
            $this->observing = false;
            $output = $this->auditStateSnapshot();
            $evidence = [
                'mode' => $this->mode,
                'base_sha' => '2e93ec918774ad64d787aba99fc59a7bc3e54d16',
                'runtime_php' => PHP_VERSION,
                'fixture' => 'parent mature 60x60 / 3600-cell recipe; clock/Faker/registration UUID fixed before setup',
                'seed' => self::FIXTURE_SEED,
                'pipeline_classes' => $phaseClasses,
                'entry_transaction_level' => 0,
                'pdo_object_id_before' => spl_object_id($pdo),
                'pdo_object_id_after' => spl_object_id(DB::connection()->getPdo()),
                'context_identities' => $this->contextIdentities,
                'state_object_ids' => array_map(static fn (TurnState $state): int => spl_object_id($state), $this->states),
                'state_batches_after' => array_map(static fn (TurnState $state): array => [
                    'active' => $state->cellAuditBatchActive(), 'buffer_rows' => $state->cellAuditRowCount(),
                ], $this->states),
                'process_cells_insert_sizes_by_attempt' => $this->processInsertSizes,
                'fault' => $this->fault,
                'rollback_checkpoint' => $this->rollback,
                'failed_first_batch_without_audit_ids' => $this->failedBatchWithoutIds,
                'replayed_first_batch_without_audit_ids' => $this->replayedBatchWithoutIds,
                'run' => $run?->only(['id', 'world_id', 'ruleset_version_id', 'target_turn', 'random_seed', 'status', 'attempt_count', 'pipeline', 'phase_results', 'failure_context']),
                'source_sha256' => array_combine($paths = [
                    'Application/CompleteTurnEngine.php', 'Application/TurnEventRecorder.php', 'Domain/Turn/TurnState.php',
                    'Application/TurnRunner.php', 'Domain/Turn/TurnPipeline.php', 'Domain/Turn/GameplayTurnPhase.php',
                    'Domain/Turn/DeterministicRandomStream.php', 'Domain/Turn/TurnRandomStreamFactory.php',
                ], array_map(static fn (string $source): string => hash_file('sha256', app_path($source)), $paths)),
                'composer_lock_sha256' => hash_file('sha256', base_path('composer.lock')),
                'input' => $input,
                'output' => $output,
                'probe_error' => $caught === null ? null : ['class' => $caught::class, 'message' => $caught->getMessage()],
                'limitations' => [
                    'One clean and one fault run are evidence checks, not timing samples.',
                    'An error immediately after takeCellAuditRows/INSERT has an empty pending buffer. Non-empty-tail discard is covered separately by the existing focused TurnCellAuditBatchTest; this probe does not invent a pending row.',
                    'PostgreSQL sequences are not rolled back: raw audit IDs are expected to differ after the failed statement. Attempt_count/failure_context also differ. Do not claim raw all-ID or all-table identity.',
                    'Authentication/session/cache tables and attachment_token are never selected by the synthetic state capture.',
                ],
            ];
            file_put_contents($path, json_encode($evidence, JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }
        if ($caught !== null) {
            throw $caught;
        }
    }

    /** @return array{?string, ?TurnContext} */
    private function phaseContext(): array
    {
        // Observe the configured engine's current call; do not wrap/replace phases or RNG.
        foreach (debug_backtrace(DEBUG_BACKTRACE_PROVIDE_OBJECT, 64) as $frame) {
            if (($frame['class'] ?? null) === CompleteTurnEngine::class && ($frame['function'] ?? null) === 'execute') {
                $phase = $frame['args'][0] ?? null;
                $context = $frame['args'][1] ?? null;
                return [is_string($phase) ? $phase : null, $context instanceof TurnContext ? $context : null];
            }
        }
        return [null, null];
    }

    private function observeState(TurnContext $context): int
    {
        foreach ($this->states as $index => $state) {
            if ($state === $context->state) {
                return $index;
            }
        }
        $index = count($this->states);
        // Retain references so spl_object_id reuse cannot hide an attempt reusing state.
        $this->states[] = $context->state;
        $this->contextIdentities[] = [
            'run_id' => $context->run->id, 'world_id' => $context->world->id,
            'ruleset_id' => $context->ruleset->id, 'target_turn' => $context->targetTurn, 'random_seed' => $context->randomSeed,
        ];
        return $index;
    }

    private function latestAuditBatch(TurnContext $context, int $count): array
    {
        return DB::table('audit_events')->where('world_id', $context->world->id)
            ->where('turn', $context->targetTurn)->orderByDesc('id')->limit($count)->get()->reverse()->values()
            ->map(function (object $record): array {
                $row = (array) $record;
                unset($row['id']);
                $row['metadata'] = json_decode($row['metadata'], true, flags: JSON_THROW_ON_ERROR);
                return $this->auditCanonicalize($row);
            })->all();
    }

    private function rollbackComparableTables(array $snapshot): array
    {
        $tables = $snapshot['tables'];
        // The run and admission slot are control records created outside the game TX.
        unset($tables['turn_runs'], $tables['turn_execution_slots']);
        return $tables;
    }

    private function expandedWorld(int $expectedCells): World
    {
        $world = app(OceanWorldGenerator::class)->initialize(WorldGenerationProfile::Production);
        $target = match ($expectedCells) {
            4_096 => new MapBounds(0, 63, 0, 63, 16),
            9_216 => new MapBounds(-16, 79, -16, 79, 16),
            default => $this->fail("Unsupported expanded World cell count {$expectedCells}."),
        };
        app(WorldExpansionService::class)->expand(
            $world->fresh(),
            new MapBounds(0, 59, 0, 59, 16),
            $target,
        );

        return $world->fresh();
    }

    private function processCellProfileWorld(int $expectedCells, string $fixture): World
    {
        $world = match ($expectedCells) {
            1_024 => $this->lightweightWorld(),
            3_600 => app(OceanWorldGenerator::class)->initialize(WorldGenerationProfile::Production),
            default => $this->expandedWorld($expectedCells),
        };
        $nation = app(NationCreationService::class)->create(
            User::factory()->create(),
            $world,
            "Process Profile {$fixture} {$expectedCells}",
            'Process Profile Owner',
        );
        $nation->update(['money' => 1_000_000]);
        $wheatId = (int) ResourceDefinition::query()->where('key', 'wheat')->valueOrFail('id');
        NationResource::query()
            ->where('nation_id', $nation->id)
            ->where('resource_definition_id', $wheatId)
            ->update(['amount' => match ($fixture) {
                'famine' => 0,
                'growth' => 1_000_000_000,
                default => 1_000_000,
            }]);
        if ($fixture === 'normal') {
            return $world;
        }

        $space = $this->surfaceMapSpace($world);
        $capitalCellId = (int) $nation->capital()->valueOrFail('map_cell_id');
        $plain = TerrainDefinition::query()->where('key', 'plain')->firstOrFail();
        $forest = TerrainDefinition::query()->where('key', 'forest')->firstOrFail();
        $factory = FacilityDefinition::query()->where('key', 'factory')->firstOrFail();
        $city = FacilityDefinition::query()->where('key', 'city')->firstOrFail();
        $defense = FacilityDefinition::query()->where('key', 'defense')->firstOrFail();
        $cellIds = MapCell::query()
            ->where('map_space_id', $space->id)
            ->whereKeyNot($capitalCellId)
            ->orderBy('id')
            ->pluck('id')
            ->map(static fn ($id): int => (int) $id)
            ->all();
        MapCell::query()->whereIn('id', $cellIds)->update([
            'terrain_definition_id' => $plain->id,
            'facility_definition_id' => null,
            'monument_definition_id' => null,
            'owner_nation_id' => $nation->id,
            'population' => 0,
            'terrain_quantity' => null,
            'facility_scale' => null,
            'facility_experience' => null,
            'facility_operational_state' => null,
        ]);

        if ($fixture === 'mature') {
            $factoryIds = [];
            $cityIds = [];
            foreach ($cellIds as $index => $cellId) {
                if ($index % 4 === 0) {
                    $factoryIds[] = $cellId;
                } elseif ($index % 4 === 1) {
                    $cityIds[] = $cellId;
                }
            }
            $this->setProfileFacility($factoryIds, $factory->id, 1, 0);
            $this->setProfileFacility($cityIds, $city->id, null, 1_000);
        } elseif ($fixture === 'fire') {
            $this->setProfileFacility($cellIds, $factory->id, 1, 0);
        } elseif ($fixture === 'protection') {
            $factoryIds = [];
            $forestIds = [];
            foreach ($cellIds as $index => $cellId) {
                if ($index % 2 === 0) {
                    $factoryIds[] = $cellId;
                } else {
                    $forestIds[] = $cellId;
                }
            }
            $this->setProfileFacility($factoryIds, $factory->id, 1, 0);
            MapCell::query()->whereIn('id', $forestIds)->update([
                'terrain_definition_id' => $forest->id,
                'terrain_quantity' => $forest->initial_quantity,
            ]);
        } elseif ($fixture === 'famine') {
            $this->setProfileFacility($cellIds, $defense->id, null, 0);
        } elseif ($fixture === 'growth') {
            $townIds = [];
            $forestIds = [];
            foreach ($cellIds as $index => $cellId) {
                if ($index % 3 === 1) {
                    $townIds[] = $cellId;
                } elseif ($index % 3 === 2) {
                    $forestIds[] = $cellId;
                }
            }
            $town = FacilityDefinition::query()->where('key', 'town')->firstOrFail();
            $this->setProfileFacility($townIds, $town->id, null, 3_000);
            MapCell::query()->whereIn('id', $forestIds)->update([
                'terrain_definition_id' => $forest->id,
                'terrain_quantity' => $forest->initial_quantity,
            ]);
        }

        return $world;
    }

    /** @param list<int> $cellIds */
    private function setProfileFacility(array $cellIds, int $facilityId, ?int $scale, int $population): void
    {
        MapCell::query()->whereIn('id', $cellIds)->update([
            'facility_definition_id' => $facilityId,
            'facility_scale' => $scale,
            'facility_experience' => null,
            'facility_operational_state' => 'operational',
            'population' => $population,
        ]);
    }

    /** External synthetic-state capture; it runs outside the Turn measurement window. */
    private function auditStateSnapshot(): array
    {
        // Authentication/cache contents are never selected. Every other public table is captured.
        $excludedTables = ['auth_identities', 'users', 'sessions', 'cache', 'cache_locks'];
        $excludedColumns = ['attachment_token'];
        $tableNames = DB::table('information_schema.tables')
            ->where('table_schema', 'public')->where('table_type', 'BASE TABLE')
            ->orderBy('table_name')->pluck('table_name')->all();
        $tables = [];
        $digests = [];
        foreach ($tableNames as $table) {
            if (in_array($table, $excludedTables, true)) {
                continue;
            }
            $rows = [];
            $columns = DB::table('information_schema.columns')
                ->where('table_schema', 'public')->where('table_name', $table)
                ->whereNotIn('column_name', $excludedColumns)
                ->orderBy('ordinal_position')->pluck('column_name')->all();
            foreach (DB::table($table)->select($columns)->get() as $record) {
                $row = (array) $record;
                foreach ($excludedColumns as $column) {
                    unset($row[$column]);
                }
                foreach ($row as $column => $value) {
                    if (is_string($value) && in_array(substr($value, 0, 1), ['[', '{'], true)) {
                        try {
                            $row[$column] = json_decode($value, true, 512, JSON_THROW_ON_ERROR);
                        } catch (\JsonException) {
                            // Non-JSON player text retains its original value.
                        }
                    }
                }
                if ($table === 'turn_runs' && is_array($row['phase_results'] ?? null)) {
                    foreach ($row['phase_results'] as &$phase) {
                        unset($phase['duration_ms']);
                    }
                    unset($phase);
                }
                $rows[] = $this->auditCanonicalize($row);
            }
            usort($rows, static fn (array $left, array $right): int => isset($left['id'], $right['id'])
                ? $left['id'] <=> $right['id']
                : strcmp(json_encode($left, JSON_THROW_ON_ERROR), json_encode($right, JSON_THROW_ON_ERROR)));
            $tables[$table] = $rows;
            $digests[$table] = ['rows' => count($rows), 'sha256' => hash('sha256', json_encode($rows, JSON_THROW_ON_ERROR))];
        }
        return [
            'excluded_tables' => $excludedTables,
            'excluded_columns' => $excludedColumns,
            'additional_exclusion' => 'turn_runs.phase_results[*].duration_ms only',
            'tables' => $tables,
            'table_digests' => $digests,
            'sha256' => hash('sha256', json_encode($tables, JSON_THROW_ON_ERROR)),
        ];
    }

    private function auditCanonicalize(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }
        if (! array_is_list($value)) {
            ksort($value);
        }
        foreach ($value as $key => $child) {
            $value[$key] = $this->auditCanonicalize($child);
        }
        return $value;
    }


}

final readonly class RetryFixtureSeedGenerator implements TurnSeedGenerator
{
    public function __construct(private string $seed) {}
    public function generate(World $world, int $targetTurn, RulesetVersion $ruleset): string
    {
        return $this->seed;
    }
}
