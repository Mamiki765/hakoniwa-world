<?php
$expected = json_decode(file_get_contents('/evidence/source-manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$inputs = [...$expected['all_app_sha256'], ...$expected['check_inputs_sha256']];
$results = [];
foreach ($inputs as $input) {
    $path = '/var/www/html/'.substr($input['path'], strlen('product/'));
    $actual = hash_file('sha256', $path);
    $results[] = ['path' => $input['path'], 'sha256' => $actual, 'matches' => $actual === $input['sha256']];
}
$failures = array_values(array_filter($results, static fn (array $row): bool => ! $row['matches']));
echo json_encode(['combined_tree' => $expected['combined_tree'], 'php_version' => PHP_VERSION, 'inputs_count' => count($results), 'mismatches' => $failures, 'files' => $results], JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR), "\n";
exit($failures === [] ? 0 : 1);
