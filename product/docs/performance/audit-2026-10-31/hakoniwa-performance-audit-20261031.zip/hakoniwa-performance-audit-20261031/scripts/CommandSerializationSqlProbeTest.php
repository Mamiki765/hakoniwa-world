<?php
declare(strict_types=1);

namespace Tests\Feature;

use App\Application\NationCreationService;
use App\Models\CommandDefinition;
use App\Models\MapCell;
use App\Models\NationCommandQueue;
use App\Models\NationCommandQueueItem;
use App\Models\NationMembership;
use App\Models\User;
use Illuminate\Database\Events\QueryExecuted;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Tests\Concerns\CreatesTestWorlds;
use Tests\TestCase;

/** Research-only query-count probe; not installed into the product test suite. */
final class CommandSerializationSqlProbeTest extends TestCase
{
    use CreatesTestWorlds;
    use RefreshDatabase;

    public function test_repeated_queue_targets_are_reread_per_row(): void
    {
        // The same supported synthetic World/Nation factory as CommandQueueAndSalePolicyTest::nation.
        $world = $this->lightweightWorld();
        $user = User::factory()->create();
        $nation = app(NationCreationService::class)->create($user, $world, '計画測定島', '合成試験島主');
        $space = $this->surfaceMapSpace($world);
        $capital = $nation->capital()->firstOrFail();
        $cell = MapCell::query()->whereKey($capital->map_cell_id)->with(['terrain', 'facility'])->firstOrFail();
        $this->assertNotNull($cell->facility);
        $command = CommandDefinition::query()->where('ruleset_version_id', $world->ruleset_version_id)
            ->where('key', 'finance')->firstOrFail();
        $membershipId = NationMembership::query()->where('nation_id', $nation->id)->valueOrFail('id');
        $queue = NationCommandQueue::query()->create([
            'nation_id' => $nation->id, 'map_space_id' => $space->id, 'version' => 1,
        ]);
        $makeItem = static function (int $position) use ($queue, $world, $command, $cell, $membershipId): void {
            NationCommandQueueItem::query()->create([
                'nation_command_queue_id' => $queue->id, 'command_definition_id' => $command->id,
                'request_ruleset_version_id' => $world->ruleset_version_id,
                'queue_position' => $position, 'target_x' => $cell->x, 'target_y' => $cell->y,
                'quantity' => 1, 'parameters' => (object) [], 'status' => 'queued',
                'queued_by_membership_id' => $membershipId, 'request_key' => (string) Str::uuid(),
                'queued_at' => now(), 'failure_metadata' => [],
            ]);
        };
        $makeItem(1);
        $queries = [];
        $recording = false;
        DB::listen(static function (QueryExecuted $query) use (&$queries, &$recording): void {
            if ($recording) {
                $queries[] = ['sql' => $query->sql, 'bindings' => $query->bindings, 'time_ms' => $query->time];
            }
        });
        $path = "/api/v1/nations/{$nation->id}/map-spaces/{$space->id}/command-queue";
        $measurements = [];
        foreach ([1, 30] as $count) {
            if ($count === 30) {
                for ($position = 2; $position <= 30; $position++) {
                    $makeItem($position);
                }
            }
            $queries = [];
            $recording = true;
            $start = hrtime(true);
            $response = $this->actingAs($user)->getJson($path);
            $elapsed = (hrtime(true) - $start) / 1e6;
            $recording = false;
            $response->assertOk()->assertJsonCount($count, 'data.items')
                ->assertJsonPath('data.explicit_count', $count)
                ->assertJsonPath('data.items.0.command_key', 'finance');
            $tableCount = static fn (string $table): int => count(array_filter($queries,
                static fn (array $q): bool => str_contains(strtolower($q['sql']), 'from "'.$table.'"')));
            $targetQueries = array_values(array_filter($queries, static fn (array $q): bool =>
                str_contains($q['sql'], 'from "map_cells"')
                && str_contains($q['sql'], '"map_space_id" = ?')
                && str_contains($q['sql'], '"x" = ?') && str_contains($q['sql'], '"y" = ?')));
            $measurements[] = [
                'queue_items' => $count, 'distinct_fixed_targets' => 1,
                'elapsed_ms' => $elapsed, 'all_select_and_write_queries' => count($queries),
                'target_cell_queries' => count($targetQueries),
                'terrain_queries' => $tableCount('terrain_definitions'),
                'facility_queries' => $tableCount('facility_definitions'), 'queries' => $queries,
            ];
        }
        file_put_contents('/audit/evidence/command-serialization-queries.json', json_encode([
            'kind' => 'current_code_isolated_pg_query_count',
            'source_sha' => '2e93ec918774ad64d787aba99fc59a7bc3e54d16',
            'php' => PHP_VERSION,
            'fixture' => 'Debug32x32 synthetic World, one synthetic owner Nation; finance plans target the same capital facility',
            'measurements' => $measurements,
            'limits' => 'One test case, one request per Q=1/Q=30. Current code only; elapsed includes route/Laravel cold differences. No candidate patch or latency-speedup claim.',
        ], JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR));
    }
}
