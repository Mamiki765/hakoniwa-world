<?php
namespace App\Services {
    function getimagesize($path) { $GLOBALS['image_reads']++; return \getimagesize($path); }
}
namespace {
    function config($key,$fallback=null) { return $GLOBALS['cfg'][$key] ?? $fallback; }
    require '/var/www/html/app/Services/AssetManifestResolver.php';
    $dir='/audit/asset-fixture'; @mkdir($dir);
    file_put_contents($dir.'/land0.gif',base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7'));
    $GLOBALS['cfg']=['hakoniwa.assets.path'=>$dir,'hakoniwa.assets.base_url'=>'/assets/hakoniwa-tiles','hakoniwa.assets.allowed_extensions'=>['gif']];
    $rows=[];
    foreach ([false,true] as $memo) {
        $samples=[];$counts=[];$checks=[];
        for ($round=0;$round<3;$round++) {
            $GLOBALS['image_reads']=0;$resolver=new App\Services\AssetManifestResolver;$cache=[];$outputs=[];$t=hrtime(true);
            for($i=0;$i<256;$i++) {
                $outputs[]=$memo ? ($cache['sea'] ??= $resolver->resolve('tile.sea','海')) : $resolver->resolve('tile.sea','海');
            }
            $samples[]=(hrtime(true)-$t)/1e6;$counts[]=$GLOBALS['image_reads'];$checks[]=hash('sha256',serialize($outputs));
        }
        $rows[]=['candidate_request_local_memo'=>$memo,'samples_ms'=>$samples,'getimagesize_calls'=>$counts,'checksums'=>$checks];
    }
    echo json_encode(['php'=>PHP_VERSION,'workload'=>'256 same-asset resolves, 3 short rounds, synthetic 1px GIF, existing resolver with config stub; no DB','rows'=>$rows],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),"\n";
}
