from pathlib import Path
import csv,json,collections
out=Path('/workspace/perf-audit-20261031'); files=['command-coverage.csv','turn-coverage.csv','battle-coverage.csv','api-db-coverage.csv','foundation-coverage.csv','frontend-coverage.csv','supplement-coverage.csv']; rows=[]
for name in files:
    for n,r in enumerate(csv.DictReader((out/name).open()),1):
        rows.append({'row_id':f'{name}:{n+1}','scope':name.removesuffix('-coverage.csv'),'path':r.get('path') or r.get('source') or r.get('path_group',''),'line':r.get('line',''),'entry':r.get('entry') or r.get('entrypoint') or r.get('path_group') or r.get('group') or r.get('scope',''),'confirmation':r.get('inspection') or r.get('review') or r.get('confirmation') or r.get('status',''),'result':r.get('result') or r.get('assessment') or r.get('judgement',''),'candidate_ids':r.get('candidate') or r.get('candidate_ids') or r.get('candidates',''),'evidence':r.get('evidence') or r.get('static_evidence') or r.get('basis') or r.get('notes',''),'dynamic_limit':r.get('dynamic_limit') or r.get('unverified') or r.get('measurement_limit') or r.get('limit') or r.get('measurement') or r.get('limits',''),'source_sha':r.get('fixed_sha') or r.get('source_sha') or r.get('sha') or '2e93ec918774ad64d787aba99fc59a7bc3e54d16'})
with (out/'coverage-ledger.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={'rows':len(rows),'by_source':dict(collections.Counter(r['scope'] for r in rows)),'pending_confirmation_rows':[{'row_id':r['row_id'],'entry':r['entry'],'state':r['confirmation'],'limit':r['dynamic_limit']} for r in rows if '未確認' in r['confirmation']],'meaning':'異なる粒度の台帳をconcat、同じfile/処理の重複を含む。行数を独立処理数/実行分岐数としない。参照元の動的未確認列も確認する。'}
(out/'ledger-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False))
