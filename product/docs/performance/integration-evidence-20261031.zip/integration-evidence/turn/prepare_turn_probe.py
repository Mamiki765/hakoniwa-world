from pathlib import Path
import hashlib

source=Path('/workspace/hakoniwa-perf-integration-base/product/tests/Feature/TurnRuntimePerformanceTest.php')
target=Path('/workspace/perf-integration-20261031/turn/TurnIntegrationSnapshotTest.php')
text=source.read_text()
assert 'final class TurnRuntimePerformanceTest extends TestCase' in text
text=text.replace('namespace Tests\\Feature;', 'namespace Tests\\IntegrationAudit;', 1)
text=text.replace('final class TurnRuntimePerformanceTest extends TestCase', 'final class TurnIntegrationSnapshotTest extends TestCase', 1)
fixture="""        $expectedCells = 3_600;
        $world = $this->processCellProfileWorld($expectedCells, 'mature');"""
assert fixture in text
text=text.replace(fixture,"""        // External paired-run probe: fixture clocks/identities are equal in both DBs.
        \\Illuminate\\Support\\Carbon::setTestNow('2026-10-31 12:00:00 UTC');
        fake()->seed(20261031);
        Str::createUuidsUsing(static fn () => \\Ramsey\\Uuid\\Uuid::fromString('00000000-0000-4000-8000-000000000031'));
        $expectedCells = 3_600;
        $world = $this->processCellProfileWorld($expectedCells, 'mature');""",1)

start=text.index('    private function measureTurn(World $world, ?string $seed = null): array')
end=text.index('    /** @param array<string, mixed> $measurement */',start)
method=text[start:end]
method=method.replace('        $probe->start();\n        $started = hrtime(true);', '        $inputState = $this->auditStateSnapshot();\n        $probe->start();\n        $startedCpu = integrationAuditCpuSnapshot();\n        $started = hrtime(true);',1)
method=method.replace('        $this->assertSame(\'completed\', $run->status);', "        $endedCpu = integrationAuditCpuSnapshot();\n        $this->assertSame('completed', $run->status);",1)
method=method.replace("        return [\n            'total_wall_ms' => $wallMs,", "        $measurement = [\n            'total_wall_ms' => $wallMs,\n            'total_cpu_user_ms' => round($endedCpu[0] - $startedCpu[0], 3),\n            'total_cpu_system_ms' => round($endedCpu[1] - $startedCpu[1], 3),",1)
method=method.replace("            'phases' => $probe->phases(),\n        ];", """            'phases' => $probe->phases(),
        ];
        $evidence = [
            'label' => getenv('TURN_AUDIT_LABEL'),
            'runtime' => PHP_VERSION,
            'fixture' => 'existing 60x60-mature, frozen clock/Faker/registration UUID only',
            'random_seed' => $run->random_seed,
            'rng_source_sha256' => [
                'DeterministicRandomStream' => hash_file('sha256', app_path('Domain/Turn/DeterministicRandomStream.php')),
                'TurnRandomStreamFactory' => hash_file('sha256', app_path('Domain/Turn/TurnRandomStreamFactory.php')),
            ],
            'measurement' => $measurement,
            'input' => $inputState,
            'output' => $this->auditStateSnapshot(),
        ];
        $path = getenv('TURN_AUDIT_OUTPUT');
        if (! is_string($path) || $path === '') {
            throw new \\RuntimeException('Explicit evidence path is required.');
        }
        file_put_contents($path, json_encode($evidence, JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        return $measurement;""",1)
assert 'inputState' in method and '$measurement =' in method and 'return $measurement' in method
text=text[:start]+method+text[end:]

helpers=r'''
    /** External synthetic-state capture; it runs outside the Turn measurement window. */
    private function auditStateSnapshot(): array
    {
        $excludedTables = [
            'auth_identities', 'users', 'sessions', 'migrations', 'cache', 'cache_locks',
            'announcements', 'inquiries', 'moderation_records', 'island_messages',
            'guide_conversation_topics', 'merchant_conversation_topics',
        ];
        $excludedColumns = ['created_at', 'updated_at', 'occurred_at', 'started_at', 'completed_at', 'generated_at'];
        $tableNames = DB::table('information_schema.tables')
            ->where('table_schema', 'public')->where('table_type', 'BASE TABLE')
            ->orderBy('table_name')->pluck('table_name')->all();
        $tables = [];
        $digests = [];
        foreach ($tableNames as $table) {
            if (in_array($table, $excludedTables, true)) {
                continue;
            }
            $rows = [];
            foreach (DB::table($table)->get() as $record) {
                $row = (array) $record;
                foreach ($excludedColumns as $column) {
                    unset($row[$column]);
                }
                foreach ($row as $column => $value) {
                    if (is_string($value) && in_array(substr($value, 0, 1), ['[', '{'], true)) {
                        try {
                            $row[$column] = json_decode($value, true, 512, JSON_THROW_ON_ERROR);
                        } catch (\JsonException) {
                            // Non-JSON player text retains its original value.
                        }
                    }
                }
                if ($table === 'turn_runs' && is_array($row['phase_results'] ?? null)) {
                    foreach ($row['phase_results'] as &$phase) {
                        unset($phase['duration_ms']);
                    }
                    unset($phase);
                }
                $rows[] = $this->auditCanonicalize($row);
            }
            usort($rows, static fn (array $left, array $right): int => isset($left['id'], $right['id'])
                ? $left['id'] <=> $right['id']
                : strcmp(json_encode($left, JSON_THROW_ON_ERROR), json_encode($right, JSON_THROW_ON_ERROR)));
            $tables[$table] = $rows;
            $digests[$table] = ['rows' => count($rows), 'sha256' => hash('sha256', json_encode($rows, JSON_THROW_ON_ERROR))];
        }
        return [
            'excluded_tables' => $excludedTables,
            'excluded_columns' => $excludedColumns,
            'additional_exclusion' => 'turn_runs.phase_results[*].duration_ms only',
            'tables' => $tables,
            'table_digests' => $digests,
            'sha256' => hash('sha256', json_encode($tables, JSON_THROW_ON_ERROR)),
        ];
    }

    private function auditCanonicalize(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }
        if (! array_is_list($value)) {
            ksort($value);
        }
        foreach ($value as $key => $child) {
            $value[$key] = $this->auditCanonicalize($child);
        }
        return $value;
    }

'''
pos=text.index('    /** @param array<string, mixed> $measurement */')
text=text[:pos]+helpers+text[pos:]
text=text.replace('    private int $phaseStartMemory = 0;', '    private int $phaseStartMemory = 0;\n\n    private array $phaseStartedCpu = [0.0, 0.0];',1)
text=text.replace('        $this->phaseStartedAt = hrtime(true);', '        $this->phaseStartedAt = hrtime(true);\n        $this->phaseStartedCpu = integrationAuditCpuSnapshot();',1)
text=text.replace("        $this->results[$phase] = [", "        $endedCpu = integrationAuditCpuSnapshot();\n        $this->results[$phase] = [\n            'cpu_user_ms' => round($endedCpu[0] - $this->phaseStartedCpu[0], 3),\n            'cpu_system_ms' => round($endedCpu[1] - $this->phaseStartedCpu[1], 3),",1)
text += r'''

/** Current PHP process CPU only; PostgreSQL runs in a separate container. */
function integrationAuditCpuSnapshot(): array
{
    $usage = getrusage();

    return [
        ($usage['ru_utime.tv_sec'] * 1000) + ($usage['ru_utime.tv_usec'] / 1000),
        ($usage['ru_stime.tv_sec'] * 1000) + ($usage['ru_stime.tv_usec'] / 1000),
    ];
}
'''
target.write_text(text)
print('Prepared external probe:',target)
print('Baseline source SHA256:',hashlib.sha256(source.read_bytes()).hexdigest())
print('Probe SHA256:',hashlib.sha256(target.read_bytes()).hexdigest())
