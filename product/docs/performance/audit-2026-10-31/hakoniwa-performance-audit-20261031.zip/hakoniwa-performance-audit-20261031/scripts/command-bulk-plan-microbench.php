<?php
declare(strict_types=1);

require getcwd().'/vendor/autoload.php';

use App\Application\CommandQueueService;
use Illuminate\Database\Eloquent\Collection;

// Exercise the current private pure planning method without booting the app or accessing any DB.
$service = (new ReflectionClass(CommandQueueService::class))->newInstanceWithoutConstructor();
$method = new ReflectionMethod(CommandQueueService::class, 'bulkPlan');
$candidateCount = 10_000;
$candidates = [];
for ($i = 0; $i < $candidateCount; $i++) {
    $candidates[] = ['definition' => null, 'x' => $i, 'y' => 0];
}
$active = new Collection;
$baseline = memory_get_usage();
$start = hrtime(true);
$plans = [];
foreach (['overflow', 'fill_available'] as $policy) {
    $plans[$policy] = $method->invoke($service, $active, $candidates, 1, 30, 1, $policy);
}
$elapsed = (hrtime(true) - $start) / 1e6;
$after = memory_get_usage();
$drops = array_map(static fn (array $plan): int => count($plan['dropped']), $plans);
$inserted = array_map(static fn (array $plan): int => $plan['inserted_count'], $plans);
echo json_encode([
    'kind' => 'current_method_isolated_php_algorithm_measurement',
    'source_sha' => '2e93ec918774ad64d787aba99fc59a7bc3e54d16', 'php' => PHP_VERSION,
    'fixture' => ['active_items' => 0, 'candidates' => $candidateCount, 'queue_limit' => 30, 'group_size' => 1],
    'plan_dropped_generated_wrappers' => $drops,
    'plan_inserted_counts' => $inserted,
    'total_dropped_wrappers' => array_sum($drops),
    'elapsed_ms' => $elapsed,
    'memory_baseline_bytes' => $baseline, 'retained_memory_delta_bytes' => $after - $baseline,
    'peak_memory_bytes' => memory_get_peak_usage(),
    'limits' => 'One current-code method invocation per policy. Candidate definitions are unused placeholders; no ORM/DB/snapshot/HTTP cost measured. No optimized candidate or whole-request speedup claim.',
], JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR), "\n";
