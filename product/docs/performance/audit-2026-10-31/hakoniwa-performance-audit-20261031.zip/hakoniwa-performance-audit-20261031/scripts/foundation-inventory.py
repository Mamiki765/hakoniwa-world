from pathlib import Path
import re,csv,json,collections
root=Path('/workspace/hakoniwa-world'); out=Path('/workspace/perf-audit-20261031'); sha='2e93ec918774ad64d787aba99fc59a7bc3e54d16'
scopes=['Domain','Models','Http/Requests','Http/Middleware','Rules','Providers']; rows=[]
known={'UnderseaConstructionPolicy.php':('改善候補（既報）','command.md','工作船反復照会。command担当の到達条件/SQL式を正本にする'), 'NationCapacityResolver.php':('改善候補（既報）','turn.md','capacity sources読取とitem effect catalog検証。Turn担当へ統合'), 'SecretaryItemGameplayContract.php':('改善候補（既報）','turn.md','validatedEffectCatalog反復。SecretaryItemCatalog再構築と重複計上しない'), 'DeterministicRandomStream.php':('改善候補（既報）','turn.md','HMAC block unpack局所候補。ゲーム確率・診断を維持'), 'TurnRandomStreamFactory.php':('改善候補（既報）','turn.md','label別stream memoあり。RNG版変更案は親判断'), 'AlphaV1CombatModel.php':('改善候補（既報）','battle.md','AI結果再利用の短期probeはbattle担当を正本'), 'PriorityCombatAi.php':('改善候補（既報）','battle.md','AI走査は戦闘担当の結果と統合'), 'SurfaceShipCatalog.php':('改善候補','FND-01','direct definitionsは全定義validate/DTO生成/sortを反復。optionsのみmemo済み'), 'SecretaryItemCatalog.php':('改善候補','FND-02/T01','immutable definitions毎回再構築、categoryLimitsは同categoryごと全走査反復'), 'RulesetVersion.php':('問題なし（既修正確認）','5.8.2','settingsは生JSON文字列をkeyにmodel内decode再利用。再提案除外'), 'SurfaceCommandProjectionMemo.php':('問題なし（既修正確認）','command.md','request内projection memoの入れ物。read境界を跨いだ再利用へ拡張しない')}
for scope in scopes:
 for p in sorted((root/'product/app'/scope).rglob('*.php')):
  text=p.read_text(); ls=text.splitlines(); rel=str(p.relative_to(root)); name=p.name
  methods=[f'{i}:{m.group(1)}' for i,l in enumerate(ls,1) if (m:=re.search(r'function\s+(\w+)\s*\(',l))]
  db=[str(i) for i,l in enumerate(ls,1) if re.search(r'::query\(|DB::|->lockForUpdate\(|->(?:firstOrFail|firstOrCreate|find)\(',l)]
  loops=[str(i) for i,l in enumerate(ls,1) if re.search(r'\b(?:foreach|for|while)\s*\(|usort\(',l)]
  kind='pure runtime helper'; owner='foundation'
  if scope=='Models': kind='Eloquent model: attributes/casts/relations/scopes'; note='全method構造確認。relation宣言自体はSQLを発行しない。呼出元のeager/lazyとcast反復は各経路台帳で評価'
  elif scope=='Http/Requests': kind='HTTP authorization/input validation'; note='全rules/authorize/normalization構造確認。bounded入力/文字列/ID/配列shapeの検証。認可・入力validation省略は候補にしない'
  elif scope=='Http/Middleware': kind='HTTP admission/authorization/cache policy'; note='全handle構造確認。admission・認可・cache headerは必要契約、除去しない。詳細はAPI/battle台帳'
  elif scope=='Rules': kind='validation'; note='text/画像署名・dimension検証。upload単位の読取は安全境界として維持。画像全decodeへの変更はしない'
  elif scope=='Providers': kind='DI/event registration'; note='boot/register構造確認。Turn pipeline 12phase、lock singleton、resolver singleton登録。独立queue Jobやschedule登録なし'
  elif '/Underground/' in rel: kind='combat/facility/progression helper'; owner='battle'; note='構造走査（IO/SQL/loop）確認済み。詳細戦闘実行・最大round/party/ログ量はbattle.mdへ委譲'
  elif '/Turn/' in rel: kind='turn state/RNG/pipeline helper'; owner='turn'; note='構造走査（IO/SQL/loop）確認済み。詳細phase/RNG/TurnState mutationはturn.mdへ委譲'
  elif '/Ruleset/' in rel: kind='authoring validator/guard'; note='RulesetAuthoringValidatorはpublish/validate CLIから到達するcold path。CurrentRulesetGuardは取得済identity照合、追加SQLなし。検証全廃はしない'
  elif re.search(r'(Exception|Result|Quote|Context|Intent|Definition|Bounds|Behavior|Policy|Projection|Facts|Modifier)\.php$',name) and len(ls)<130: kind='DTO/enum/policy/pure helper'; note='全method構造確認。DB/ファイル/networkの直接呼出なし、またはCSV query行で列挙。定数/整数/状態判定の局所処理'
  else: note='全method構造とloop/直接DB/IOを走査。設定/入力数への線形計算や小catalogのsortを評価。主経路はcommand/turn/API/battle詳細台帳に接続'
  status='問題なし（追加候補なし）'; ref='foundation.md'
  if name in known: status,ref,note=known[name]
  if name=='MapCellStateService.php': note='transitionTerrainのFacility::findを確認。主経路は直前setFacility(null)でfindへ入らないため一般N+1として除外。部分的直接callの全分岐SQL実測は未実施'
  if name=='GridCoordinate.php': note='radius/ringはsquare候補(2r+1)^2生成→distance filter。現行主用途radius1/2等、ring直接列挙は低効果・順序検証必要で優先提案せず'
  if name in ['UserMembershipMutationLock.php','WorldMutationLock.php']: note='advisory acquire/releaseとdepth再入memo確認。WorldはPDO同一性保持、assertHeldはSQLなし。lock省略/再接続迂回は候補外'
  if name=='UpdateNationProfileRequest.php': note='authorizeにmembership EXISTS1回。権限確認に必要。定数3field正規化のみ、件数比例追加SQLなし'
  if name=='Secretary.php': note='created hookでsurfaceState1INSERT、lockSurfaceStateは1SELECT FOR UPDATEしてrelation更新。通常relation宣言をSQLと数えない'
  if name=='UndergroundProfile.php': note='skillAllocationMapは既読relation再利用fallback GET。反復呼出でrelation未設定なら再GET可能だがcaller eagerあり/なしはbattle台帳参照、独立N+1断定なし'
  rows.append(dict(path=rel,scope=scope,classification=kind,confirmation='構造確認済み',assessment=status,detail_owner=owner,reference=ref,lines=len(ls),methods=';'.join(methods),direct_db_line_markers=';'.join(db),loop_line_markers=';'.join(loops),basis=note,unverified='本番size/latency/PG plan/全入力分岐のdynamic costは未測定',sha=sha))
with (out/'foundation-coverage.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
print(json.dumps({'files':len(rows),'by_scope':dict(collections.Counter(x['scope'] for x in rows)),'by_assessment':dict(collections.Counter(x['assessment'] for x in rows)),'methods':sum(len(x['methods'].split(';')) if x['methods'] else 0 for x in rows)},ensure_ascii=False))
