<?php
declare(strict_types=1);
require '/source/product/app/Domain/Turn/DeterministicRandomStream.php';
require '/source/product/app/Domain/Turn/TurnRandomStreamFactory.php';

use App\Domain\Turn\DeterministicRandomStream;
use App\Domain\Turn\TurnRandomStreamFactory;

// Measurement-only alternate representation of exactly the same HMAC blocks.
final class AuditBlockWords {
    private string $counter = "\0\0\0\0\0\0\0\0";
    private array $words = [];
    private int $offset = 8;
    public function __construct(private string $key) {}
    public function integer(mixed $minimum, mixed $maximum): int {
        if (!is_int($minimum) || !is_int($maximum) || $minimum > $maximum || $minimum < -2147483648 || $maximum > 2147483647) throw new InvalidArgumentException();
        $width = $maximum - $minimum + 1;
        $limit = intdiv(4294967296, $width) * $width;
        do {
            if ($this->offset === 8) {
                $this->words = array_values(unpack('N*', hash_hmac('sha256', $this->counter, $this->key, true)));
                $this->offset = 0;
                for ($i = 7; $i >= 0; --$i) {
                    $b = ord($this->counter[$i]);
                    if ($b < 255) { $this->counter[$i] = chr($b + 1); break; }
                    $this->counter[$i] = "\0";
                    if ($i === 0) throw new LogicException();
                }
            }
            $sample = $this->words[$this->offset++];
        } while ($sample >= $limit);
        return $minimum + $sample % $width;
    }
}

final class AuditNative {
    private Random\Randomizer $rng;
    public function __construct(string $key) { $this->rng = new Random\Randomizer(new Random\Engine\Xoshiro256StarStar($key)); }
    public function integer(mixed $minimum, mixed $maximum): int {
        if (!is_int($minimum) || !is_int($maximum) || $minimum > $maximum || $minimum < -2147483648 || $maximum > 2147483647) throw new InvalidArgumentException();
        return $this->rng->getInt($minimum, $maximum);
    }
}

$key = hash('sha256', 'audit-key', true);
$original = new DeterministicRandomStream($key);
$alternate = new AuditBlockWords($key);
// Includes maximal rejection probability, full signed range, one-value and ordinary bounds.
$bounds = [[0,10000],[-2147483648,2147483647],[-1,2147483647],[4,4],[-10,10]];
for ($i = 0; $i < 10000; ++$i) {
    [$a,$b] = $bounds[$i % count($bounds)];
    if ($original->integer($a,$b) !== $alternate->integer($a,$b)) throw new RuntimeException('Exact stream comparison failed');
}
$results = ['runtime'=>PHP_VERSION,'opcache_cli'=>ini_get('opcache.enable_cli'),'exact_comparison_draws'=>10000,'measurements'=>[]];
foreach ([DeterministicRandomStream::class,AuditBlockWords::class,AuditNative::class] as $class) {
    $times=[]; $checksums=[];
    for ($round=0;$round<3;++$round) {
        $rng = new $class($key); $sum=0;
        $start=hrtime(true);
        for($i=0;$i<100000;++$i) $sum += $rng->integer(0,10000);
        $times[]=(hrtime(true)-$start)/1e6; $checksums[]=$sum;
    }
    if (count(array_unique($checksums)) !== 1) throw new RuntimeException('Replay failed');
    $results['measurements'][]=['class'=>$class,'draws_per_round'=>100000,'milliseconds'=>$times,'checksum'=>$checksums[0]];
}
$factory=new TurnRandomStreamFactory(str_repeat('0',64));
$factory->stream('audit-label');
$start=hrtime(true);
for($i=0;$i<100000;++$i) $factory->stream('audit-label');
$results['factory_cached_stream_100000_ms']=(hrtime(true)-$start)/1e6;
echo json_encode($results,JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR),"\n";
