<?php
// External isolated probe. Does not change app/tests or connect to any database.
require '/var/www/html/vendor/autoload.php';
$app = require '/var/www/html/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use App\Application\Underground\UndergroundAlphaV1PlayerCatalog;
use App\Domain\Secretary\SecretaryItemCatalog;
use App\Domain\Underground\Combat\AlphaV1CombatModel;

$mode = $argv[1] ?? 'combined';
$checks = [];
$check = static function (string $name, bool $condition) use (&$checks): void {
    $checks[$name] = $condition;
    if (! $condition) {
        throw new RuntimeException('Probe failed: '.$name);
    }
};
$hash = static fn (mixed $value): string => hash('sha256', serialize($value));

$players = $app->make(UndergroundAlphaV1PlayerCatalog::class);
$sameResolver = $app->make(UndergroundAlphaV1PlayerCatalog::class);
$check('same_scope_resolver_lifetime_matches_version', ($players === $sameResolver) === ($mode === 'combined'));
$catalog = $players->explorationCatalog();
$catalogHash = $hash($catalog->manifest());
$zero = ['vitality'=>0,'might'=>0,'finesse'=>0,'spirit'=>0,'agility'=>0];
$definition = $players->explorationCombatDefinition('martial_red', 10, $zero, $players->starterWeapon(), 'synthetic scope probe');
$snapshot = $definition['player_snapshot'];
$enemy = $players->explorationEncounters()[0]['key'];
$model = $app->make(AlphaV1CombatModel::class);
$fight = $model->fightPlayerSnapshot($catalog, $snapshot, $enemy, 17, 4, 1000);
$changed = $snapshot;
$changed['current_hp'] = max(1, intdiv($snapshot['current_hp'], 2));
$otherFight = $model->fightPlayerSnapshot($catalog, $changed, $enemy, 17, 4, 1000);
$fightAgain = $model->fightPlayerSnapshot($catalog, $snapshot, $enemy, 17, 4, 1000);
$check('different_hp_reaches_fresh_mutable_combat_state', $fight->initialState['player']['hp'] === $snapshot['current_hp']
    && $otherFight->initialState['player']['hp'] === $changed['current_hp']
    && $fight->initialState['player']['hp'] !== $otherFight->initialState['player']['hp']);
$check('same_seed_replays_after_other_fight', $hash($fight) === $hash($fightAgain));
$check('combat_does_not_mutate_cached_catalog', $catalogHash === $hash($catalog->manifest()));
$check('combat_does_not_mutate_input_snapshot', $definition['player_snapshot'] === $snapshot);
$later = $players->explorationCombatDefinition('martial_red', 20, $zero, $players->starterWeapon(), 'synthetic scope probe');
$check('player_level_is_resolved_outside_catalog_cache', $definition['combat_stats'] !== $later['combat_stats']);

$items = $app->make(SecretaryItemCatalog::class);
$item = $items->definition(SecretaryItemCatalog::OLD_BOW);
$mutableCopy = $items->definitions();
$mutableCopy[SecretaryItemCatalog::OLD_BOW]['name'] = 'caller mutation';
$resolved = $items->definitionWithResolvedEconomics(SecretaryItemCatalog::OLD_BOW, SecretaryItemCatalog::RARITY_ARTIFACT, 1234);
$check('resolved_item_economics_are_per_call', $resolved['fixed_sale_price_money'] === 1234 && $items->definition(SecretaryItemCatalog::OLD_BOW) === $item);
$check('item_nested_copy_is_isolated', (new SecretaryItemCatalog)->definition(SecretaryItemCatalog::OLD_BOW) === $item);
$overridden = new class extends SecretaryItemCatalog {
    public string $probeName = 'first override';
    public function definitions(): array {
        $definitions = parent::definitions();
        $definitions[self::OLD_BOW]['name'] = $this->probeName;
        return $definitions;
    }
};
$firstOverride = $overridden->definition(SecretaryItemCatalog::OLD_BOW);
$overridden->probeName = 'next override';
$check('item_override_stays_live_after_warm_base_cache', $firstOverride['name'] === 'first override'
    && $overridden->definition(SecretaryItemCatalog::OLD_BOW)['name'] === 'next override'
    && $items->definition(SecretaryItemCatalog::OLD_BOW) === $item);

// Invoke the reset callback installed by the real framework QueueServiceProvider.
// No daemon loop, queue pop, job dispatch or database mutation is performed.
$worker = $app->make('queue.worker');
$property = new ReflectionProperty($worker, 'resetScope');
$resetScope = $property->getValue($worker);
$check('framework_worker_has_reset_scope_callback', $resetScope instanceof Closure);
$app->scoped('probe.scope-marker', static fn (): object => new stdClass);
$marker = $app->make('probe.scope-marker');
$resetScope();
$nextPlayers = $app->make(UndergroundAlphaV1PlayerCatalog::class);
$check('worker_callback_discards_scoped_instances', $marker !== $app->make('probe.scope-marker') && $players !== $nextPlayers);
$nextCatalog = $nextPlayers->explorationCatalog();
$check('next_scope_catalog_has_same_immutable_content', $catalogHash === $hash($nextCatalog->manifest()));
$nextFight = $model->fightPlayerSnapshot($nextCatalog, $snapshot, $enemy, 17, 4, 1000);
$check('next_scope_same_seed_has_same_result', $hash($fight) === $hash($nextFight));
$check('constant_item_catalog_remains_valid_across_worker_reset', $item === $app->make(SecretaryItemCatalog::class)->definition(SecretaryItemCatalog::OLD_BOW));
$check('worker_reset_and_fights_do_not_open_database_connections', $app->make('db')->getConnections() === []);

$result = [
    'mode'=>$mode, 'php'=>PHP_VERSION, 'framework'=>Illuminate\Foundation\Application::VERSION,
    'checks'=>$checks, 'checked_count'=>count($checks), 'catalog_hash'=>$catalogHash,
    'fight_hash'=>$hash($fight), 'changed_hp_fight_hash'=>$hash($otherFight),
    'item_hash'=>$hash($item), 'scope_reset_source'=>(new ReflectionFunction($resetScope))->getFileName(),
    'scope_reset_line'=>(new ReflectionFunction($resetScope))->getStartLine(),
    'database_connections'=>count($app->make('db')->getConnections()),
];
file_put_contents(__DIR__.'/scope-interaction-'.$mode.'.json', json_encode($result, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n");
echo json_encode($result, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n";
