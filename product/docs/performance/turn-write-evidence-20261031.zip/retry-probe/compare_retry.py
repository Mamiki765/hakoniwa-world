from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).parent
clean = json.loads((ROOT / 'clean.json').read_text())
fault = json.loads((ROOT / 'fault-v2.json').read_text())


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(',', ':')).encode()).hexdigest()


def gameplay(report):
    # Keep all other numeric IDs and all captured timestamps. These two tables
    # have explicitly different attempt diagnostics/audit sequences after C1.
    return {key: rows for key, rows in report['output']['tables'].items()
            if key not in ['audit_events', 'turn_runs']}


def turn_audit(report):
    run = report['run']
    return [row for row in report['output']['tables']['audit_events']
            if row.get('world_id') == run['world_id'] and row.get('turn') == run['target_turn']
            and row.get('metadata', {}).get('turn_run_id') == run['id']]


def without_audit_ids(rows):
    return [{key: value for key, value in row.items() if key != 'id'} for row in rows]


def normalized_run(report):
    rows = report['output']['tables']['turn_runs']
    return [{key: value for key, value in row.items()
             if key not in ['attempt_count', 'failure_context']} for row in rows]


def phase_metrics(report):
    return {row['phase']: row['metrics'] for row in report['run']['phase_results']}


left_audit = turn_audit(clean)
right_audit = turn_audit(fault)
all_tables = sorted(set(clean['output']['tables']) | set(fault['output']['tables']))
differing_tables = [table for table in all_tables
                    if clean['output']['tables'].get(table) != fault['output']['tables'].get(table)]
gameplay_tables = gameplay(clean)
checks = {
    'both_probe_checks_passed': clean['probe_error'] is None and fault['probe_error'] is None,
    'same_code': clean['source_sha256'] == fault['source_sha256'],
    'same_composer_lock': clean['composer_lock_sha256'] == fault['composer_lock_sha256'],
    'same_input_all_captured_rows': clean['input'] == fault['input'],
    'same_master_seed': clean['seed'] == fault['seed'] == clean['run']['random_seed'] == fault['run']['random_seed'],
    'canonical_pipeline_classes_equal': clean['pipeline_classes'] == fault['pipeline_classes']
        and all(name == r'App\Domain\Turn\GameplayTurnPhase' for name in clean['pipeline_classes']),
    'gameplay_rows_and_numeric_ids_and_timestamps_equal': gameplay_tables == gameplay(fault),
    'only_expected_raw_table_differences': set(differing_tables).issubset({'audit_events', 'turn_runs'}),
    'ordered_audit_body_metadata_and_all_timestamps_equal': without_audit_ids(left_audit) == without_audit_ids(right_audit),
    'turn_row_equal_except_retry_diagnostics': normalized_run(clean) == normalized_run(fault),
    'successful_phase_metrics_equal': phase_metrics(clean) == phase_metrics(fault),
    'root_rollback_restored_gameplay_and_preexisting_audit': fault['rollback_checkpoint']['gameplay_and_preexisting_audit_restored'],
    'first_failed_bulk_replayed_identically_except_ids': fault['failed_first_batch_without_audit_ids'] == fault['replayed_first_batch_without_audit_ids'],
    'same_context_identity_across_attempts': len(fault['context_identities']) == 2
        and fault['context_identities'][0] == fault['context_identities'][1],
    'fresh_state_across_attempts': len(fault['state_object_ids']) == 2
        and fault['state_object_ids'][0] != fault['state_object_ids'][1],
    'root_transaction_and_same_pdo': fault['rollback_checkpoint']['transaction_level'] == 0
        and fault['pdo_object_id_before'] == fault['pdo_object_id_after'] == fault['rollback_checkpoint']['pdo_object_id'],
    'failed_scope_and_success_scope_closed': all(not item['active'] and item['buffer_rows'] == 0
        for item in fault['state_batches_after']),
    'real_40001_after_1000_rows_visible': fault['fault'].get('sqlstate') == '40001'
        and fault['fault']['inserted_rows_in_statement'] == 1000
        and fault['fault']['turn_audit_rows_visible_before_error'] >= 1000,
    'c1_attempt_diagnostics_exact': fault['run']['attempt_count'] == 2
        and fault['run']['failure_context'] == {'transient_retries': [
            {'attempt_count': 1, 'phase': 'process_cells', 'sqlstate': '40001'}]},
}
report = {
    'passed': all(checks.values()),
    'checks': checks,
    'probe_sha256': hashlib.sha256((ROOT / 'TurnCellAuditRetryProbeTest.php').read_bytes()).hexdigest(),
    'source_sha256': clean['source_sha256'],
    'captured_tables': len(all_tables),
    'strict_gameplay_tables': len(gameplay_tables),
    'raw_differing_tables': differing_tables,
    'raw_full_output_equal': clean['output'] == fault['output'],
    'raw_audit_numeric_ids_equal': [row['id'] for row in left_audit] == [row['id'] for row in right_audit],
    'ordered_audit_rows': {'clean': len(left_audit), 'fault': len(right_audit)},
    'ordered_audit_without_ids_sha256': {'clean': digest(without_audit_ids(left_audit)), 'fault': digest(without_audit_ids(right_audit))},
    'audit_id_ranges': {
        'clean': [left_audit[0]['id'], left_audit[-1]['id']] if left_audit else [],
        'fault': [right_audit[0]['id'], right_audit[-1]['id']] if right_audit else [],
    },
    'attempt_counts': {'clean': clean['run']['attempt_count'], 'fault': fault['run']['attempt_count']},
    'process_cells_insert_sizes_by_attempt': {'clean': clean['process_cells_insert_sizes_by_attempt'], 'fault': fault['process_cells_insert_sizes_by_attempt']},
    'fault_point': {key: value for key, value in fault['fault'].items()},
    'rollback_checkpoint': {key: value for key, value in fault['rollback_checkpoint'].items() if key != 'snapshot'},
    'excluded_comparison_fields': {
        'ordered_audit': ['id only; metadata, subject IDs, occurred_at, created_at and updated_at are retained'],
        'turn_runs': ['attempt_count', 'failure_context', 'phase_results[*].duration_ms (removed by common capture)'],
        'rollback_checkpoint': ['turn_runs and turn_execution_slots: control records created outside game transaction'],
        'capture_never_reads': clean['input']['excluded_tables'],
        'capture_excluded_columns': clean['input']['excluded_columns'],
    },
    'limitations': [
        'The selected comparison uses one initial clean invocation and one initial fault-v2 invocation; no manual or cross-invocation retry.',
        'An earlier fault invocation also completed C1, but its last probe assertion compared JSONB object key order. Its original fault.json/XML and reconstructed probe-v1.php.txt are retained; the external assertion was corrected before fault-v2.',
        'This is correctness evidence, not a timing or throughput measurement.',
        'The fault is real SQLSTATE 40001 but not an organic competing workload race.',
        'At the post-flush fault, pending rows are already empty. The existing focused non-empty-tail test supplies that separate coverage.',
        'Raw audit sequence IDs and retry diagnostic fields intentionally differ; full raw all-table/all-ID equivalence is not claimed.',
    ],
}
(ROOT / 'comparison.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False, indent=2))
if not report['passed']:
    raise SystemExit('C1 comparison failed; inspect saved raw evidence without widening exclusions.')
