<?php
declare(strict_types=1);
namespace App\Models {
    // Source index only needs model identity and current scalar fields here.
    // This is a CPU algorithm probe, not Eloquent/SQL or gameplay validation.
    class MapCell {
        public function __construct(public int $id,public int $x,public int $y,public int $owner_nation_id,public object $facility) {}
    }
}
namespace {
require '/source/product/app/Domain/Map/GridCoordinate.php';
require '/source/product/app/Application/DisasterMutableCellIndex.php';
use App\Models\MapCell;
use App\Domain\Map\GridCoordinate;
use App\Application\DisasterMutableCellIndex;
$cells=[];
for($x=0;$x<96;++$x) for($y=0;$y<96;++$y) {
    $id=$x*96+$y+1;
    $station=$id%31===0 || ($x===48 && in_array($y,[47,49,51],true)) || ($x===47 && $y===48);
    $cells[]=new MapCell($id,$x,$y,1,(object)['key'=>($station?'undersea_fire_station':'other')]);
}
// Input is already ID-ordered, as the real process_cells query is.
$index=DisasterMutableCellIndex::fromCells($cells,[1]);
$origin=new GridCoordinate(48,48);$times=[];$checks=[];
foreach(['full_sort','radius_index'] as $mode) {
    $roundTimes=[];$ids=[];
    for($round=0;$round<3;++$round) {
        $start=hrtime(true);
        for($iteration=0;$iteration<50;++$iteration) {
            $candidates=[];
            if($mode==='full_sort') $candidates=$index->cells();
            else {
                foreach($origin->radius(2) as $coordinate) {
                    $cell=$index->cellAt($coordinate->x,$coordinate->y);
                    if($cell!==null) $candidates[]=$cell;
                }
                usort($candidates,fn(MapCell $a,MapCell $b):int=>$a->id<=>$b->id);
            }
            $ids=[];
            foreach($candidates as $station) {
                if($station->facility->key!=='undersea_fire_station'||$station->owner_nation_id!==1||$origin->distanceTo(new GridCoordinate($station->x,$station->y))>2) continue;
                $ids[]=$station->id;
            }
        }
        $roundTimes[]=(hrtime(true)-$start)/1e6;
    }
    $times[$mode]=$roundTimes;$checks[$mode]=$ids;
}
if($checks['full_sort']!==$checks['radius_index']) throw new RuntimeException('Candidate identity/order mismatch');
echo json_encode(['runtime'=>PHP_VERSION,'cells'=>count($cells),'successful_undersea_fire_candidate_checks_per_round'=>50,'milliseconds'=>$times,'candidate_ids'=>$checks['full_sort'],'limitation'=>'CPU scalar-model probe only; no Eloquent, SQL, finance, charm, monster or gameplay assertion'],JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR),"\n";
}
