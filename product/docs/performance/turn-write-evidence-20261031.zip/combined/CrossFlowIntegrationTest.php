<?php
namespace Tests\IntegrationProbe;
use App\Application\BoostScheduleService;
use App\Application\CommandQueueService;
use App\Application\NationCreationService;
use App\Application\SecretaryItemGrantService;
use App\Application\TurnRunner;
use App\Application\Underground\UndergroundAlphaV1PlayerCatalog;
use App\Application\Underground\UndergroundStarterEquipmentService;
use App\Domain\Map\MapCellStateService;
use App\Domain\Secretary\SecretaryItemCatalog;
use App\Domain\Turn\TurnSeedGenerator;
use App\Models\AuthIdentity;
use App\Models\BoostOccurrence;
use App\Models\MapCell;
use App\Models\NationCommandQueueItem;
use App\Models\RulesetVersion;
use App\Models\TerrainDefinition;
use App\Models\UndergroundBattle;
use App\Models\UndergroundProfile;
use App\Models\World;
use Carbon\CarbonImmutable;
use Illuminate\Database\Events\QueryExecuted;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Ramsey\Uuid\Uuid;
use Tests\Concerns\CreatesBoostSchedules;
use Tests\Concerns\CreatesTestWorlds;
use Tests\Support\UndergroundPlayerAccessTestCase;
final class CrossFlowIntegrationTest extends UndergroundPlayerAccessTestCase
{
    use CreatesBoostSchedules,CreatesTestWorlds,RefreshDatabase;
    public function test_command_turn_and_real_underground_combat_share_one_application_without_state_leaks(): void
    {
        Carbon::setTestNow('2026-10-31T14:00:00Z');
        CarbonImmutable::setTestNow('2026-10-31T14:00:00Z');
        fake()->seed(20261031);
        $counter=0;
        Str::createUuidsUsing(function () use (&$counter) {return Uuid::fromString(sprintf('00000000-0000-4000-8000-%012d',++$counter));});
        $this->app->instance(TurnSeedGenerator::class,new class implements TurnSeedGenerator {
            public function generate(World $world,int $targetTurn,RulesetVersion $ruleset):string {return hash('sha256','integration-cross-flow:'.$targetTurn);}
        });
        [$user,$secretary]=$this->secretaryUser('Integration secretary');
        $user->forceFill(['visitor_code'=>'INTG0001'])->save();$world=$this->lightweightWorld();
        $nation=app(NationCreationService::class)->create($user,$world,'Integration nation','Integration owner');
        $space=$this->surfaceMapSpace($world);
        app(SecretaryItemGrantService::class)->grant($secretary,SecretaryItemCatalog::RING,4,2,'integration:ring');
        $profile=$this->openEquipmentProfile($secretary);
        app(UndergroundStarterEquipmentService::class)->reconcile($profile);
        $catalog=app(UndergroundAlphaV1PlayerCatalog::class);
        $catalogBefore=hash('sha256',json_encode($catalog->explorationCatalog()->manifest(),JSON_THROW_ON_ERROR));
        $items=app(SecretaryItemCatalog::class)->definitions();
        $items[SecretaryItemCatalog::RING]['name']='caller-local mutation';
        $this->assertNotSame('caller-local mutation',app(SecretaryItemCatalog::class)->definition(SecretaryItemCatalog::RING)['name']);
        $plain=TerrainDefinition::query()->where('key','plain')->sole();
        $waste=TerrainDefinition::query()->where('key','wasteland')->sole();
        $cells=MapCell::query()->where('owner_nation_id',$nation->id)->whereNull('facility_definition_id')->with('terrain')->orderBy('y')->orderBy('x')->get();
        $this->assertGreaterThanOrEqual(2,$cells->count());
        foreach($cells as $cell){app(MapCellStateService::class)->transitionTerrain($cell,$plain);$cell->save();}
        $targets=MapCell::query()->where('map_space_id',$space->id)->whereNull('facility_definition_id')->orderBy('y')->orderBy('x')->limit(31)->with('terrain')->get();$this->assertCount(31,$targets);foreach($targets as $cell){app(MapCellStateService::class)->transitionTerrain($cell,$waste);$cell->owner_nation_id=$nation->id;$cell->save();}
        $boost=$this->boostOccurrence('hunting_ground',$world);
        foreach([1,2] as $offset){$later=$boost->replicate();$later->occurrence_number=$offset+1;$later->starts_at=now()->addDays($offset);$later->ends_at=now()->addDays($offset)->addHours(2);$later->save();}
        config(['hakoniwa.admin.discord_user_id'=>'integration-admin']);
        AuthIdentity::query()->create(['user_id'=>$user->id,'provider'=>'discord','provider_user_id'=>'integration-admin','display_name'=>'Integration admin']);
        $input=[];foreach(['map_cells','nations','secretary_item_instances','underground_profiles','boost_occurrences'] as $table){$rows=DB::table($table)->get()->map(fn($r)=>json_encode($r,JSON_THROW_ON_ERROR))->all();sort($rows,SORT_STRING);$input[$table]=hash('sha256',json_encode($rows,JSON_THROW_ON_ERROR));}
        $measuring=false;$queries=[];$measurements=[];
        DB::listen(function(QueryExecuted $q) use (&$measuring,&$queries):void {if($measuring)$queries[]=['sql'=>$q->sql,'milliseconds'=>$q->time];});
        $measure=function(string $name,callable $call) use (&$measuring,&$queries,&$measurements){
            $queries=[];$measuring=true;$usageStart=getrusage();$start=hrtime(true);
            try{$value=$call();}finally{$elapsed=(hrtime(true)-$start)/1e6;$usageEnd=getrusage();$measuring=false;}
            $measurements[$name]=['wall_ms'=>$elapsed,'cpu_ms'=>(($usageEnd['ru_utime.tv_sec']-$usageStart['ru_utime.tv_sec']+$usageEnd['ru_stime.tv_sec']-$usageStart['ru_stime.tv_sec'])*1000+($usageEnd['ru_utime.tv_usec']-$usageStart['ru_utime.tv_usec']+$usageEnd['ru_stime.tv_usec']-$usageStart['ru_stime.tv_usec'])/1000),'sql_count'=>count($queries),'sql_ms'=>array_sum(array_column($queries,'milliseconds')),'sql_shapes'=>array_count_values(array_column($queries,'sql'))];
            return $value;
        };
        $this->actingAs($user);
        $path="/api/v1/nations/{$nation->id}/map-spaces/{$space->id}/command-queue";
        $post=$measure('queue_post',fn()=>$this->postJson($path,['command_key'=>'finance','quantity'=>1,'request_key'=>'10000000-0000-4000-8000-000000000001','expected_version'=>1])->assertCreated()->json('data'));
        $version=$post['queue']['version'];
        for($i=0;$i<28;$i++){$result=app(CommandQueueService::class)->add($user,$nation,$space,'finance',null,null,sprintf('20000000-0000-4000-8000-%012d',$i+1),$version,quantity:1,quantityProvided:true);$version=$result['queue']->version;}
        $bulk=$measure('queue_bulk',fn()=>$this->postJson($path.'/bulk',['action'=>'clear_all','position'=>1,'request_key'=>'30000000-0000-4000-8000-000000000001','expected_version'=>$version])->assertOk()->assertJsonPath('data.inserted_count',30)->assertJsonPath('data.skipped_count',1)->assertJsonPath('data.cancelled_count',29)->json('data'));
        $queue=$measure('queue_30_get',fn()=>$this->getJson($path)->assertOk()->assertJsonPath('data.explicit_count',30)->json('data'));
        $admin=$measure('boost_admin',fn()=>app(BoostScheduleService::class)->adminStatus($user,$world));
        $this->assertCount(3,$admin['occurrences']);
        $run=$measure('official_turn',fn()=>app(TurnRunner::class)->run($world));
        $this->assertNotNull($run);$this->assertSame('completed',$run->status);$this->assertSame(2,$world->fresh()->current_turn);
        $this->assertSame(1,NationCommandQueueItem::query()->where('status','completed')->count());
        $afterQueue=$measure('queue_after_turn',fn()=>$this->getJson($path)->assertOk()->json('data'));
        $request=['request_id'=>'40000000-0000-4000-8000-000000000001','hunting_ground_key'=>'shallow_caves'];
        $battle=$measure('real_exploration',fn()=>$this->postJson('/api/v1/me/underground/explore',$request)->assertOk()->json('data'));
        $battleRow=UndergroundBattle::query()->where('request_id',$request['request_id'])->sole();
        $this->assertNotNull($battleRow->log);
        $balances=$profile->refresh()->only(['combat_xp','shard_balance','current_hp','next_battle_at']);
        $battleCount=UndergroundBattle::query()->count();
        $repeat=$measure('exploration_replay',fn()=>$this->postJson('/api/v1/me/underground/explore',$request)->assertOk()->json('data'));
        $this->assertSame($battle['id'],$repeat['id']);$this->assertEquals($balances,$profile->refresh()->only(array_keys($balances)));$this->assertSame($battleCount,UndergroundBattle::query()->count());
        $this->assertSame($catalogBefore,hash('sha256',json_encode($catalog->explorationCatalog()->manifest(),JSON_THROW_ON_ERROR)));
        $tables=['worlds','map_cells','map_chunks','nations','nation_capitals','nation_resources','nation_command_queues','nation_command_queue_items','nation_command_queue_bulk_requests','secretaries','secretary_surface_states','secretary_item_instances','secretary_skills','user_daily_quest_activities','user_daily_quest_progress','user_paradox_balances','user_paradox_ledger','underground_profiles','underground_intro_progress','underground_owned_equipment','underground_battles','underground_battle_logs','boost_series','boost_occurrences','audit_events'];
        $state=[];
        foreach($tables as $table){$rows=DB::table($table)->get()->map(fn($r)=>json_encode($r,JSON_THROW_ON_ERROR))->all();sort($rows,SORT_STRING);$state[$table]=['rows'=>count($rows),'hash'=>hash('sha256',json_encode($rows,JSON_THROW_ON_ERROR))];}
        $responses=['post'=>$post,'bulk'=>$bulk,'queue'=>$queue,'after_turn'=>$afterQueue,'boost_admin'=>$admin,'battle'=>$battle,'replay'=>$repeat];
        $responseHashes=array_map(fn($v)=>hash('sha256',json_encode($v,JSON_THROW_ON_ERROR)),$responses);
        $phaseResults=$run->phase_results;foreach($phaseResults as &$phase)unset($phase['duration_ms']);unset($phase);
        $out=['variant'=>getenv('INTEGRATION_VARIANT'),'php'=>PHP_VERSION,'fixture'=>['world_cells'=>1024,'queue_before_turn'=>30,'seed_label'=>'integration-cross-flow:2','clock'=>'2026-10-31T14:00:00Z','one_application'=>true,'real_combat'=>true],'input_hashes'=>$input,'sample'=>'reverse-order CPU diagnostic pair','measurements'=>$measurements,'response_hashes'=>$responseHashes,'response_values'=>$responses,'state'=>$state,'turn'=>['target_turn'=>$run->target_turn,'status'=>$run->status,'phase_results'=>$phaseResults],'battle'=>['result'=>$battleRow->result,'rounds'=>$battleRow->rounds,'private_seed'=>$battleRow->private_seed,'snapshot_hash'=>hash('sha256',json_encode($battleRow->snapshot,JSON_THROW_ON_ERROR))],'limits'=>'One paired run per version. Synthetic unlocked-profile fixture and trusted server-issued admission test adapter; no intro UI, real issuer, browser, production, concurrency or whole-workload claims. Auth tables are excluded. Turn timing fields are not gameplay comparisons.'];
        file_put_contents('/evidence/cross-flow-'.getenv('INTEGRATION_VARIANT').'.json',json_encode($out,JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR));
    }
    protected function tearDown():void {Str::createUuidsNormally();Carbon::setTestNow();CarbonImmutable::setTestNow();parent::tearDown();}
}
