<?php
require '/var/www/html/vendor/autoload.php';

use App\Application\DisasterMutableCellIndex;
use App\Domain\Map\GridCoordinate;
use App\Models\FacilityDefinition;
use App\Models\MapCell;

$results = ['runtime' => PHP_VERSION, 'opcache_cli' => ini_get('opcache.enable_cli'), 'checks_per_round' => 20, 'profiles' => []];
foreach ([32, 96] as $size) {
    $cells = [];
    $origin = new GridCoordinate(16, 16);
    $station = (new FacilityDefinition)->setRawAttributes(['key' => 'undersea_fire_station']);
    for ($x = 0; $x < $size; $x++) {
        for ($y = 0; $y < $size; $y++) {
            $id = $x * $size + $y + 1;
            $cell = (new MapCell)->setRawAttributes(['id' => $id, 'x' => $x, 'y' => $y, 'owner_nation_id' => 1]);
            $cell->setRelation('facility', ($x === 15 || $x === 17) && $y === 16 ? $station : null);
            $cells[] = $cell;
        }
    }
    $index = DisasterMutableCellIndex::fromCells($cells, [1]);
    $profile = ['cells' => count($cells), 'timings_ms' => []];
    $identities = [];
    foreach (['full_index_sort', 'coordinate_radius'] as $mode) {
        $times = [];
        for ($round = 0; $round < 3; $round++) {
            $start = hrtime(true);
            for ($check = 0; $check < $results['checks_per_round']; $check++) {
                $candidates = $mode === 'full_index_sort' ? $index->cells() : $index->cellsWithinRadius($origin, 2);
                $ids = [];
                foreach ($candidates as $candidate) {
                    if ($candidate->facility?->key !== 'undersea_fire_station'
                        || $candidate->owner_nation_id !== 1
                        || $origin->distanceTo(new GridCoordinate($candidate->x, $candidate->y)) > 2) {
                        continue;
                    }
                    $ids[] = $candidate->id;
                }
            }
            $times[] = (hrtime(true) - $start) / 1e6;
        }
        $profile['timings_ms'][$mode] = $times;
        $identities[$mode] = $ids;
    }
    if ($identities['full_index_sort'] !== $identities['coordinate_radius'] || count($identities['coordinate_radius']) !== 2) {
        throw new RuntimeException('Candidate identity/order comparison failed.');
    }
    $profile['candidate_ids'] = $identities['coordinate_radius'];
    $results['profiles'][] = $profile;
}
$results['scope'] = 'Actual source index and Eloquent models; synthetic CPU candidate selection only, no SQL/payment/fire lottery or whole-turn timing.';
echo json_encode($results, JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR), "\n";
