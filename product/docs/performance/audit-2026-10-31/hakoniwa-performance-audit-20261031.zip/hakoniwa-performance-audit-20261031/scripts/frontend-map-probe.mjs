import { performance } from 'node:perf_hooks';
import fs from 'node:fs';
const rows=[];
for(const side of [60,96]) {
  const positioned=[];
  for(let y=0;y<side;y++) for(let x=0;x<side;x++) positioned.push({id:y*side+x,x:x*32,y:y*32});
  const samples=[];let matches=0;
  for(let round=0;round<3;round++) {
    const t=performance.now();
    for(let frame=0;frame<120;frame++) {
      const pan={x:-side*16+frame,y:-side*16}; const zoom=1;const padding=64;
      matches+=positioned.filter(item=>{const screenX=pan.x+item.x*zoom,screenY=pan.y+item.y*zoom;return screenX>=-padding&&screenX<=900+padding&&screenY>=-padding&&screenY<=600+padding}).length;
    }
    samples.push(performance.now()-t);
  }
  rows.push({cells:positioned.length,panEvents:120,predicateEvaluationsPerRound:positioned.length*120,samplesMs:samples,matches});
}
const d={node:process.version,kind:'synthetic scalar loop from HexMap.visiblePositioned; not Vue/DOM/browser FPS',rows};
fs.writeFileSync('/workspace/perf-audit-20261031/frontend-map-probe.json',JSON.stringify(d,null,2));console.log(JSON.stringify(d));
