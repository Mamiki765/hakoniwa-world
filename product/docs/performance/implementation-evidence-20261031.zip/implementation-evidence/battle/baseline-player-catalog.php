<?php

namespace App\Application\Underground;

use App\Domain\Underground\Combat\AlphaV1BuildCatalog;
use App\Domain\Underground\Combat\AlphaV1CombatRules;
use App\Domain\Underground\Combat\PriorityCombatAiConfiguration;
use App\Domain\Underground\Combat\UndergroundBuildValidator;
use App\Domain\Underground\Combat\UndergroundEquipmentScaling;
use InvalidArgumentException;
use JsonException;
use RuntimeException;

/**
 * @phpstan-type ExplorationHuntingGround array{
 *     key: string,
 *     content_identity: string,
 *     name: string,
 *     kind: 'hunting_ground'|'vault'|'otherworld',
 *     required_trial_key: string|null,
 *     enemy_count_by_party_size: array{1:int,2:int,3:int,4:int},
 *     item_level_min: int,
 *     item_level_max: int,
 *     rare_encounter: array{key:string,chance_bps:int,encounter:array<string,mixed>,distorted_stone_quantity?:int}|null,
 *     key_reward: array{normal_chance_bps:int,rare_quantity:int}|null,
 *     key_balance_field: string,
 *     key_label: string,
 *     entry_key_cost: int,
 *     vault_base_g: int|null,
 *     treasure_multiplier: int|null,
 *     forced_drop_profile: string|null,
 *     drop_tier_key: string
 * }
 */
final readonly class UndergroundAlphaV1PlayerCatalog
{
    public function __construct(
        private AlphaV1CombatRules $rules,
        private UndergroundBuildValidator $buildValidator,
        private PriorityCombatAiConfiguration $aiConfiguration = new PriorityCombatAiConfiguration,
        private UndergroundEquipmentCatalog $equipmentCatalog = new UndergroundEquipmentCatalog,
        private UndergroundRuntimeCatalog $runtimeCatalog = new UndergroundRuntimeCatalog,
        private UndergroundRuntimeEquipmentGenerator $generatedEquipment = new UndergroundRuntimeEquipmentGenerator,
    ) {}

    public function growthIdentity(): string
    {
        return $this->string($this->data(), 'growth_identity');
    }

    public function skillTreeIdentity(): string
    {
        return $this->string($this->data(), 'skill_tree_identity');
    }

    public function targetingIdentity(): string
    {
        $contract = $this->laboratoryCatalog()->targetingContract();
        $identity = $contract['identity'] ?? null;

        return is_string($identity) && $identity === AlphaV1CombatRules::TARGETING_IDENTITY
            ? $identity
            : throw new RuntimeException('Underground targeting identity is invalid.');
    }

    public function initialSkillPoints(): int
    {
        $points = $this->data()['initial_skill_points'] ?? null;

        return is_int($points) && $points > 0
            ? $points
            : throw new RuntimeException('Underground initial Skill Points must be positive.');
    }

    /**
     * @param  array<array-key, mixed>  $allocations
     * @return array{
     *     acquired_nodes: array<string, int>,
     *     passive_nodes: array<string, int>,
     *     passive_modifiers: array<string, int|bool|string>,
     *     active_skills: list<string>,
     *     ai_rules: list<array<string, mixed>>,
     *     tree_points: array<string, int>
     * }
     */
    public function playerSkillBuild(array $allocations, ?string $weaponStyle = null): array
    {
        if ($weaponStyle !== null && $weaponStyle === '') {
            throw new RuntimeException('Underground player weapon style is invalid.');
        }
        $catalog = $this->laboratoryCatalog();
        $acquired = [];
        $passives = [];
        $activeBySlot = [];
        $treePoints = array_fill_keys(AlphaV1CombatRules::TREES, 0);
        foreach ($allocations as $nodeKey => $allocation) {
            if (! is_string($nodeKey) || ! is_array($allocation)
                || ! is_int($allocation['rank'] ?? null) || $allocation['rank'] < 1
                || ! array_key_exists('active_slot', $allocation)
                || (! is_null($allocation['active_slot']) && ! is_int($allocation['active_slot']))) {
                throw new RuntimeException('Underground player skill allocation is invalid.');
            }
            $entry = $catalog->node($nodeKey);
            $node = $entry['node'];
            $rank = $allocation['rank'];
            $maxRank = $node['max_rank'] ?? null;
            $cost = $node['point_cost_per_rank'] ?? null;
            if (! is_int($maxRank) || ! is_int($cost) || $rank > $maxRank || $cost < 1) {
                throw new RuntimeException("Underground player skill allocation [{$nodeKey}] is invalid.");
            }
            $acquired[$nodeKey] = $rank;
            $treePoints[$entry['tree']] += $rank * $cost;
            if (($node['type'] ?? null) === 'passive') {
                if ($allocation['active_slot'] !== null) {
                    throw new RuntimeException('Underground passive skill cannot occupy an active slot.');
                }
                $passives[$nodeKey] = $rank;

                continue;
            }
            $skillKey = $node['skill_key'] ?? null;
            if (! is_string($skillKey)) {
                throw new RuntimeException("Underground active skill node [{$nodeKey}] is invalid.");
            }
            $skill = $catalog->skill($skillKey);
            if (($skill['node_key'] ?? null) !== $nodeKey) {
                throw new RuntimeException("Underground active skill node [{$nodeKey}] is invalid.");
            }
            $slot = $allocation['active_slot'];
            if ($slot !== null) {
                if ($slot < 1 || $slot > AlphaV1CombatRules::ACTIVE_SKILL_LIMIT || isset($activeBySlot[$slot])) {
                    throw new RuntimeException('Underground active skill loadout is invalid.');
                }
                if ($weaponStyle === null || $this->skillSupportsWeaponStyle($skill, $weaponStyle)) {
                    $activeBySlot[$slot] = $skillKey;
                }
            }
        }
        ksort($activeBySlot);
        $activeSkills = array_values($activeBySlot);
        $modifiers = $this->buildValidator->passiveModifiers($catalog, $passives);
        $aiRules = $this->playerAiRules($activeSkills);
        $this->buildValidator->assertAiRules($catalog, $activeSkills, $aiRules, 'secretary_runtime');

        return [
            'acquired_nodes' => $acquired,
            'passive_nodes' => $passives,
            'passive_modifiers' => $modifiers,
            'active_skills' => $activeSkills,
            'ai_rules' => $aiRules,
            'tree_points' => $treePoints,
        ];
    }

    /**
     * @param  array<string, array{rank: int, active_slot: int|null}>  $allocations
     * @return list<array<string, mixed>>
     */
    public function skillTrees(array $allocations, int $unspentSkillPoints): array
    {
        if ($unspentSkillPoints < 0) {
            throw new RuntimeException('Underground unspent Skill Points are invalid.');
        }
        $catalog = $this->laboratoryCatalog();
        $build = $this->playerSkillBuild($allocations);
        $trees = [];
        foreach (AlphaV1CombatRules::TREES as $treeKey) {
            $tree = $catalog->tree($treeKey);
            $nodes = [];
            foreach (($tree['nodes'] ?? []) as $nodeKey => $node) {
                if (! is_string($nodeKey) || ! is_array($node)) {
                    throw new RuntimeException("Underground skill tree [{$treeKey}] is invalid.");
                }
                $rank = $build['acquired_nodes'][$nodeKey] ?? 0;
                $cost = $node['point_cost_per_rank'] ?? null;
                $maxRank = $node['max_rank'] ?? null;
                $required = $node['invested_points_required'] ?? null;
                $prerequisite = $node['prerequisite'] ?? null;
                if (! is_int($cost) || ! is_int($maxRank) || ! is_int($required)) {
                    throw new RuntimeException("Underground skill node [{$nodeKey}] is invalid.");
                }
                $reason = null;
                if ($rank >= $maxRank) {
                    $reason = '最大rankです';
                } elseif (is_string($prerequisite) && ! isset($build['acquired_nodes'][$prerequisite])) {
                    $reason = '前提skill未取得';
                } elseif ($this->investedBelowGate($catalog, $allocations, $treeKey, $required) < $required) {
                    $remaining = $required - $this->investedBelowGate($catalog, $allocations, $treeKey, $required);
                    $reason = ($tree['label'] ?? $treeKey)."へあと{$remaining}SP必要";
                } elseif ($unspentSkillPoints < $cost) {
                    $reason = 'SP不足';
                }
                $skill = ($node['type'] ?? null) === 'active'
                    ? $catalog->skill((string) ($node['skill_key'] ?? ''))
                    : null;
                $nodes[] = [
                    'key' => $nodeKey,
                    'label' => $this->string($node, 'label'),
                    'summary' => $this->string($node, 'summary'),
                    'type' => $node['type'],
                    'rank' => $rank,
                    'max_rank' => $maxRank,
                    'point_cost' => $cost,
                    'invested_points_required' => $required,
                    'prerequisite' => $prerequisite,
                    'can_acquire' => $reason === null,
                    'unavailable_reason' => $reason,
                    'skill_key' => $skill === null ? null : $node['skill_key'],
                    'mp_cost' => $skill['mp_cost'] ?? null,
                    'cooldown' => $skill['cooldown'] ?? null,
                    'consumes_action' => $skill['consumes_action'] ?? true,
                    'required_weapon_styles' => $skill['required_weapon_styles'] ?? [],
                    'recommended_stats' => $skill === null
                        ? null
                        : $this->recommendedStats((string) $node['skill_key']),
                    'active_slot' => $allocations[$nodeKey]['active_slot'] ?? null,
                ];
            }
            $trees[] = [
                'key' => $treeKey,
                'label' => $this->string($tree, 'label'),
                'invested_points' => $build['tree_points'][$treeKey],
                'full_points' => $this->fullTreePoints($catalog, $treeKey),
                'nodes' => $nodes,
            ];
        }

        return $trees;
    }

    /**
     * @param  array<string, array{rank: int, active_slot: int|null}>  $allocations
     */
    public function investedBelowGate(
        AlphaV1BuildCatalog $catalog,
        array $allocations,
        string $treeKey,
        int $requiredInvestment,
    ): int {
        $points = 0;
        foreach ($allocations as $nodeKey => $allocation) {
            $entry = $catalog->node($nodeKey);
            $node = $entry['node'];
            if ($entry['tree'] === $treeKey
                && is_int($node['invested_points_required'] ?? null)
                && $node['invested_points_required'] < $requiredInvestment) {
                $points += $allocation['rank'] * (int) $node['point_cost_per_rank'];
            }
        }

        return $points;
    }

    public function fullTreePoints(AlphaV1BuildCatalog $catalog, string $treeKey): int
    {
        $points = 0;
        foreach (($catalog->tree($treeKey)['nodes'] ?? []) as $node) {
            if (! is_array($node) || ! is_int($node['max_rank'] ?? null)
                || ! is_int($node['point_cost_per_rank'] ?? null)) {
                throw new RuntimeException("Underground skill tree [{$treeKey}] is invalid.");
            }
            $points += $node['max_rank'] * $node['point_cost_per_rank'];
        }

        return $points;
    }

    public function explorationIdentity(): string
    {
        return $this->string($this->explorationConfig(), 'identity');
    }

    public function explorationHuntingGroundKey(): string
    {
        return $this->string($this->explorationConfig(), 'default_hunting_ground_key');
    }

    /** @return list<ExplorationHuntingGround> */
    public function explorationHuntingGrounds(): array
    {
        $configured = $this->explorationConfig()['grounds'];
        $grounds = [];
        foreach ($configured as $key => $ground) {
            if (! is_string($key) || ! is_array($ground)) {
                throw new RuntimeException('Underground hunting ground configuration is invalid.');
            }
            $grounds[] = $this->validatedHuntingGround($key, $ground);
        }
        if ($grounds === [] || ! in_array(
            $this->explorationHuntingGroundKey(),
            array_column($grounds, 'key'),
            true,
        )) {
            throw new RuntimeException('Underground default hunting ground is invalid.');
        }

        return $grounds;
    }

    /** @return ExplorationHuntingGround */
    public function explorationHuntingGround(string $key): array
    {
        if ($this->isOtherworldStage($key)) {
            $content = $this->otherworld();
            $stage = $content['stages'][$key];

            return ['key' => $key, 'name' => $stage['name'], 'content_identity' => 'secretary-underground-otherworld-v1:'.$key,
                'kind' => 'otherworld', 'required_trial_key' => $content['required_trial_key'],
                'enemy_count_by_party_size' => [1 => 1, 2 => 1, 3 => 1, 4 => 1],
                'item_level_min' => $stage['item_level'], 'item_level_max' => $stage['item_level'],
                'rare_encounter' => null, 'key_reward' => null, 'entry_key_cost' => 0,
                'key_balance_field' => 'shining_kingdom_key_balance', 'key_label' => '輝きの王国の鍵',
                'vault_base_g' => null, 'treasure_multiplier' => null, 'forced_drop_profile' => null, 'drop_tier_key' => 'bahamul'];
        }
        foreach ($this->explorationHuntingGrounds() as $ground) {
            if ($ground['key'] === $key) {
                return $ground;
            }
        }

        throw new UndergroundRuntimeException(
            'underground_hunting_ground_not_supported',
            '狩場を確認してください。',
        );
    }

    public function explorationEnemyCountForPartySize(string $huntingGroundKey, int $partySize): int
    {
        if ($partySize < 1 || $partySize > 4) {
            throw new InvalidArgumentException('Underground party size must be between one and four.');
        }

        return $this->explorationHuntingGround($huntingGroundKey)['enemy_count_by_party_size'][$partySize];
    }

    public function explorationMaxRounds(): int
    {
        $value = $this->explorationConfig()['max_rounds'] ?? null;

        return is_int($value) && $value >= 1 && $value <= 100
            ? $value
            : throw new RuntimeException('Underground exploration max rounds must be between 1 and 100.');
    }

    public function innCost(): int
    {
        $cost = $this->shopConfig()['inn']['cost_shards'] ?? null;

        return is_int($cost) && $cost > 0
            ? $cost
            : throw new RuntimeException('Underground inn cost must be positive.');
    }

    public function bankTransferUnit(): int
    {
        $unit = $this->shopConfig()['bank']['transfer_unit_shards'] ?? null;

        return is_int($unit) && $unit > 0
            ? $unit
            : throw new RuntimeException('Underground bank transfer unit must be positive.');
    }

    /** @return list<array<string, mixed>> */
    public function growthPaths(): array
    {
        $paths = $this->data()['growth_paths'];

        return array_map(fn (string $key): array => $this->growthPath($key), array_keys($paths));
    }

    /** @return array<string, mixed> */
    public function growthPath(string $key): array
    {
        $configured = $this->data()['growth_paths'][$key] ?? null;
        if (! is_array($configured)) {
            throw new UndergroundRuntimeException('underground_growth_path_invalid', '輝石の選択を確認してください。');
        }
        $buildKey = $this->string($configured, 'build_key');
        $build = $this->laboratoryCatalog()->build($buildKey);
        $stats = $build['base_stats'] ?? null;
        $growth = $configured['natural_growth'] ?? null;
        $stp = $configured['unspent_stp_per_level'] ?? null;
        if (! is_array($stats) || ! is_array($growth) || ! is_int($stp)) {
            throw new RuntimeException("Underground growth path [{$key}] is invalid.");
        }
        $this->rules->assertFiveStats($stats);
        $growthKeys = array_keys($growth);
        $statKeys = AlphaV1CombatRules::STATS;
        sort($growthKeys);
        sort($statKeys);
        if ($growthKeys !== $statKeys
            || array_filter($growth, static fn (mixed $value): bool => ! is_int($value) || $value < 0) !== []
            || $stp < 0
            || array_sum($growth) + $stp < 1) {
            throw new RuntimeException("Underground growth path [{$key}] growth contract is invalid.");
        }
        $description = $configured['description'] ?? null;
        if (! is_array($description) || ! array_is_list($description)
            || array_filter($description, 'is_string') !== $description) {
            throw new RuntimeException("Underground growth path [{$key}] description is invalid.");
        }

        return [
            'key' => $key,
            'identity' => $this->growthIdentity(),
            'label' => $this->string($configured, 'label'),
            'color' => $this->string($configured, 'color'),
            'description' => $description,
            'default_build_key' => $buildKey,
            'stats' => $stats,
            'max_hp' => $this->rules->maxHp($stats, 10_000),
            'max_mp' => AlphaV1CombatRules::MAX_MP,
            'natural_recovery' => $this->laboratoryCatalog()->balanceInt('mp_natural_recovery'),
            'natural_growth' => $growth,
            'unspent_stp_per_level' => $stp,
            'points_per_level' => array_sum($growth) + $stp,
        ];
    }

    /**
     * @param  array<string, mixed>  $allocatedStp
     * @return array{vitality: int, might: int, finesse: int, spirit: int, agility: int}
     */
    public function currentStats(string $growthPathKey, int $combatLevel, array $allocatedStp): array
    {
        if ($combatLevel < 1) {
            throw new RuntimeException('Underground player growth state is invalid.');
        }
        $normalizedAllocatedStp = [];
        foreach (AlphaV1CombatRules::STATS as $key) {
            $value = $allocatedStp[$key] ?? null;
            if (! is_int($value) || $value < 0) {
                throw new RuntimeException('Underground allocated STP is invalid.');
            }
            $normalizedAllocatedStp[$key] = $value;
        }
        if (array_keys($allocatedStp) !== AlphaV1CombatRules::STATS) {
            throw new RuntimeException('Underground allocated STP is invalid.');
        }
        $path = $this->growthPath($growthPathKey);
        $stats = [];
        foreach (AlphaV1CombatRules::STATS as $key) {
            $stats[$key] = $path['stats'][$key]
                + ($path['natural_growth'][$key] * ($combatLevel - 1))
                + $normalizedAllocatedStp[$key];
        }
        $this->rules->assertFiveStats($stats, false);

        return $stats;
    }

    public function stpEntitlement(string $growthPathKey, int $combatLevel): int
    {
        if ($combatLevel < 1) {
            throw new RuntimeException('Underground combat level is invalid.');
        }

        return ($combatLevel - 1) * $this->growthPath($growthPathKey)['unspent_stp_per_level'];
    }

    /** @return array<string, mixed> */
    public function starterWeapon(): array
    {
        $weapon = $this->explorationConfig()['starter_weapon'] ?? null;
        if (! is_array($weapon)
            || ($weapon['key'] ?? null) !== 'starter_knife'
            || ($weapon['label'] ?? null) !== '護身用ナイフ'
            || ($weapon['item_level'] ?? null) !== 1
            || ($weapon['rarity'] ?? null) !== 'common'
            || ($weapon['weapon_style'] ?? null) !== 'dagger'
            || ! is_int($weapon['weapon_power'] ?? null)
            || $weapon['weapon_power'] < 1
            || ! is_int($weapon['physical_defense'] ?? null) || $weapon['physical_defense'] < 0
            || ! is_int($weapon['magical_defense'] ?? null) || $weapon['magical_defense'] < 0
            || ! is_int($weapon['max_hp'] ?? null) || $weapon['max_hp'] < 0
            || ! is_array($weapon['stats'] ?? null)
            || array_keys($weapon['stats']) !== AlphaV1CombatRules::STATS
            || ($weapon['modifiers'] ?? null) !== []
            || ($weapon['affixes'] ?? null) !== []
            || ! array_key_exists('unique_effect', $weapon)
            || $weapon['unique_effect'] !== null) {
            throw new RuntimeException('Underground starter weapon is invalid.');
        }
        foreach ($weapon['stats'] as $value) {
            if (! is_int($value) || $value < 0) {
                throw new RuntimeException('Underground starter weapon stats are invalid.');
            }
        }

        return $weapon;
    }

    /**
     * @param  array{vitality: int, might: int, finesse: int, spirit: int, agility: int}  $progressionStats
     * @param  array<string, mixed>  $equipment
     * @return array{vitality: int, might: int, finesse: int, spirit: int, agility: int}
     */
    public function combatStats(array $progressionStats, array $equipment): array
    {
        $this->rules->assertFiveStats($progressionStats, false);
        $bonuses = $equipment['stats'] ?? null;
        if (! is_array($bonuses) || array_keys($bonuses) !== AlphaV1CombatRules::STATS) {
            throw new RuntimeException('Underground equipment stat bonuses are invalid.');
        }
        foreach (AlphaV1CombatRules::STATS as $key) {
            if (! is_int($bonuses[$key])) {
                throw new RuntimeException('Underground equipment stat bonuses are invalid.');
            }
            $progressionStats[$key] += $bonuses[$key];
        }
        $this->rules->assertFiveStats($progressionStats, false);

        return $progressionStats;
    }

    /**
     * @param  array{vitality: int, might: int, finesse: int, spirit: int, agility: int}  $combatStats
     * @param  array<string, mixed>  $equipment
     */
    public function maxHp(array $combatStats, array $equipment): int
    {
        $maxHp = $equipment['max_hp'] ?? null;
        if (! is_int($maxHp) || $maxHp < 0) {
            throw new RuntimeException('Underground equipment max HP bonus is invalid.');
        }

        return UndergroundEquipmentScaling::maxHp($this->rules, $combatStats, 10_000, $equipment);
    }

    /**
     * @param  array<string, mixed>  $allocatedStp
     * @param  array<string, mixed>|null  $equipment
     */
    public function currentMaxHp(
        string $growthPathKey,
        int $combatLevel,
        array $allocatedStp,
        ?array $equipment = null,
    ): int {
        $equipment ??= $this->starterWeapon();
        $progressionStats = $this->currentStats($growthPathKey, $combatLevel, $allocatedStp);

        return $this->maxHp($this->combatStats($progressionStats, $equipment), $equipment);
    }

    /**
     * @return list<array{
     *   key: string,
     *   label: string,
     *   weight: int,
     *   xp: int,
     *   shards: int,
     *   drop_profile: string,
     *   item_level_min: int,
     *   item_level_max: int
     * }>
     */
    public function explorationEncounters(?string $huntingGroundKey = null): array
    {
        $groundKey = $huntingGroundKey ?? $this->explorationHuntingGroundKey();
        if ($this->isOtherworldStage($groundKey)) {
            $stage = $this->otherworld()['stages'][$groundKey];

            return [['key' => $groundKey, 'label' => $stage['name'], 'weight' => 10000,
                'xp' => $stage['xp'], 'shards' => $stage['shards'], 'drop_profile' => 'otherworld_fixed',
                'item_level_min' => $stage['item_level'], 'item_level_max' => $stage['item_level']]];
        }
        $ground = $this->configuredHuntingGround($groundKey);
        $configured = $ground['encounters'] ?? null;
        if (! is_array($configured) || $configured === []) {
            throw new RuntimeException('Underground exploration encounters are invalid.');
        }
        $encounters = [];
        $weightTotal = 0;
        foreach ($configured as $key => $entry) {
            if (! is_string($key) || ! is_array($entry)
                || ! is_string($entry['label'] ?? null)
                || ! is_int($entry['weight'] ?? null) || $entry['weight'] < 1
                || ! is_int($entry['xp'] ?? null) || $entry['xp'] < 0
                || ! is_int($entry['shards'] ?? null) || $entry['shards'] < 0
                || ! is_string($entry['drop_profile'] ?? null)
                || ! array_key_exists($entry['drop_profile'], $this->explorationDropConfig()['profiles'])
                || ! is_int($entry['item_level_min'] ?? null) || $entry['item_level_min'] < 1
                || ! is_int($entry['item_level_max'] ?? null)
                || $entry['item_level_max'] < $entry['item_level_min']
                || $entry['item_level_max'] > $this->equipmentCatalog->generatorItemLevelMax()
                || ! is_array($entry['enemy'] ?? null)) {
                throw new RuntimeException("Underground exploration encounter [{$key}] is invalid.");
            }
            $weightTotal += $entry['weight'];
            $encounters[] = [
                'key' => $key,
                'label' => $entry['label'],
                'weight' => $entry['weight'],
                'xp' => $entry['xp'],
                'shards' => $entry['shards'],
                'drop_profile' => $entry['drop_profile'],
                'item_level_min' => $entry['item_level_min'],
                'item_level_max' => $entry['item_level_max'],
            ];
        }
        if ($weightTotal !== 10_000) {
            throw new RuntimeException('Underground exploration encounter weights must total 10000 bps.');
        }
        $catalog = $this->explorationCatalog();
        foreach ($encounters as $encounter) {
            $catalog->enemy($encounter['key']);
        }

        return $encounters;
    }

    /**
     * @return array{
     *   key: string,
     *   label: string,
     *   weight: int,
     *   xp: int,
     *   shards: int,
     *   drop_profile: string,
     *   item_level_min: int,
     *   item_level_max: int
     * }
     */
    public function explorationEncounter(string $key, ?string $huntingGroundKey = null): array
    {
        foreach ($this->explorationEncounters($huntingGroundKey) as $encounter) {
            if ($encounter['key'] === $key) {
                return $encounter;
            }
        }
        $ground = $this->configuredHuntingGround($huntingGroundKey ?? $this->explorationHuntingGroundKey());
        $rare = $ground['rare_encounter'] ?? null;
        if (is_array($rare) && ($rare['key'] ?? null) === $key && is_array($rare['encounter'] ?? null)) {
            $encounter = $rare['encounter'];

            return [
                'key' => $key,
                'label' => $encounter['label'],
                'weight' => 0,
                'xp' => $encounter['xp'],
                'shards' => $encounter['shards'],
                'drop_profile' => $encounter['drop_profile'],
                'item_level_min' => $encounter['item_level_min'],
                'item_level_max' => $encounter['item_level_max'],
            ];
        }

        throw new UndergroundRuntimeException('underground_encounter_not_supported', '探索先の敵を解決できません。');
    }

    public function weightedExplorationEncounter(int $roll, ?string $huntingGroundKey = null): string
    {
        if ($roll < 1 || $roll > 10_000) {
            throw new RuntimeException('Underground exploration encounter roll is invalid.');
        }
        $upper = 0;
        foreach ($this->explorationEncounters($huntingGroundKey) as $encounter) {
            $upper += $encounter['weight'];
            if ($roll <= $upper) {
                return $encounter['key'];
            }
        }

        throw new RuntimeException('Underground exploration encounter weights are invalid.');
    }

    public function explorationCatalog(): AlphaV1BuildCatalog
    {
        $manifest = $this->laboratoryCatalog()->manifest();
        foreach ($this->explorationConfig()['grounds'] as $ground) {
            if (! is_array($ground) || ! is_array($ground['encounters'] ?? null)) {
                throw new RuntimeException('Underground exploration enemy catalog is invalid.');
            }
            foreach ($ground['encounters'] as $key => $entry) {
                if (! is_string($key) || ! is_array($entry) || ! is_array($entry['enemy'] ?? null)) {
                    throw new RuntimeException('Underground exploration enemy catalog is invalid.');
                }
                if (array_key_exists($key, $manifest['enemies'])) {
                    if ($manifest['enemies'][$key] !== $entry['enemy']) {
                        throw new RuntimeException('Underground exploration enemy catalog is invalid.');
                    }

                    continue;
                }
                $manifest['enemies'][$key] = $entry['enemy'];
            }
            $rare = $ground['rare_encounter'] ?? null;
            if (is_array($rare) && is_string($rare['key'] ?? null) && is_array($rare['encounter']['enemy'] ?? null)) {
                $key = $rare['key'];
                $enemy = $rare['encounter']['enemy'];
                if (array_key_exists($key, $manifest['enemies']) && $manifest['enemies'][$key] !== $enemy) {
                    throw new RuntimeException('Underground rare exploration enemy catalog is invalid.');
                }
                $manifest['enemies'][$key] = $enemy;
            }
        }

        return new AlphaV1BuildCatalog($manifest);
    }

    /** @return array<string, mixed> */
    public function guideDuel(): array
    {
        $definition = $this->data()['guide_duel'] ?? null;
        if (! is_array($definition) || ($definition['identity'] ?? null) !== 'secretary-underground-guide-duel-v1') {
            throw new RuntimeException('Guide duel definition is missing.');
        }

        return $definition;
    }

    public function guideDuelCatalog(): AlphaV1BuildCatalog
    {
        $manifest = $this->explorationCatalog()->manifest();
        $duel = $this->guideDuel();
        $manifest['enemies'][$duel['key']] = $duel['enemy'];

        return new AlphaV1BuildCatalog($manifest);
    }

    /** @return array<string, mixed> */
    public function madMoon(): array
    {
        return $this->data()['mad_moon'];
    }

    public function madMoonCatalog(): AlphaV1BuildCatalog
    {
        $event = $this->madMoon();
        $manifest = $this->explorationCatalog()->manifest();
        $manifest['skills'] = [...$manifest['skills'], ...$event['skills']];
        $manifest['statuses'] = [...$manifest['statuses'], ...$event['statuses']];
        $manifest['enemies'][$event['key']] = $event['enemy'];

        return new AlphaV1BuildCatalog($manifest);
    }

    /** @return array<string, mixed> */
    public function madMoonGuideSnapshot(string $playerGrowthPath): array
    {
        $pathKey = $playerGrowthPath === 'guardianship_blue' ? 'martial_red' : 'guardianship_blue';
        $catalog = $this->madMoonCatalog();
        $build = $catalog->build($this->growthPath($pathKey)['default_build_key']);
        $guide = $this->madMoon()['guide'];
        $level = $guide['level'];
        $points = $this->stpEntitlement($pathKey, $level);
        $allocated = [];
        foreach (AlphaV1CombatRules::STATS as $stat) {
            $allocated[$stat] = intdiv($points * $build['base_stats'][$stat], 100);
        }
        $allocated['agility'] += $points - array_sum($allocated);
        $items = [];
        foreach (UndergroundEquipmentCatalog::EQUIPPED_SLOTS as $index => $slot) {
            if ($slot === 'resonance') {
                continue;
            }
            $category = str_starts_with($slot, 'accessory_') ? 'accessory' : $slot;
            $definition = $this->generatedEquipment->generate($guide['item_level'], 'yunagi_harbor', 'rare', $category,
                $category === 'weapon' ? ($pathKey === 'martial_red' ? 'dagger' : 'longsword') : null,
                $category === 'accessory' ? ($pathKey === 'martial_red' ? 'might' : 'vitality') : null,
                41400 + $index, $this->madMoon()['identity']);
            $items[] = ['definition' => $definition, 'slot' => $slot,
                'catalog_identity' => $this->equipmentCatalog->identity(), 'instance_identity' => $definition['key']];
        }
        $equipment = $this->equipmentCatalog->combatLoadout($items);
        $allocations = [];
        foreach ($build['allocations'] as $nodeKey => $rank) {
            $node = $catalog->node($nodeKey)['node'];
            $slot = array_search($node['skill_key'] ?? null, $build['active_skills'], true);
            $allocations[$nodeKey] = ['rank' => $rank, 'active_slot' => $slot === false ? null : $slot + 1];
        }
        $definition = $this->playerCombatDefinition($catalog, $pathKey, $level, $allocated, $equipment, '案内人', null, $allocations, null);
        $snapshot = $definition['player_snapshot'];
        foreach (['stats', 'equipment'] as $key) {
            foreach ($snapshot[$key] as $field => $value) {
                if ($key === 'stats' || in_array($field, ['weapon_power', 'physical_defense', 'magical_defense', 'max_hp'], true)) {
                    $snapshot[$key][$field] = intdiv($value * $guide['scale_bps'], 10000);
                }
            }
        }
        foreach ($snapshot['equipment']['stats'] as &$stat) {
            $stat = intdiv($stat * $guide['scale_bps'], 10000);
        }
        unset($stat);
        unset($snapshot['current_hp']);
        $snapshot['key'] = 'mad_moon_guide';
        $snapshot['combatant_id'] = 'npc:guide';
        $snapshot['natural_recovery'] = $this->growthPath($pathKey)['natural_recovery'];
        $snapshot['awakening'] = ['unlocked' => false, 'gauge' => 0, 'message' => '案内人', 'growth_path' => $pathKey];

        return $snapshot;
    }

    /** @return array<string,mixed> */
    public function otherworld(): array
    {
        return $this->data()['otherworld'];
    }

    public function isOtherworldStage(string $key): bool
    {
        return isset($this->otherworld()['stages'][$key]);
    }

    public function otherworldCatalog(string $stageKey): AlphaV1BuildCatalog
    {
        $content = $this->otherworld();
        $stage = $content['stages'][$stageKey] ?? null;
        if (! is_array($stage)) {
            throw new RuntimeException('Unknown otherworld stage.');
        }
        $manifest = $this->explorationCatalog()->manifest();
        $manifest['skills'] = [...$manifest['skills'], ...$content['skills']];
        $manifest['statuses'] = [...$manifest['statuses'], ...$content['statuses']];
        $ultimateRules = $stage['abyssal_roar']
            ? [['conditions' => [['type' => 'own_hp_lte', 'percent' => $content['roar_hp_percent']],
                ['type' => 'skill_ready', 'skill' => 'bahamul_roar']], 'action' => 'skill:bahamul_roar']]
            : [
                ['conditions' => [['type' => 'self_has_status', 'status' => 'telegraph'], ['type' => 'skill_ready', 'skill' => 'bahamul_megaflare']], 'action' => 'skill:bahamul_megaflare'],
                ['conditions' => [['type' => 'own_hp_lte', 'percent' => $content['ultimate_hp_percent']], ['type' => 'skill_ready', 'skill' => 'bahamul_megaflare']], 'action' => 'skill:enemy_telegraph'],
            ];
        $manifest['enemies'][$stageKey] = [
            'label' => $stage['name'], 'boss' => true,
            'base_stats' => ['vitality' => $stage['might'], 'might' => $stage['might'], 'finesse' => $stage['finesse'],
                'spirit' => $stage['spirit'], 'agility' => $stage['agility']],
            'max_hp' => $stage['max_hp'], 'physical_defense' => $stage['physical_defense'],
            'magical_defense' => $stage['magical_defense'], 'weapon_power' => $stage['weapon_power'],
            'skills' => ['bahamul_black_claw', 'bahamul_breath', 'bahamul_dragon_wing', 'bahamul_megaflare',
                'bahamul_claw_telegraph', $stage['abyssal_roar'] ? 'bahamul_roar' : 'enemy_telegraph'], 'modifiers' => [],
            'normal_attack' => ['type' => 'damage', 'category' => 'physical', 'potency_bps' => 10000,
                'stat_coefficients' => ['might' => 10000], 'weapon_coefficient_bps' => 10000,
                'fixed' => 0, 'target_max_hp_bps' => 0, 'can_crit' => false, 'dodgeable' => true, 'hits' => 1],
            'ai_rules' => [
                // Finish the announced claw even if the ultimate HP threshold was crossed during its preparation.
                ['conditions' => [['type' => 'self_has_status', 'status' => 'bahamul_claw_ready'],
                    ['type' => 'self_has_status', 'status' => 'telegraph']], 'action' => 'skill:bahamul_black_claw'],
                ...$ultimateRules,
                ['conditions' => [['type' => 'round_modulo', 'modulo' => 6, 'equals' => 2]], 'action' => 'skill:bahamul_claw_telegraph'],
                ['conditions' => [['type' => 'round_modulo', 'modulo' => 6, 'equals' => 4]], 'action' => 'skill:bahamul_breath'],
                ['conditions' => [['type' => 'round_modulo', 'modulo' => 6, 'equals' => 0]], 'action' => 'skill:bahamul_dragon_wing'],
                ['conditions' => [['type' => 'always']], 'action' => 'normal_attack'],
            ],
            'charged_attack' => $stage['abyssal_roar'] ? $content['charged_attack'] : null,
        ];

        return new AlphaV1BuildCatalog($manifest);
    }

    public function trialCatalog(string $trialKey): AlphaV1BuildCatalog
    {
        $manifestPath = $this->runtimeCatalog->trial($trialKey)['balance_manifest'];
        try {
            $trial = json_decode(
                file_get_contents(config_path($manifestPath)) ?: '',
                true,
                512,
                JSON_THROW_ON_ERROR,
            );
        } catch (JsonException $exception) {
            throw new RuntimeException("Underground {$trialKey} manifest is invalid.", previous: $exception);
        }
        if (! is_array($trial)
            || ($trial['schema_version'] ?? null) !== 1
            || ($trial['combat_identity'] ?? null) !== AlphaV1CombatRules::IDENTITY
            || ! is_array($trial['skills'] ?? null)
            || ! is_array($trial['statuses'] ?? null)
            || ! is_array($trial['enemies'] ?? null)) {
            throw new RuntimeException("Underground {$trialKey} manifest is invalid.");
        }

        $manifest = $this->laboratoryCatalog()->manifest();
        foreach (['skills', 'statuses', 'enemies'] as $section) {
            foreach ($trial[$section] as $key => $definition) {
                if (! is_string($key) || ! is_array($definition) || array_key_exists($key, $manifest[$section])) {
                    throw new RuntimeException("Underground {$trialKey} {$section} catalog is invalid.");
                }
                $manifest[$section][$key] = $definition;
            }
        }

        return new AlphaV1BuildCatalog($manifest);
    }

    public function trialOneCatalog(): AlphaV1BuildCatalog
    {
        return $this->trialCatalog('trial_01');
    }

    /**
     * @param  array{vitality: int, might: int, finesse: int, spirit: int, agility: int}  $allocatedStp
     * @param  array<string, array{rank: int, active_slot: int|null}>  $skillAllocations
     * @param  array<string, mixed>  $equipment
     * @param  list<array<string, mixed>>|null  $customAiRules
     * @return array{catalog: AlphaV1BuildCatalog, player_snapshot: array<string, mixed>, progression_stats: array<string, int>, combat_stats: array<string, int>, equipment: array<string, mixed>, current_hp: int, max_hp: int, acquired_nodes: array<string, int>, active_skills: list<string>, passive_modifiers: array<string, int|bool|string>, ai: array{schema_version: int, rules: list<array<string, mixed>>, hash: string}}
     */
    public function explorationCombatDefinition(
        string $growthPathKey,
        int $combatLevel,
        array $allocatedStp,
        array $equipment,
        string $playerDisplayName,
        ?int $currentHp = null,
        array $skillAllocations = [],
        ?array $customAiRules = null,
    ): array {
        return $this->playerCombatDefinition(
            $this->explorationCatalog(),
            $growthPathKey,
            $combatLevel,
            $allocatedStp,
            $equipment,
            $playerDisplayName,
            $currentHp,
            $skillAllocations,
            $customAiRules,
        );
    }

    /**
     * @param  array{vitality: int, might: int, finesse: int, spirit: int, agility: int}  $allocatedStp
     * @param  array<string, array{rank: int, active_slot: int|null}>  $skillAllocations
     * @param  array<string, mixed>  $equipment
     * @param  list<array<string, mixed>>|null  $customAiRules
     * @return array{catalog: AlphaV1BuildCatalog, player_snapshot: array<string, mixed>, progression_stats: array<string, int>, combat_stats: array<string, int>, equipment: array<string, mixed>, current_hp: int, max_hp: int, acquired_nodes: array<string, int>, active_skills: list<string>, passive_modifiers: array<string, int|bool|string>, ai: array{schema_version: int, rules: list<array<string, mixed>>, hash: string}}
     */
    public function trialOneCombatDefinition(
        string $growthPathKey,
        int $combatLevel,
        array $allocatedStp,
        array $equipment,
        string $playerDisplayName,
        ?int $currentHp = null,
        array $skillAllocations = [],
        ?array $customAiRules = null,
    ): array {
        return $this->trialCombatDefinition(
            'trial_01',
            $growthPathKey,
            $combatLevel,
            $allocatedStp,
            $equipment,
            $playerDisplayName,
            $currentHp,
            $skillAllocations,
            $customAiRules,
        );
    }

    /**
     * @param  array{vitality: int, might: int, finesse: int, spirit: int, agility: int}  $allocatedStp
     * @param  array<string, array{rank: int, active_slot: int|null}>  $skillAllocations
     * @param  array<string, mixed>  $equipment
     * @param  list<array<string, mixed>>|null  $customAiRules
     * @return array{catalog: AlphaV1BuildCatalog, player_snapshot: array<string, mixed>, progression_stats: array<string, int>, combat_stats: array<string, int>, equipment: array<string, mixed>, current_hp: int, max_hp: int, acquired_nodes: array<string, int>, active_skills: list<string>, passive_modifiers: array<string, int|bool|string>, ai: array{schema_version: int, rules: list<array<string, mixed>>, hash: string}}
     */
    public function trialCombatDefinition(
        string $trialKey,
        string $growthPathKey,
        int $combatLevel,
        array $allocatedStp,
        array $equipment,
        string $playerDisplayName,
        ?int $currentHp = null,
        array $skillAllocations = [],
        ?array $customAiRules = null,
    ): array {
        return $this->playerCombatDefinition(
            $this->trialCatalog($trialKey),
            $growthPathKey,
            $combatLevel,
            $allocatedStp,
            $equipment,
            $playerDisplayName,
            $currentHp,
            $skillAllocations,
            $customAiRules,
        );
    }

    /**
     * @param  array{vitality: int, might: int, finesse: int, spirit: int, agility: int}  $allocatedStp
     * @param  array<string, array{rank: int, active_slot: int|null}>  $skillAllocations
     * @param  array<string, mixed>  $equipment
     * @param  list<array<string, mixed>>|null  $customAiRules
     * @return array{catalog: AlphaV1BuildCatalog, player_snapshot: array<string, mixed>, progression_stats: array<string, int>, combat_stats: array<string, int>, equipment: array<string, mixed>, current_hp: int, max_hp: int, acquired_nodes: array<string, int>, active_skills: list<string>, passive_modifiers: array<string, int|bool|string>, ai: array{schema_version: int, rules: list<array<string, mixed>>, hash: string}}
     */
    private function playerCombatDefinition(
        AlphaV1BuildCatalog $catalog,
        string $growthPathKey,
        int $combatLevel,
        array $allocatedStp,
        array $equipment,
        string $playerDisplayName,
        ?int $currentHp,
        array $skillAllocations,
        ?array $customAiRules,
    ): array {
        $progressionStats = $this->currentStats($growthPathKey, $combatLevel, $allocatedStp);
        $combatStats = $this->combatStats($progressionStats, $equipment);
        $maxHp = $this->maxHp($combatStats, $equipment);
        $currentHp ??= $maxHp;
        if ($currentHp < 1 || $currentHp > $maxHp) {
            throw new RuntimeException('Underground current HP is invalid.');
        }

        $weaponStyle = $equipment['weapon_style'] ?? null;
        if (! is_string($weaponStyle) || $weaponStyle === '') {
            throw new RuntimeException('Underground player weapon style is invalid.');
        }
        $skillBuild = $this->playerSkillBuild($skillAllocations, $weaponStyle);
        $aiRules = $customAiRules === null
            ? $this->aiConfiguration->defaultRules($skillBuild['ai_rules'], $catalog)
            : $this->aiConfiguration->normalizeRules($customAiRules, $catalog);
        $ai = $this->aiConfiguration->snapshot($aiRules, $catalog);

        return [
            'catalog' => $catalog,
            'player_snapshot' => [
                'key' => 'secretary_runtime',
                'label' => $playerDisplayName,
                'stats' => $progressionStats,
                'active_skills' => $skillBuild['active_skills'],
                'ai_rules' => $ai['rules'],
                'ai_mode' => $customAiRules === null ? 'default' : 'custom',
                'modifiers' => $skillBuild['passive_modifiers'],
                'equipment' => $equipment,
                'current_hp' => $currentHp,
            ],
            'progression_stats' => $progressionStats,
            'combat_stats' => $combatStats,
            'equipment' => $equipment,
            'current_hp' => $currentHp,
            'max_hp' => $maxHp,
            'acquired_nodes' => $skillBuild['acquired_nodes'],
            'active_skills' => $skillBuild['active_skills'],
            'passive_modifiers' => $skillBuild['passive_modifiers'],
            'ai' => $ai,
        ];
    }

    /** @return array<string, mixed> */
    public function playtestOptions(string $growthPathKey): array
    {
        $playtest = $this->playtestConfig();
        $catalog = $this->laboratoryCatalog();
        $builds = [];
        foreach ($playtest['builds'] as $key => $configured) {
            if (! is_string($key) || ! is_array($configured)) {
                throw new RuntimeException('Underground playtest build configuration is invalid.');
            }
            $builds[] = [
                'key' => $key,
                'label' => $this->string($catalog->build($key), 'label'),
                'description' => $this->string($configured, 'description'),
            ];
        }
        $enemies = [];
        foreach ($playtest['enemies'] as $key => $configured) {
            if (! is_string($key) || ! is_array($configured)) {
                throw new RuntimeException('Underground playtest enemy configuration is invalid.');
            }
            $catalog->enemy($key);
            $enemies[] = [
                'key' => $key,
                'label' => $this->string($configured, 'label'),
                'description' => $this->string($configured, 'description'),
            ];
        }

        return [
            'notice' => $this->string($playtest, 'notice'),
            'default_build_key' => $this->growthPath($growthPathKey)['default_build_key'],
            'builds' => $builds,
            'enemies' => $enemies,
        ];
    }

    /** @return array{catalog: AlphaV1BuildCatalog, identity: string, tier_key: string, max_rounds: int, build_label: string, enemy_label: string, ai: array{schema_version: int, rules: list<array<string, mixed>>, hash: string}} */
    public function playtestDefinition(string $buildKey, string $enemyKey): array
    {
        $playtest = $this->playtestConfig();
        $build = $playtest['builds'][$buildKey] ?? null;
        $enemy = $playtest['enemies'][$enemyKey] ?? null;
        if (! is_array($build) || ! is_array($enemy)) {
            throw new UndergroundRuntimeException(
                'underground_playtest_selection_invalid',
                '力試しのbuildまたは対戦相手を確認してください。',
            );
        }
        $maxRounds = $enemy['max_rounds'] ?? null;
        if (! is_int($maxRounds) || $maxRounds < 1 || $maxRounds > 100) {
            throw new RuntimeException('Underground playtest round contract is invalid.');
        }
        $catalog = $this->laboratoryCatalog();
        $buildDefinition = $catalog->build($buildKey);
        $catalog->enemy($enemyKey);

        return [
            'catalog' => $catalog,
            'identity' => $this->string($playtest, 'identity'),
            'tier_key' => $this->string($playtest, 'tier_key'),
            'max_rounds' => $maxRounds,
            'build_label' => $this->string($buildDefinition, 'label'),
            'enemy_label' => $this->string($enemy, 'label'),
            'ai' => $this->aiSnapshotForBuild($buildDefinition, $catalog),
        ];
    }

    /** @return array{catalog: AlphaV1BuildCatalog, build_key: string, enemy_key: string, tier_key: string, combat_level_equivalent: int, enemy_scale_bps: int, seed: int, max_rounds: int, expected_winner: string, ai: array{schema_version: int, rules: list<array<string, mixed>>, hash: string}} */
    public function trueNameStoryBattle(): array
    {
        $definition = $this->data()['true_name_story_battle'];
        $manifest = $this->laboratoryCatalog()->manifest();
        $buildKey = $this->string($definition, 'build_key');
        $enemyKey = $this->string($definition, 'enemy_key');
        $manifest['builds'][$buildKey] = $definition['build'];
        $manifest['enemies'][$enemyKey] = $definition['enemy'];
        $catalog = new AlphaV1BuildCatalog($manifest);
        $seed = $definition['seed'] ?? null;
        $maxRounds = $definition['max_rounds'] ?? null;
        $equivalentCombatLevel = $definition['combat_level_equivalent'] ?? null;
        if (! is_int($seed) || ! is_int($maxRounds) || ! is_int($equivalentCombatLevel)) {
            throw new RuntimeException('Underground true-name story battle contract is invalid.');
        }
        $build = $catalog->build($buildKey);

        return [
            'catalog' => $catalog,
            'build_key' => $buildKey,
            'enemy_key' => $enemyKey,
            'tier_key' => $this->string($definition, 'tier_key'),
            'combat_level_equivalent' => $equivalentCombatLevel,
            'enemy_scale_bps' => $this->rules->storyBenchmarkScaleBps($equivalentCombatLevel),
            'seed' => $seed,
            'max_rounds' => $maxRounds,
            'expected_winner' => $this->string($definition, 'expected_winner'),
            'ai' => $this->aiSnapshotForBuild($build, $catalog),
        ];
    }

    /**
     * @param  array<string, mixed>  $build
     * @return array{schema_version: int, rules: list<array<string, mixed>>, hash: string}
     */
    private function aiSnapshotForBuild(array $build, AlphaV1BuildCatalog $catalog): array
    {
        $rules = $build['ai_rules'] ?? null;
        if (! is_array($rules) || ! array_is_list($rules)) {
            throw new RuntimeException('Underground build AI rules are invalid.');
        }

        return $this->aiConfiguration->snapshot($rules, $catalog);
    }

    public function laboratoryCatalog(): AlphaV1BuildCatalog
    {
        try {
            $manifest = json_decode(
                file_get_contents(config_path('underground/balance/foundation-v4.json')) ?: '',
                true,
                512,
                JSON_THROW_ON_ERROR,
            );
        } catch (JsonException $exception) {
            throw new RuntimeException('Underground alpha-v1 manifest is invalid.', previous: $exception);
        }
        if (! is_array($manifest)) {
            throw new RuntimeException('Underground alpha-v1 manifest is invalid.');
        }

        return new AlphaV1BuildCatalog($manifest);
    }

    /** @return array<string, mixed> */
    private function playtestConfig(): array
    {
        $playtest = $this->data()['playtest'];
        if (! is_array($playtest['builds'] ?? null) || ! is_array($playtest['enemies'] ?? null)) {
            throw new RuntimeException('Underground playtest configuration is invalid.');
        }

        return $playtest;
    }

    /**
     * @return array{
     *   identity: string,
     *   profiles: array<string, array{presence_bps: int, rarity_weights: array<string, int>}>,
     *   category_weights: array<string, int>,
     *   weapon_styles: list<string>,
     *   accessory_main_stats: list<string>
     * }
     */
    public function explorationDropConfig(): array
    {
        $drop = $this->explorationConfig()['drop'] ?? null;
        if (! is_array($drop)
            || ! is_string($drop['identity'] ?? null) || $drop['identity'] === ''
            || ! is_array($drop['profiles'] ?? null)
            || ! is_array($drop['category_weights'] ?? null)
            || ! is_array($drop['weapon_styles'] ?? null)
            || ! array_is_list($drop['weapon_styles'])
            || ! is_array($drop['accessory_main_stats'] ?? null)
            || ! array_is_list($drop['accessory_main_stats'])) {
            throw new RuntimeException('Underground exploration drop configuration is invalid.');
        }
        $rarities = ['common', 'uncommon', 'rare', 'epic'];
        if ($drop['profiles'] === []) {
            throw new RuntimeException('Underground exploration drop pool is invalid.');
        }
        foreach ($drop['profiles'] as $profileKey => $profile) {
            $weights = is_array($profile) ? ($profile['rarity_weights'] ?? null) : null;
            if (! is_string($profileKey) || $profileKey === '' || ! is_array($profile)
                || ! is_int($profile['presence_bps'] ?? null)
                || $profile['presence_bps'] < 0 || $profile['presence_bps'] > 10_000
                || ! is_array($weights)
                || array_keys($weights) !== $rarities
                || array_filter($weights, static fn (mixed $weight): bool => ! is_int($weight) || $weight < 0) !== []
                || array_sum($weights) !== 10_000) {
                throw new RuntimeException("Underground exploration drop profile [{$profileKey}] is invalid.");
            }
        }
        if (array_keys($drop['category_weights']) !== ['weapon', 'armor', 'accessory']
            || array_filter(
                $drop['category_weights'],
                static fn (mixed $weight): bool => ! is_int($weight) || $weight < 0,
            ) !== []
            || array_sum($drop['category_weights']) !== 10_000
            || $drop['weapon_styles'] !== ['dagger', 'rapier', 'longsword', 'crystal_staff']
            || $drop['accessory_main_stats'] !== AlphaV1CombatRules::STATS) {
            throw new RuntimeException('Underground exploration drop pool is invalid.');
        }

        return $drop;
    }

    /** @return array<string, mixed> */
    private function configuredHuntingGround(string $key): array
    {
        $ground = $this->explorationConfig()['grounds'][$key] ?? null;
        if (! is_array($ground)) {
            throw new UndergroundRuntimeException(
                'underground_hunting_ground_not_supported',
                '狩場を確認してください。',
            );
        }
        $this->validatedHuntingGround($key, $ground);

        return $ground;
    }

    /**
     * @param  array<string, mixed>  $ground
     * @return ExplorationHuntingGround
     */
    private function validatedHuntingGround(string $key, array $ground): array
    {
        $requiredTrial = $ground['required_trial_key'] ?? null;
        $enemyCounts = $ground['enemy_count_by_party_size'] ?? null;
        $kind = $ground['kind'] ?? 'hunting_ground';
        $rare = $ground['rare_encounter'] ?? null;
        $entryKeyCost = $ground['entry_key_cost'] ?? 0;
        $vaultBaseG = $ground['vault_base_g'] ?? null;
        $treasureMultiplier = $ground['treasure_multiplier'] ?? null;
        $forcedDropProfile = $ground['forced_drop_profile'] ?? null;
        $dropTierKey = $ground['drop_tier_key'] ?? $key;
        $keyReward = $ground['key_reward'] ?? null;
        $keyBalanceField = $ground['key_balance_field'] ?? 'shining_kingdom_key_balance';
        $keyLabel = $ground['key_label'] ?? '輝きの王国の鍵';
        if ($key === ''
            || ! is_string($ground['content_identity'] ?? null) || $ground['content_identity'] === ''
            || ! is_string($ground['name'] ?? null) || $ground['name'] === ''
            || ($requiredTrial !== null && (! is_string($requiredTrial) || $requiredTrial === ''))
            || ! is_int($ground['item_level_min'] ?? null) || $ground['item_level_min'] < 1
            || ! is_int($ground['item_level_max'] ?? null)
            || $ground['item_level_max'] < $ground['item_level_min']
            || $ground['item_level_max'] > $this->equipmentCatalog->generatorItemLevelMax()
            || ! is_array($ground['encounters'] ?? null) || $ground['encounters'] === []
            || ! is_array($enemyCounts) || array_keys($enemyCounts) !== [1, 2, 3, 4]
            || array_filter($enemyCounts, static fn (mixed $count): bool => ! is_int($count) || $count < 1) !== []
            || ! in_array($kind, ['hunting_ground', 'vault'], true)
            || ! is_int($entryKeyCost) || $entryKeyCost < 0
            || ! in_array($keyBalanceField, ['shining_kingdom_key_balance', 'yunagi_harbor_key_balance'], true)
            || ! is_string($keyLabel) || $keyLabel === ''
            || ! is_string($dropTierKey) || $dropTierKey === ''
            || ($kind === 'vault' && ($entryKeyCost < 1 || ! is_int($vaultBaseG) || $vaultBaseG < 0
                || ! is_int($treasureMultiplier) || $treasureMultiplier < 1
                || ! is_string($forcedDropProfile)
                || ! array_key_exists($forcedDropProfile, $this->explorationDropConfig()['profiles'])))
            || ($rare !== null && (! is_array($rare) || ! is_string($rare['key'] ?? null)
                || ! is_int($rare['chance_bps'] ?? null) || $rare['chance_bps'] < 1 || $rare['chance_bps'] > 10_000
                || ! is_array($rare['encounter'] ?? null)
                || ! is_int($rare['distorted_stone_quantity'] ?? 0) || ($rare['distorted_stone_quantity'] ?? 0) < 0))
            || ($keyReward !== null && (! is_array($keyReward)
                || ! is_int($keyReward['normal_chance_bps'] ?? null)
                || $keyReward['normal_chance_bps'] < 0 || $keyReward['normal_chance_bps'] > 10_000
                || ! is_int($keyReward['rare_quantity'] ?? null) || $keyReward['rare_quantity'] < 0))) {
            throw new RuntimeException("Underground hunting ground [{$key}] is invalid.");
        }

        return [
            'key' => $key,
            'content_identity' => $ground['content_identity'],
            'name' => $ground['name'],
            'kind' => $kind,
            'required_trial_key' => $requiredTrial,
            'enemy_count_by_party_size' => $enemyCounts,
            'item_level_min' => $ground['item_level_min'],
            'item_level_max' => $ground['item_level_max'],
            'rare_encounter' => $rare,
            'key_reward' => $keyReward,
            'key_balance_field' => $keyBalanceField,
            'key_label' => $keyLabel,
            'entry_key_cost' => $entryKeyCost,
            'vault_base_g' => $vaultBaseG,
            'treasure_multiplier' => $treasureMultiplier,
            'forced_drop_profile' => $forcedDropProfile,
            'drop_tier_key' => $dropTierKey,
        ];
    }

    /** @return array<string, mixed> */
    private function explorationConfig(): array
    {
        $exploration = $this->data()['exploration'];
        if (! is_array($exploration['grounds'] ?? null)
            || $exploration['grounds'] === []
            || ! is_array($exploration['drop'] ?? null)
            || ! is_array($exploration['starter_weapon'] ?? null)
            || ! is_array($exploration['player_ai_rules'] ?? null)
            || ! is_array($exploration['player_skill_ai_rules'] ?? null)) {
            throw new RuntimeException('Underground exploration configuration is invalid.');
        }

        return $exploration;
    }

    /** @return array<string, mixed> */
    private function shopConfig(): array
    {
        $shop = $this->data()['shop'];
        if (! is_array($shop['inn'] ?? null) || ! is_array($shop['bank'] ?? null)) {
            throw new RuntimeException('Underground shop configuration is invalid.');
        }

        return $shop;
    }

    /** @return array<string, mixed> */
    private function data(): array
    {
        $data = config('underground-alpha-v1');
        if (! is_array($data) || ($data['schema_version'] ?? null) !== 1
            || ! is_array($data['growth_paths'] ?? null)
            || ! is_string($data['skill_tree_identity'] ?? null)
            || ! is_int($data['initial_skill_points'] ?? null)
            || ! is_array($data['player_skill_guidance'] ?? null)
            || ! is_array($data['exploration'] ?? null)
            || ! is_array($data['shop'] ?? null)
            || ! is_array($data['playtest'] ?? null)
            || ! is_array($data['true_name_story_battle'] ?? null)) {
            throw new RuntimeException('Underground alpha-v1 player configuration is invalid.');
        }

        return $data;
    }

    /** @return list<string> */
    private function recommendedStats(string $skillKey): array
    {
        $guidance = $this->data()['player_skill_guidance'][$skillKey] ?? null;
        $stats = is_array($guidance) ? ($guidance['recommended_stats'] ?? null) : null;
        if (! is_array($stats) || ! array_is_list($stats)
            || count(array_unique($stats)) !== count($stats)) {
            throw new RuntimeException("Underground player skill guidance [{$skillKey}] is invalid.");
        }
        foreach ($stats as $stat) {
            if (! is_string($stat) || ! in_array($stat, AlphaV1CombatRules::STATS, true)) {
                throw new RuntimeException("Underground player skill guidance [{$skillKey}] is invalid.");
            }
        }

        return $stats;
    }

    /** @param array<string, mixed> $values */
    private function string(array $values, string $key): string
    {
        $value = $values[$key] ?? null;

        return is_string($value) && $value !== ''
            ? $value
            : throw new RuntimeException("Underground alpha-v1 [{$key}] is invalid.");
    }

    /**
     * @param  list<string>  $activeSkills
     * @return list<array<string, mixed>>
     */
    private function playerAiRules(array $activeSkills): array
    {
        $configured = $this->explorationConfig()['player_skill_ai_rules'];
        $emergencyActions = ['skill:mending_prayer', 'skill:renewing_guard', 'skill:draining_cut'];
        $emergency = [];
        $remaining = [];
        foreach ($configured as $rule) {
            $action = is_array($rule) ? ($rule['action'] ?? null) : null;
            if (! is_string($action) || ! str_starts_with($action, 'skill:')) {
                throw new RuntimeException('Underground player skill AI rule is invalid.');
            }
            if (! in_array(substr($action, 6), $activeSkills, true)) {
                continue;
            }
            if (in_array($action, $emergencyActions, true)) {
                $emergency[] = $rule;
            } else {
                $remaining[] = $rule;
            }
        }
        $base = $this->explorationConfig()['player_ai_rules'];
        $fallback = array_pop($base);
        if (! is_array($fallback) || ($fallback['action'] ?? null) !== 'normal_attack') {
            throw new RuntimeException('Underground player AI fallback is invalid.');
        }

        return [...$emergency, ...$base, ...$remaining, $fallback];
    }

    /** @param array<string, mixed> $skill */
    private function skillSupportsWeaponStyle(array $skill, string $weaponStyle): bool
    {
        $required = $skill['required_weapon_styles'] ?? [];
        if (! is_array($required) || ! array_is_list($required)) {
            throw new RuntimeException('Underground active skill weapon requirement is invalid.');
        }
        foreach ($required as $style) {
            if (! is_string($style) || $style === '') {
                throw new RuntimeException('Underground active skill weapon requirement is invalid.');
            }
        }

        return $required === [] || in_array($weaponStyle, $required, true);
    }
}
