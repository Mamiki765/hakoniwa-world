<?php

declare(strict_types=1);

require '/var/www/html/vendor/autoload.php';
require __DIR__.'/catalog-before.php';

use App\Domain\Secretary\SecretaryItemCatalog;
use App\Domain\Secretary\SecretaryItemGameplayContract;
use App\Domain\Secretary\UncachedSecretaryItemCatalog;

$settings = require '/var/www/html/config/hakoniwa/rulesets/hakoniwa-2s-plus-v41.php';
$baseline = new UncachedSecretaryItemCatalog;
$candidate = new SecretaryItemCatalog;
$keys = array_keys($baseline->definitions());
$results = [];
foreach (['before' => $baseline, 'after' => $candidate] as $name => $catalog) {
    $contract = new SecretaryItemGameplayContract($catalog);
    $workloads = [
        'definitions' => [5000, fn () => $catalog->definitions()],
        'lookup' => [5000, fn () => $catalog->definition($keys[0])],
        'category_limits' => [1000, fn () => $catalog->categoryLimits()],
        'validated_effect_catalog' => [500, fn () => $contract->validatedEffectCatalog($settings)],
    ];
    foreach ($workloads as $key => [$calls, $run]) {
        $samples = [];
        $hashes = [];
        for ($round = 0; $round < 3; $round++) {
            $start = hrtime(true);
            for ($i = 0; $i < $calls; $i++) {
                $result = $run();
            }
            $samples[] = (hrtime(true) - $start) / 1e6;
            $hashes[] = hash('sha256', serialize($result));
        }
        $sorted = $samples;
        sort($sorted);
        $results[$key][$name] = ['calls' => $calls, 'samples_ms' => $samples, 'median_ms' => $sorted[1], 'output_hashes' => $hashes];
    }
    $all = [];
    foreach ($keys as $key) {
        $all[$key] = [$catalog->definition($key), $catalog->maximumRetainedLevel($key),
            $catalog->definitionWithResolvedEconomics($key, SecretaryItemCatalog::RARITY_CURSED, 0)];
    }
    $outputs[$name] = hash('sha256', serialize([$all, $catalog->categoryLimits(), $contract->validatedEffectCatalog($settings)]));
}
foreach ($results as $key => &$rows) {
    if (count(array_unique([...$rows['before']['output_hashes'], ...$rows['after']['output_hashes']])) !== 1) {
        throw new RuntimeException("Output changed: {$key}");
    }
    $rows['ratio_before_over_after'] = $rows['before']['median_ms'] / $rows['after']['median_ms'];
}
unset($rows);
if ($outputs['before'] !== $outputs['after']) {
    throw new RuntimeException('Full catalog/effect/economics output changed.');
}
echo json_encode(['php' => PHP_VERSION, 'opcache_cli' => ini_get('opcache.enable_cli'), 'ruleset' => $settings['key'],
    'item_count' => count($keys), 'baseline_sha' => '2e93ec918774ad64d787aba99fc59a7bc3e54d16',
    'baseline_loader' => 'Full fixed source renamed to an uncached subclass; all base constants retained; no application/DB boot.',
    'results' => $results, 'full_output_hashes' => $outputs], JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR), "\n";
