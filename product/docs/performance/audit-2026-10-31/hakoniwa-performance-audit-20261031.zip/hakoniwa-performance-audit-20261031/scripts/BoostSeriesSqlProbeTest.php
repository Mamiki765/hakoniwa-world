<?php
declare(strict_types=1);
namespace Tests\Feature;

use App\Application\BoostScheduleService;
use App\Models\AuthIdentity;
use App\Models\BoostOccurrence;
use App\Models\RulesetVersion;
use App\Models\User;
use App\Models\World;
use Carbon\CarbonImmutable;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Tests\TestCase;

/** A one-case research probe, stored outside the repository. */
final class BoostSeriesSqlProbeTest extends TestCase
{
    use RefreshDatabase;

    public function test_admin_projection_repeats_the_same_series_lookup(): void
    {
        CarbonImmutable::setTestNow('2026-10-31T12:00:00Z');
        try {
            config(['hakoniwa.admin.discord_user_id' => 'audit-admin']);
            $actor = User::factory()->create();
            AuthIdentity::query()->create(['user_id' => $actor->id, 'provider' => 'discord',
                'provider_user_id' => 'audit-admin', 'display_name' => 'Audit fixture']);
            $world = World::query()->create(['key' => 'audit-boost', 'name' => 'Audit fixture',
                'ruleset_version_id' => RulesetVersion::query()->firstOrFail()->id, 'current_turn' => 1]);
            $series = DB::table('boost_series')->insertGetId(['world_id' => $world->id, 'created_by' => $actor->id,
                'request_id' => (string) Str::uuid(), 'kind' => 'hunting_ground', 'title' => 'Audit fixture',
                'schedule' => '{}', 'created_at' => now(), 'updated_at' => now()]);
            for ($i = 0; $i < 3; $i++) {
                BoostOccurrence::query()->create(['world_id' => $world->id, 'boost_series_id' => $series,
                    'occurrence_number' => $i + 1, 'kind' => 'hunting_ground',
                    'starts_at' => CarbonImmutable::now()->addDays($i + 1),
                    'ends_at' => CarbonImmutable::now()->addDays($i + 1)->addHours(2)]);
            }
            $queries = [];
            DB::listen(static function ($query) use (&$queries): void {
                $queries[] = ['sql' => $query->sql, 'bindings' => $query->bindings, 'time_ms' => $query->time];
            });
            $started = hrtime(true);
            $data = app(BoostScheduleService::class)->adminStatus($actor, $world);
            $duration = (hrtime(true) - $started) / 1e6;
            $seriesQueries = array_values(array_filter($queries,
                static fn (array $q): bool => str_contains($q['sql'], 'from "boost_series"')));
            $this->assertCount(3, $data['occurrences']);
            $this->assertSame([3, 2, 1], array_column($data['occurrences'], 'occurrence_number'));
            $this->assertSame(0, $data['uncompensated_turns']);
            $this->assertCount(4, $seriesQueries); // public first-per-kind + three admin rows
            file_put_contents('/audit/evidence/api-boost-series-queries.json', json_encode([
                'type' => 'isolated_current_code_pg_query_count', 'source_sha' => '2e93ec918774ad64d787aba99fc59a7bc3e54d16',
                'php' => PHP_VERSION, 'fixture' => ['series' => 1, 'occurrences' => 3, 'kind' => 'hunting_ground'],
                'projection_elapsed_ms' => $duration, 'series_queries' => count($seriesQueries),
                'all_queries' => count($queries), 'queries' => $queries,
                'limits' => 'One synthetic fixture and one current-code invocation. No candidate patch, no latency speedup claim.'
            ], JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR));
        } finally {
            CarbonImmutable::setTestNow();
        }
    }
}
