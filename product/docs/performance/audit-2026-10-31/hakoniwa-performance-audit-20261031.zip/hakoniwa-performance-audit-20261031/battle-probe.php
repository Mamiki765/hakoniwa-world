<?php
// Isolated short probe. Reads immutable app/config mounts; never boots Laravel or a DB.
$mode = $argv[1] ?? 'baseline';
$GLOBALS['probe_counts'] = [];
function bump(string $key): void { $GLOBALS['probe_counts'][$key] = ($GLOBALS['probe_counts'][$key] ?? 0) + 1; }
function config_path(string $path): string { return '/var/www/html/config/'.$path; }
function config(string $key, mixed $default = null): mixed {
    static $configs = [];
    $parts = explode('.', $key); $name = array_shift($parts);
    $configs[$name] ??= require config_path($name.'.php');
    $value = $configs[$name];
    foreach ($parts as $part) { if (! is_array($value) || ! array_key_exists($part, $value)) { return $default; } $value = $value[$part]; }
    return $value;
}
spl_autoload_register(function (string $class) use ($mode): void {
    if (! str_starts_with($class, 'App\\')) { return; }
    $path = '/var/www/html/app/'.str_replace('\\', '/', substr($class, 4)).'.php';
    $source = file_get_contents($path);
    if ($class === App\Domain\Underground\Combat\PriorityCombatAi::class) {
        $needle = "    ): array {\n        if (\$startRuleIndex";
        $source = str_replace($needle, "    ): array {\n        \\bump('ai_select');\n        if (\$startRuleIndex", $source, $n);
        if ($n !== 1) { throw new RuntimeException('AI instrumentation mismatch'); }
    }
    if ($class === App\Domain\Underground\Combat\BuildCombatState::class) {
        $source = str_replace("public function stat(string \$key): int\n    {", "public function stat(string \$key): int\n    {\n        \\bump('stat');", $source, $n);
        if ($n !== 1) { throw new RuntimeException('stat instrumentation mismatch'); }
    }
    if ($class === App\Domain\Underground\Combat\UndergroundRandom::class) {
        $source = str_replace("public function integer(string \$label, int \$minimum, int \$maximum): int\n    {", "public function integer(string \$label, int \$minimum, int \$maximum): int\n    {\n        \\bump('random_integer');", $source, $n);
        if ($n !== 1) { throw new RuntimeException('RNG instrumentation mismatch'); }
        $source = str_replace("if (! isset(\$this->streams[\$label])) {", "if (! isset(\$this->streams[\$label])) {\n            \\bump('random_stream');", $source);
    }
    if ($class === App\Application\Underground\UndergroundAlphaV1PlayerCatalog::class) {
        $source = str_replace("public function laboratoryCatalog(): AlphaV1BuildCatalog\n    {", "public function laboratoryCatalog(): AlphaV1BuildCatalog\n    {\n        \\bump('laboratory_catalog');", $source, $n);
        if ($n !== 1) { throw new RuntimeException('catalog instrumentation mismatch'); }
    }
    if ($class === App\Domain\Underground\Combat\AlphaV1CombatModel::class && $mode === 'ai_reuse') {
        $source = str_replace("        \$nextRuleIndex = 0;", "        \$preselected = null;\n        \$nextRuleIndex = 0;", $source, $n);
        if ($n !== 1) { throw new RuntimeException('AI local prototype start mismatch'); }
        $needle = "            if (\$candidate['type'] === 'awakening') {";
        $source = str_replace($needle, "            \$preselected = \$candidate['type'] !== 'awakening' ? \$candidate : null;\n".$needle, $source, $n);
        if ($n !== 1) { throw new RuntimeException('AI local prototype candidate mismatch'); }
        $needle = "            \$action = \$this->ai->select(\$actor, \$target, \$catalog, \$round, \$nextRuleIndex, \$partyAllies, \$partyEnemies);";
        $source = str_replace($needle, "            \$action = \$preselected ?? \$this->ai->select(\$actor, \$target, \$catalog, \$round, \$nextRuleIndex, \$partyAllies, \$partyEnemies);\n            \$preselected = null;", $source, $n);
        if ($n !== 1) { throw new RuntimeException('AI local prototype while mismatch'); }
    }
    eval(substr($source, 5));
});
use App\Application\Underground\UndergroundAlphaV1PlayerCatalog;
use App\Domain\Underground\Combat\AlphaV1CombatModel;
use App\Domain\Underground\Combat\AlphaV1CombatRules;
use App\Domain\Underground\Combat\CanonicalCombatOrchestrator;
use App\Domain\Underground\Combat\DeterministicEquipmentGenerator;
use App\Domain\Underground\Combat\PriorityCombatAi;
use App\Domain\Underground\Combat\UndergroundAwakening;
use App\Domain\Underground\Combat\UndergroundBuildValidator;
$rules = new AlphaV1CombatRules;
$validator = new UndergroundBuildValidator($rules);
$players = new UndergroundAlphaV1PlayerCatalog($rules, $validator);
$model = new AlphaV1CombatModel($rules, $validator, new DeterministicEquipmentGenerator($rules), new PriorityCombatAi, new CanonicalCombatOrchestrator, new UndergroundAwakening);
$manifest = json_decode(file_get_contents(config_path('underground/balance/foundation-v4.json')), true, 512, JSON_THROW_ON_ERROR);
$catalog = $players->laboratoryCatalog();
$measure = function (callable $work): array {
    $GLOBALS['probe_counts'] = []; $start = hrtime(true); $value = $work();
    return ['elapsed_ms' => (hrtime(true) - $start) / 1e6, 'calls' => $GLOBALS['probe_counts'], 'value' => $value];
};
$results = ['mode' => $mode, 'php' => PHP_VERSION, 'source_sha' => '2e93ec918774ad64d787aba99fc59a7bc3e54d16', 'fixture' => 'read-only config + pure PHP, no DB, no network', 'manifest_bytes' => filesize(config_path('underground/balance/foundation-v4.json')), 'manifest_skills' => count($manifest['skills']), 'manifest_statuses' => count($manifest['statuses'])];
$results['catalog_16_calls'] = $measure(function () use ($players): int { for ($i = 0; $i < 16; $i++) { $value = $players->laboratoryCatalog(); } return count($value->manifest()['skills']); });
$results['catalog_16_references'] = $measure(function () use ($players): int { $cache = $players->laboratoryCatalog(); for ($i = 0; $i < 16; $i++) { $value = $cache; } return count($value->manifest()['skills']); });
$results['laboratory_32_fights'] = $measure(function () use ($model, $catalog): array {
    $rows = []; foreach (['pure_attacker', 'pure_tank', 'pure_healer', 'balanced'] as $build) { for ($seed = 1; $seed <= 8; $seed++) {
        $r = $model->fight($catalog, $build, 'endurance_construct', 'late', $seed, 100);
        $rows[] = ['seed' => $seed, 'build' => $build, 'rounds' => $r->rounds, 'hash' => hash('sha256', serialize($r))];
    }} return $rows;
});
$zero = ['vitality' => 0, 'might' => 0, 'finesse' => 0, 'spirit' => 0, 'agility' => 0];
$equipment = $players->starterWeapon();
$def = $players->explorationCombatDefinition('martial_red', 10, $zero, $equipment, 'synthetic_probe', null, [], null);
$snapshot = $def['player_snapshot'];
$snapshot['awakening'] = ['unlocked' => false, 'gauge' => 0, 'growth_path' => 'martial_red', 'technique_key' => null, 'message' => 'probe'];
$enemies = array_keys($players->explorationHuntingGrounds()[0]['encounters'] ?? []);
$encounters = $players->explorationEncounters();
$enemyKey = $encounters[0]['key'];
$results['runtime_8_solo_fights'] = $measure(function () use ($model, $def, $snapshot, $enemyKey): array {
    $rows = []; for ($seed = 1; $seed <= 8; $seed++) {
        $r = $model->fightPlayerSnapshot($def['catalog'], $snapshot, $enemyKey, $seed, 100, 1000);
        $rows[] = ['seed' => $seed, 'rounds' => $r->rounds, 'hash' => hash('sha256', serialize($r))];
    } return $rows;
});
$partySnapshots = [];
for ($i = 1; $i <= 4; $i++) { $partySnapshots[] = [...$snapshot, 'combatant_id' => 'probe:'.$i, 'natural_recovery' => 1000]; }
$results['runtime_8_party_fights'] = $measure(function () use ($model, $def, $partySnapshots, $enemyKey): array {
    $rows = []; for ($seed = 1; $seed <= 8; $seed++) {
        $r = $model->fightPartySnapshots($def['catalog'], $partySnapshots, [$enemyKey,$enemyKey,$enemyKey,$enemyKey], $seed, 100, 1000);
        $rows[] = ['seed' => $seed, 'rounds' => $r->rounds, 'hash' => hash('sha256', serialize($r))];
    } return $rows;
});
$results['peak_memory_bytes'] = memory_get_peak_usage(true);
file_put_contents('/audit/battle-probe-'.$mode.'.json', json_encode($results, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)."\n");
echo json_encode(array_map(fn ($row) => is_array($row) && array_key_exists('value', $row) ? array_diff_key($row, ['value'=>true]) : $row, $results), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)."\n";
